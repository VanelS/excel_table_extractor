# Prompts Kilo Code — un lot = une nouvelle tâche

Préparation : kit à la racine de `hermes/`, maquettes PNG dans `docs/specs/maquettes/`, branche `feat/roles-controleur-manager`.
Après chaque lot : relire le diff, `git commit`, ouvrir une NOUVELLE tâche.

| Lot | Mode | Modèle conseillé | Prompt à coller |
|---|---|---|---|
| L0 | Architect | puissant | `Exécute @docs/specs/lots/L0_cartographie.md` |
| L1 | Code | puissant | `Implémente @docs/specs/lots/L1_roles_launched_by.md en t'appuyant sur @docs/specs/PLAN_IMPLEMENTATION.md` |
| L2 | Code | puissant | `Implémente @docs/specs/lots/L2_perimetre.md en t'appuyant sur @docs/specs/PLAN_IMPLEMENTATION.md` |
| L3 | Code | puissant | `Implémente @docs/specs/lots/L3_endpoints_dashboard.md en t'appuyant sur @docs/specs/PLAN_IMPLEMENTATION.md` |
| L4 | Code | économique | `Implémente @docs/specs/lots/L4_socle_front.md en t'appuyant sur @docs/specs/PLAN_IMPLEMENTATION.md` |
| L5 | Code | économique | `Implémente @docs/specs/lots/L5_workboard_controleur.md en t'appuyant sur @docs/specs/PLAN_IMPLEMENTATION.md` + joindre controleur.png |
| L6 | Code | économique | `Implémente @docs/specs/lots/L6_vue_manager.md en t'appuyant sur @docs/specs/PLAN_IMPLEMENTATION.md` + joindre manager.png |
| L7 | Code | économique | `Exécute @docs/specs/lots/L7_documentation.md` |

Après L0 : relire et corriger `PLAN_IMPLEMENTATION.md` à la main. C'est la seule carte que les lots suivants utiliseront.
Après L2 : tester à la main avec `HERMES_DEV_ROLE=controller` puis `manager` (API, export, Assistant global).
