# L1 — Rôles OIDC + `launched_by`

Fichiers : voir « Fichiers par lot / L1 » dans `docs/specs/PLAN_IMPLEMENTATION.md`.

## 1. Rôles
Variables d'environnement (ajouter à `.env.example`) :
```env
HERMES_ROLE_CLAIM=groups
HERMES_ROLE_MAP={"GRP_HERMES_MANAGERS":"manager","GRP_HERMES_CONTROLEURS":"controller","GRP_HERMES_ADMINS":"admin"}
HERMES_DEFAULT_ROLE=controller
HERMES_DEV_ROLE=            # dev local sans OIDC : controller | manager | admin
```
```python
class Role(str, Enum): controller="controller"; manager="manager"; admin="admin"

@dataclass(frozen=True)
class CurrentUser:
    sub: str; name: str; email: str | None; role: Role

def resolve_role(claims: dict) -> Role: ...   # priorité admin > manager > controller, sinon HERMES_DEFAULT_ROLE
def get_current_user(...) -> CurrentUser: ... # s'appuie sur la dépendance OIDC existante
```
`GET /api/me` renvoie en plus : `role`, `can_switch_view` (= manager|admin).

## 2. `launched_by`
Migration idempotente (au démarrage ou script existant) :
```sql
ALTER TABLE <executions> ADD COLUMN launched_by TEXT;
ALTER TABLE <executions> ADD COLUMN launched_by_name TEXT;
CREATE INDEX IF NOT EXISTS ix_executions_launched_by ON <executions>(launched_by);
```
- Rempli à la création d'une exécution ET au rejeu (rejeu = celui qui relance).
- `scripts/backfill_launched_by.py` : complète depuis `activity_logs` quand possible, sinon laisse `NULL`. Option `--dry-run`.

## 3. Tests (`tests/test_roles.py`)
- `resolve_role` : chaque groupe, multi-groupes, aucun groupe.
- `/api/me` renvoie `role` et `can_switch_view`.
- `POST /api/executions` renseigne `launched_by`.

Fin de lot : `pytest tests/test_roles.py -q --tb=short` + ruff.
