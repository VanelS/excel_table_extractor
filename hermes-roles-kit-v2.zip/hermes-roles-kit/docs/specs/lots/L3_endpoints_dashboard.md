# L3 — Endpoints tableaux de bord

## 1. `compute_status()` (fonction pure, `app/.../dashboard/status.py`)
Priorité de haut en bas :
| Statut | Règle |
|---|---|
| `late` | `due_at` < maintenant et pas `done` |
| `done` | étape Planning `done`, ou dernier run `succeeded` et 0 KO non jugé |
| `blocked` | dernier run `failed` |
| `in_progress` | run en cours ou étape Planning `in_progress` |
| `to_judge` | dernier run `succeeded` et KO non jugés > 0 |
| `to_run` | aucun run sur la période |

KO non jugé = ligne KO sans disposition active (réutiliser la logique existante).

## 2. Jalons
```sql
CREATE TABLE IF NOT EXISTS closing_milestones (
  id INTEGER PRIMARY KEY, period TEXT NOT NULL, label TEXT NOT NULL,
  due_date TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending', sort_order INTEGER NOT NULL DEFAULT 0);
```
`GET /api/closing/milestones?period=YYYY-MM` ; `PUT /api/closing/milestones/{id}` (manager/admin).

## 3. Endpoints (Pydantic, filtrés par `apply_scope`)
`GET /api/dashboard/controller?period=YYYY-MM`
```json
{"period":"2026-09",
 "kpis":{"assigned":4,"ko_to_judge":3253,"due_48h":2,"runs_30d":7},
 "today":[ControlRow],"all":[ControlRow],
 "anomalies":{"run_id":"...","control_id":"section_setting","by_rule":[{"rule":"ctrl_unit_mgr_authorized_ok","count":1204}]}}
```
`GET /api/dashboard/manager?period=YYYY-MM` (controller → 404)
```json
{"kpis":{"planned":10,"done":4,"in_progress":2,"blocked_or_late":2,"ko_to_judge":4812,"progress_pct":40},
 "progress":{"done":4,"in_progress":2,"blocked":2,"todo":2},
 "milestones":[...],
 "alerts":[{"kind":"ko_unjudged|late|blocked","control_id":"...","owner":{"sub":"...","name":"..."},"message":"...","action":"judge|rerun|open"}],
 "team":[{"owner":{...},"assigned":4,"done":1,"ko_to_judge":3253,"late":1}],
 "rows":[ControlRow]}
```
`ControlRow` :
```json
{"control_id":"section_setting","name":"...","version":"v009",
 "last_run":{"run_id":"...","at":"2026-10-13T20:04:00","status":"succeeded"},
 "status":"to_judge","ko_unjudged":3253,"due_at":"2026-10-15T18:00:00",
 "owner":{"sub":"...","name":"R. Gogajeto"},"primary_action":"judge|rerun|run|view"}
```
`today` = statuts `late`, `to_judge`, `to_run`, `blocked` ou échéance ≤ 48 h.

## 4. Tests (`tests/test_dashboard.py`)
Un cas par ligne du tableau §1 ; manager endpoint → 404 pour controller ; KPI cohérents avec `rows`.
Fin de lot : `pytest tests/test_dashboard.py -q --tb=short` + ruff.
