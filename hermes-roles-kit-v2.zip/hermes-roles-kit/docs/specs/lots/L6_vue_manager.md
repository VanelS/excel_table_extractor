# L6 — Vue Manager

Maquette : `docs/specs/maquettes/manager.png` (structure). Style : celui de l'app. Réutiliser au maximum les sous-composants de L5 (tuile, pastille, tableau).

`ManagerOverviewComponent` (garde `roleGuard(['manager','admin'])`), de haut en bas :
1. Titre « Clôture de <mois> » + sous-titre + bouton « Exporter en Excel » (export existant, toutes les lignes).
2. 6 tuiles KPI : planifiés, terminés, en cours, bloqués/retard, KO à juger, avancement %.
3. Carte « Avancement global » : barre segmentée (vert terminés, violet en cours, rouge bloqués, gris à faire) + légende + « n / total — x % ».
4. Grille de 2 cartes :
   - « Jalons de l'arrêté » : pastille d'état, date, libellé, état (Fait / En cours / À venir).
   - « Alertes — action requise » : titre, détail (responsable + échéance), bouton d'action.
5. « Charge par contrôleur » : avatar + nom, barre de progression, « x / y faits », KO à juger, retard.
6. « Tous les contrôles de la période » : filtres en pilules (Tous + un par contrôleur, construits depuis `team`) + tableau de L5 avec une colonne de plus, « Lancé par / Responsable ».

- Entrée de sidebar « Équipe » visible avec `*hasRole` (page vide « à venir », phase 2).
- FR + EN.

Fin de lot : build Angular OK.
