# L5 — Workboard contrôleur

Maquette : `docs/specs/maquettes/controleur.png` (structure). Style : celui de l'app.

- `DashboardComponent` remplace l'écran d'accueil actuel (« Bonjour <prénom> ») sur la route `/` ; affiche `ControllerWorkboardComponent` ou `ManagerOverviewComponent` selon `ViewModeService`.
- `ControllerWorkboardComponent`, de haut en bas :
  1. Titre « Bonjour <prénom> » + sous-titre + bouton « Nouveau contrôle » (action existante).
  2. 4 tuiles KPI (composant tuile existant) : contrôles à ma charge (violet), KO à juger (rouge), échéances ≤ 48 h (orange), mes exécutions 30 j (vert).
  3. Carte avec onglets en pilules : « Mes tâches du jour (n) » → `today` ; « Tous mes contrôles (n) » → `all` ; « Mes anomalies (n) » → `anomalies.by_rule` (barres horizontales rouges + lien « Ouvrir l'onglet Jugements »).
  4. Tableau : Contrôle (nom + `control_id · version` en mono) | Dernière exécution (date + run_id) | Statut (pastille) | KO non jugés | Échéance (rouge si dépassée, orange si ≤ 48 h) | Action.
- Actions → onglets existants : `judge` → Jugements, `run` / `rerun` → Lancer, `view` → Résultats.
- Pastilles de statut : `to_judge` rouge, `late` orange, `to_run` gris, `in_progress` violet, `blocked` orange foncé, `done` vert.
- Sidebar : pour un contrôleur, « Contrôles » devient « Mes contrôles » avec un badge = taille de `today`.
- Liste `/controls` : filtre `scope=mine` par défaut pour un contrôleur.
- États vide et chargement. FR + EN.

Fin de lot : build Angular OK.
