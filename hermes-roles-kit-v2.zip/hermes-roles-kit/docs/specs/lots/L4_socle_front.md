# L4 — Socle Angular

Fichiers : « Front » de `docs/specs/PLAN_IMPLEMENTATION.md`.

- `AuthService` : `role$`, `canSwitchView$` (depuis `/api/me`).
- `roleGuard(roles: Role[])` (guard fonctionnel).
- Directive structurelle `*hasRole="['manager','admin']"`.
- `ViewModeService` : `'controller' | 'manager'` ; défaut = manager si `canSwitchView`, sinon controller ; mémorisé en `localStorage` (try/catch).
- `PeriodService` : période courante `YYYY-MM` (défaut = mois précédent), observable.
- `PeriodSelectorComponent` (en-tête, à gauche de FR/EN) : bouton « Arrêté · Septembre 2026 » + menu des 12 derniers mois.
- `RoleSwitchComponent` (en-tête) : segment Contrôleur | Manager, affiché seulement si `canSwitchView`.
- `DashboardApiService` : `getController(period)`, `getManager(period)`, `getMilestones(period)` typés (interfaces = schémas de L3).
- i18n FR + EN pour toutes les chaînes.

Fin de lot : build Angular OK. Pas de test e2e.
