# L2 — Périmètre (sécurité) ⚠️ lot à relire à la main

Fichiers : tableau « points à filtrer » de `docs/specs/PLAN_IMPLEMENTATION.md`.

## 1. Scope
```python
@dataclass(frozen=True)
class Scope:
    all: bool
    user_sub: str | None
    user_name: str | None

def get_scope(user: CurrentUser = Depends(get_current_user)) -> Scope:
    if user.role in (Role.manager, Role.admin):
        return Scope(True, None, None)
    return Scope(False, user.sub, user.name)

def apply_scope(query, scope: Scope):
    """controller : launched_by = moi OU contrôle dont je suis responsable Planning
    (responsable_id = sub, sinon comparaison sur le nom, insensible à la casse)."""

def ensure_in_scope(run, scope: Scope) -> None:
    """Lève HTTPException(404) si le run est hors périmètre."""
```
Planning : ajouter `responsable_id` (sub OIDC) à côté de `responsable`, sans casser l'existant.

## 2. Brancher sur CHAQUE point de la liste
- Listes → `apply_scope()` ; accès par `run_id` → `ensure_in_scope()`.
- Inclut : résultats, jugements (lecture ET écriture), export Excel, `/api/executions/{run_id}/query` (DuckDB), SSE.
- Agent LangGraph : passer le `Scope` de l'utilisateur de la conversation à chaque outil qui lit des exécutions.
- Le catalogue des définitions de contrôles reste visible par tous.

## 3. Tests (`tests/test_scope.py`)
Fixtures : runs de A (controller), de B (controller), un manager M.
- Pour chaque point : A ne voit pas le run de B (404 ou absent) ; M voit tout.
- A voit un run de B si A est responsable Planning du contrôle.
- Agent : A demande les KO du run de B → pas de données.

Fin de lot : `pytest tests/test_scope.py -q --tb=short` + ruff. Lister les points couverts / non couverts.
