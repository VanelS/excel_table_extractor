# HERMES — règles (rôles & périmètre)
- Rôles : `controller` (voit ses exécutions + contrôles dont il est responsable Planning), `manager` et `admin` (voient tout).
- Filtrage UNIQUEMENT côté back via `apply_scope()`. Hors périmètre → 404. Rôle issu d'OIDC, jamais du front.
- Ne pas modifier `data/controls/**`. Pas de régression sur rejeu, jugements, export, Planning.
- Front : style existant (lavande/violet), chaînes FR + EN, réutiliser les composants existants.
- Lire seulement le fichier du lot en cours (`docs/specs/lots/Lx_*.md`) et `docs/specs/PLAN_IMPLEMENTATION.md`. Ne pas explorer au-delà des fichiers qu'ils citent.
- Tests ciblés uniquement (`pytest <fichier> -q --tb=short`). Réponses courtes : pas de récapitulatif du code écrit, juste la liste des fichiers modifiés.
- Ne jamais committer ni pousser.
