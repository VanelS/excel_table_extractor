# Chantier navigation — prompts Kilo (indépendant des autres chantiers)

Branche dédiée : `git checkout -b fix/navigation` (depuis la branche principale actuelle).
Exporter la maquette « Navigation » du canevas en `docs/specs/navigation/maquettes/navigation.png`.
Avant N0 : installer Playwright (`PLAYWRIGHT_SETUP.md`) et lancer `npm run e2e:nav` une fois. Les tests qui échouent = ton diagnostic de départ, à joindre à N0.
Un lot = une NOUVELLE tâche ; relire le diff et committer entre deux lots.

| # | Lot | Mode | Modèle | Prompt |
|---|---|---|---|---|
| 1 | N0 Diagnostic | Architect | puissant | `Exécute @docs/specs/navigation/N0_diagnostic.md` |
| 2 | N1 Socle technique | Code | puissant | `Implémente @docs/specs/navigation/N1_socle_technique.md en t'appuyant sur @docs/specs/navigation/NAV_DIAGNOSTIC.md` |
| 3 | N2 État dans l'URL | Code | puissant | `Implémente @docs/specs/navigation/N2_etat_dans_url.md en t'appuyant sur @docs/specs/navigation/NAV_DIAGNOSTIC.md` |
| 4 | N3 Ergonomie (+ navigation.png) | Code | économique | `Implémente @docs/specs/navigation/N3_ergonomie.md en t'appuyant sur @docs/specs/navigation/NAV_DIAGNOSTIC.md` |
| 5 | N4 Non-régression | Code | économique | `Implémente @docs/specs/navigation/N4_tests_non_regression.md` |

Après N0 : compléter toi-même la colonne « observé » des 10 tests manuels de NAV_DIAGNOSTIC.md.
N1 et N2 corrigent les bugs techniques et peuvent partir en production seuls ; N3 change l'ergonomie (à montrer aux utilisateurs avant).
Articulation avec les autres chantiers : faire ce chantier AVANT les lots L5/L6/R5 (ils réutiliseront fil d'Ariane, onglets et URL). Si les rôles ou occurrences sont livrés plus tard, ils s'ajoutent aux emplacements prévus (badge « À faire », sélecteur de période, menu Historique › Occurrences).
