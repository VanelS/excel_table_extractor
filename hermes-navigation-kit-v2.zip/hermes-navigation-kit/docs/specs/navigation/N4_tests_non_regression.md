# N4 — Filet de non-régression navigation

- Playwright utilise le Edge du poste (`channel: 'msedge'`), voir `PLAYWRIGHT_SETUP.md`. Partir de `e2e/navigation/smoke.spec.ts` fourni ; commande `npm run e2e:nav`.
- Regrouper les tests N1–N3 + les 10 cas de NAV_DIAGNOSTIC.md en un parcours `smoke.spec.ts` (< 2 min).
- Test « tous les liens » : parcourir la sidebar et chaque onglet de 2 contrôles, échouer sur toute erreur console ou réponse 404.
- Ajouter `npm run e2e:nav` à la commande de vérification globale (`scripts/check.ps1` si elle existe) et à la CI.
- Documenter le schéma d'URL dans `docs/specs/navigation/URLS.md` (une ligne par route, exemple d'URL).
