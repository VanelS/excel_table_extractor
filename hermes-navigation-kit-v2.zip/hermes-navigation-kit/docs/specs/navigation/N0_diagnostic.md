# N0 — Diagnostic (mode Architect, AUCUNE modification)

Produire `docs/specs/navigation/NAV_DIAGNOSTIC.md` (≤ 100 lignes).

## 1. Cartographie ciblée
- Fichier(s) de routes Angular (`app.routes.ts` / modules), routes enfants, guards, resolvers, `provideRouter` et ses options.
- Comment les onglets du détail contrôle sont gérés (route, `*ngIf`, variable de composant, query param ?).
- Où vivent filtres / tri / pagination de Résultats, Jugements, liste des contrôles.
- Flux de connexion OIDC : où l'URL demandée est-elle perdue/conservée ?
- Serveur web en prod (Nginx/OpenShift) : `try_files`, `base href`, préfixe de chemin.
- Tous les liens internes construits « à la main » (`href="/..."`, `window.location`, `router.navigate` avec chaînes).

## 2. Tests manuels à décrire (résultat attendu vs observé, à compléter par l'utilisateur)
1. Ouvrir directement `/controls/section_setting` dans un nouvel onglet.
2. F5 sur la page Résultats d'un contrôle.
3. Onglet Jugements → filtre → page 2 → ouvrir un détail → bouton Retour du navigateur.
4. Liste des contrôles triée par Nom → ouvrir un contrôle → « ← Contrôles ».
5. Copier l'URL de l'onglet Jugements et l'ouvrir dans une autre session.
6. Session expirée → reconnexion : retour sur la page demandée ?
7. Changer FR/EN sur une page profonde.
8. Navigation au clavier (Tab) dans la sidebar et les onglets.
9. Lien vers un contrôle inexistant.
10. Retour sur une page déjà visitée : position de défilement.

## 3. Sortie
Tableau des problèmes : `# | symptôme | cause probable | fichier | lot (N1/N2/N3)`, puis la liste des URL actuelles (pour les redirections de N3).
