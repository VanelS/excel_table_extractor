# N1 — Socle technique de navigation

1. **Rechargement / liens directs** : serveur web → `try_files $uri $uri/ /index.html;` (Nginx) ; `base href` cohérent avec le préfixe OpenShift ; assets en chemins relatifs.
2. **Retour après connexion** : avant redirection OIDC, mémoriser l'URL demandée (`sessionStorage`, try/catch) ; après login, `router.navigateByUrl(returnUrl)` si URL interne valide, sinon accueil.
3. **Guards** : attendre le chargement de l'utilisateur (`/api/me`) avant de décider ; pas de redirection vers l'accueil pendant le chargement.
4. **Options du routeur** : `withInMemoryScrolling({ scrollPositionRestoration: 'enabled', anchorScrolling: 'enabled' })`, `withComponentInputBinding()`.
5. **Titre d'onglet navigateur** par page (`TitleStrategy`) : « Jugements · Section Setting · Hermes ».
6. **Page 404** dédiée (route `**`) et page « ressource introuvable » pour un contrôle/run inexistant, avec lien de retour.
7. **Liens** : remplacer `href` codés en dur et `window.location` par `routerLink` / `router.navigate([...])`.
8. Langue FR/EN : changer de langue ne change pas de page ni ne perd les paramètres.

Tests Playwright `e2e/navigation/n1.spec.ts` : lien direct, F5, retour après login simulé, 404, titre.
