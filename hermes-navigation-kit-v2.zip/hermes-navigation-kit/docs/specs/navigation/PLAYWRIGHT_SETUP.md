# Playwright avec le Edge du poste (sans téléchargement de navigateur)

## Installation (une fois, dans le projet Angular)
```powershell
npm config get registry                          # doit pointer vers le registre interne
$env:PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD = "1"       # n'essaie pas de télécharger Chromium
$env:NO_PROXY = "localhost,127.0.0.1"             # évite le proxy d'entreprise pour l'appli locale
npm i -D @playwright/test
```
Copier `frontend-e2e/playwright.config.ts` à la racine du projet Angular et `frontend-e2e/e2e/` à côté.
Ajouter dans `package.json` :
```json
"e2e:nav": "playwright test e2e/navigation",
"e2e:ui":  "playwright test --ui",
"e2e:rec": "playwright codegen --channel=msedge http://localhost:4200"
```
Ajouter à `.gitignore` : `playwright-report/`, `test-results/`.

## Lancer
1. Démarrer le back (uvicorn) en mode dev, avec l'authentification de développement (`HERMES_DEV_ROLE=manager`).
2. `npm run e2e:nav` (démarre le front si besoin) — ou `npx playwright test --headed` pour voir Edge travailler.
3. Rapport : `npx playwright show-report` ; en cas d'échec : `npx playwright show-trace test-results/.../trace.zip`.

## Écrire des tests sans coder
`npm run e2e:rec` ouvre Edge : tu cliques dans Hermes, Playwright écrit le test. Coller le code dans `e2e/navigation/`.

## Authentification
Le Edge piloté démarre avec un profil vierge : pas de session SSO. En local, utiliser le mode d'auth de dev du back.
Si un vrai login est indispensable : un `global-setup.ts` qui se connecte une fois et enregistre `storageState` (ne jamais committer ce fichier).

## Si ça bloque
- « Executable doesn't exist » : vérifier `channel: 'msedge'` et que Edge est bien installé (`edge://version`).
- Edge refuse d'être piloté (stratégie de groupe sur le débogage distant) : essayer `channel: 'chrome'` ; sinon, garder Playwright pour la CI uniquement.
- Version de Playwright trop récente pour l'Edge du poste : installer une version de `@playwright/test` un peu plus ancienne.
