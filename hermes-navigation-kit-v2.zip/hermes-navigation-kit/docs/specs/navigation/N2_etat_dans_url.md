# N2 — L'état dans l'URL (liens partageables, Retour fiable)

## Schéma d'URL du détail contrôle
```
/controls/:controlId/:tab?run=<run_id>&<filtres>&sort=<col>:<asc|desc>&page=<n>
tab ∈ synthese | resultats | jugements | planning | pieces | regles | versions | calendrier | occurrences | journal
```
- Onglets = **routes enfants** (une route par onglet, chargement paresseux), plus de variable de composant.
- `run` absent → dernier run ; le sélecteur d'exécution met à jour `run` (sans recharger la page).
- Période (si le chantier occurrences existe) : `/controls/:controlId/:period/:tab` ; sinon segment absent. Prévoir les deux via une route optionnelle.

## Listes et tableaux
- Résultats, Jugements, liste des contrôles, Tendances : filtres, recherche, tri, page et taille de page lus/écrits dans les query params (`queryParamsHandling: 'merge'`, `replaceUrl: true` pour la saisie, `false` pour les changements de page).
- Un service utilitaire `UrlStateService` (lecture/écriture typée des query params) réutilisé partout.
- Lien « ← Contrôles » : revient à la liste avec ses paramètres (mémoriser la dernière URL de liste, sinon `/controls`).

## Redirections
Toutes les anciennes URL relevées dans NAV_DIAGNOSTIC.md redirigent vers le nouveau schéma (`redirectTo` ou guard de redirection). L'ancien onglet « Main » → `synthese`, « Espace de contrôle » → `synthese`, « Lancer » → `synthese?launch=1`, « Assistant IA » → `synthese?assistant=1`.

Tests `e2e/navigation/n2.spec.ts` : partager une URL filtrée ; Retour après changement de page ; Retour depuis un détail ; anciennes URL redirigées.
