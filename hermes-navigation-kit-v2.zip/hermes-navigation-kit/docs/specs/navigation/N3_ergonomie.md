# N3 — Réorganisation ergonomique

Maquette : `docs/specs/navigation/maquettes/navigation.png`. Style existant.

## Sidebar groupée
- **MON TRAVAIL** : Tableau de bord, À faire (badge ; masqué si le chantier rôles n'existe pas).
- **CONTRÔLES** : Catalogue (`/controls`), Exécutions récentes.
- **ANALYSE** : Tendances & Analyses, Rapports.
- **ADMINISTRATION** : Référentiels, Paramètres.
Libellés de groupe non cliquables ; `aria-current="page"` sur l'entrée active ; réduction de la sidebar conservée.

## Fil d'Ariane (composant `BreadcrumbComponent`)
Construit depuis les `data.breadcrumb` des routes : `Contrôles › <nom du contrôle> › [<période>] › <onglet>`. Chaque niveau cliquable sauf le dernier. Remplace le titre mono actuel de l'en-tête.

## En-tête du détail contrôle
Titre + pastilles (fréquence si disponible, version champion) ; à droite : sélecteur de période (si disponible), sélecteur d'exécution, bouton principal **Lancer** (ouvre le formulaire actuel de l'onglet Lancer dans un panneau), bouton **Assistant IA** (ouvre l'assistant actuel dans un panneau latéral, pas un onglet).

## Onglets : 11 → 5 + 2 menus
- Travail : **Synthèse** (fusion Main + Espace de contrôle) · **Résultats** · **Jugements (n)** · **Planning** · **Pièces jointes**
- Menu **Configuration ▾** : Règles (n), Versions (n), Calendrier (si disponible)
- Menu **Historique ▾** : Occurrences (si disponible), Journal d'audit (ex-Historique)
Le menu affiché comme actif quand un de ses éléments est ouvert. Menus accessibles au clavier (flèches, Échap).

## Contenu
Le contenu de chaque onglet est **déplacé, pas réécrit**. Seule « Synthèse » combine Main + Espace de contrôle : lister dans le diff ce qui a été fusionné.

Tests `e2e/navigation/n3.spec.ts` : chaque onglet atteignable en ≤ 2 clics, fil d'Ariane correct, menus au clavier, panneaux Lancer/Assistant ouvrables par URL (`?launch=1`, `?assistant=1`).
