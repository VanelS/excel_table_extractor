# HERMES — règles chantier navigation (indépendant des autres chantiers)
- Lire seulement le lot en cours (`docs/specs/navigation/Nx_*.md`) et `docs/specs/navigation/NAV_DIAGNOSTIC.md`.
- Ne pas toucher au back métier (règles, exécutions, jugements). Back autorisé : configuration serveur web et endpoints de redirection d'auth uniquement.
- Ne pas dépendre des chantiers « rôles » ou « occurrences » : si un élément (période, rôle) n'existe pas encore, le masquer proprement.
- Toute ancienne URL doit continuer à fonctionner (redirection), aucun lien existant ne doit casser.
- L'état visible (onglet, run, filtres, tri, page) vit dans l'URL ; rien d'important seulement en mémoire du composant.
- Style existant, FR + EN. Ne jamais modifier un test existant pour le faire passer. Ne jamais committer.
- Fin de lot : build Angular + tests Playwright de navigation (`e2e/navigation/`) au vert.
