import { test, expect, Page } from '@playwright/test';

// Base de référence AVANT le chantier navigation : ces tests décrivent le comportement attendu.
// Certains peuvent échouer aujourd'hui : c'est le diagnostic. Adapter les sélecteurs si besoin.

const CONTROL_ID = 'section_setting';
const CONTROL_TITLE = /Section Setting Controls/;

function collectErrors(page: Page) {
  const errors: string[] = [];
  page.on('pageerror', e => errors.push(`pageerror: ${e.message}`));
  page.on('console', m => { if (m.type() === 'error') errors.push(`console: ${m.text()}`); });
  page.on('response', r => {
    if (r.url().includes('/api/') && r.status() >= 500) errors.push(`API ${r.status()} ${r.url()}`);
  });
  return errors;
}

test('accueil : la page se charge sans erreur', async ({ page }) => {
  const errors = collectErrors(page);
  await page.goto('/');
  await expect(page.getByRole('button', { name: /Nouveau contrôle/i })).toBeVisible();
  expect(errors).toEqual([]);
});

test('lien direct vers un contrôle', async ({ page }) => {
  await page.goto(`/controls/${CONTROL_ID}`);
  await expect(page.getByText(CONTROL_TITLE).first()).toBeVisible();
  await expect(page).toHaveURL(new RegExp(`/controls/${CONTROL_ID}`));
});

test('F5 sur le détail contrôle reste sur la même page', async ({ page }) => {
  await page.goto(`/controls/${CONTROL_ID}`);
  await expect(page.getByText(CONTROL_TITLE).first()).toBeVisible();
  const before = page.url();
  await page.reload();
  await expect(page.getByText(CONTROL_TITLE).first()).toBeVisible();
  expect(page.url()).toBe(before);
});

test('liste → contrôle → bouton Retour du navigateur', async ({ page }) => {
  await page.goto('/controls');
  await page.getByText(CONTROL_TITLE).first().click();
  await expect(page).toHaveURL(new RegExp(`/controls/${CONTROL_ID}`));
  await page.goBack();
  await expect(page).toHaveURL(/\/controls\/?(\?.*)?$/);
});

test('le tri de la liste survit au Retour', async ({ page }) => {
  await page.goto('/controls');
  await page.getByRole('button', { name: /^Nom$/ }).click();
  const sortedUrl = page.url();
  await page.getByText(CONTROL_TITLE).first().click();
  await page.goBack();
  expect(page.url()).toBe(sortedUrl);   // échoue tant que le tri n'est pas dans l'URL (lot N2)
});

test('un onglet du détail contrôle a sa propre URL', async ({ page }) => {
  await page.goto(`/controls/${CONTROL_ID}`);
  const before = page.url();
  await page.getByRole('tab', { name: /Jugements/ }).or(page.getByText(/^Jugements/)).first().click();
  expect(page.url()).not.toBe(before);  // échoue tant que les onglets ne sont pas des routes (lot N2)
});

test('chaque entrée de la sidebar mène à une page sans erreur', async ({ page }) => {
  const errors = collectErrors(page);
  for (const path of ['/', '/controls', '/analytics']) {
    await page.goto(path);
    await expect(page.locator('body')).not.toBeEmpty();
  }
  expect(errors).toEqual([]);
});

test('URL inconnue → page 404 (pas une page blanche)', async ({ page }) => {
  await page.goto('/cette-page-n-existe-pas');
  await expect(page.getByText(/introuvable|404/i)).toBeVisible();  // échoue tant que N1 n'est pas fait
});
