// À placer à la racine du projet Angular (à côté de angular.json).
import { defineConfig } from '@playwright/test';

const baseURL = process.env.HERMES_E2E_URL ?? 'http://localhost:4200';

export default defineConfig({
  testDir: './e2e',
  timeout: 30_000,
  expect: { timeout: 10_000 },
  fullyParallel: false,
  retries: process.env.CI ? 1 : 0,
  reporter: [['list'], ['html', { open: 'never' }]],
  use: {
    baseURL,
    channel: 'msedge',            // Edge installé sur le poste : aucun téléchargement de navigateur
    headless: true,
    locale: 'fr-FR',
    trace: 'retain-on-failure',   // en cas d'échec : npx playwright show-trace <fichier>
    screenshot: 'only-on-failure',
  },
  projects: [
    { name: 'edge', use: { channel: 'msedge' } },
    // { name: 'chrome', use: { channel: 'chrome' } },  // si Edge est bloqué par une stratégie de groupe
  ],
  // Lance le front s'il ne tourne pas déjà. Le back (uvicorn) doit être démarré à part.
  webServer: process.env.HERMES_E2E_URL ? undefined : {
    command: 'npm run start',
    url: baseURL,
    reuseExistingServer: true,
    timeout: 180_000,
  },
});
