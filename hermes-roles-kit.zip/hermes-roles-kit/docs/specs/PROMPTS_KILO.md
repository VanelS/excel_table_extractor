# Prompts Kilo Code — Vues Contrôleur & Manager

Mode d'emploi :
1. Copier ce kit à la racine du dépôt `hermes/` (le dossier `.kilocode/rules/` est chargé automatiquement par Kilo Code).
   Si ta version de Kilo utilise le nouveau format `kilo.jsonc`, déplace la règle dans `.kilo/rules/` et ajoute-la au tableau `instructions` de `kilo.jsonc`.
2. Exporter les 2 maquettes du canevas en PNG (Partager › Exporter) dans `docs/specs/maquettes/controleur.png` et `docs/specs/maquettes/manager.png`.
3. Créer une branche : `git checkout -b feat/roles-controleur-manager`.
4. Lancer les prompts ci-dessous **dans l'ordre**, un par tâche Kilo (nouvelle tâche à chaque lot pour garder un contexte propre). Relire le diff et committer entre deux lots.

---

## Prompt 0 — Cartographie (mode **Architect**)

```
Lis docs/specs/SPEC_vues_controleur_manager.md et .kilocode/rules/hermes-roles-scope.md.
Explore le code backend (hermes_backend/) et frontend (Angular) SANS rien modifier, puis produis
docs/specs/PLAN_IMPLEMENTATION.md contenant :
- le nom réel de la table/modèle des exécutions et où elles sont créées (POST /api/executions, rerun) ;
- comment l'utilisateur OIDC courant est obtenu aujourd'hui (dépendance FastAPI, session, claims disponibles) ;
- la LISTE EXHAUSTIVE des endpoints, exports, flux SSE et outils de l'agent LangGraph qui renvoient des données d'exécution
  (avec fichier + fonction) — ce sont les points où apply_scope() devra être branché ;
- où sont stockées les étapes du Planning (champ responsable) ;
- côté Angular : service d'auth, routing, composant de l'écran d'accueil, composant des tuiles KPI réutilisable, fichiers i18n,
  variables de style (couleurs) ;
- pour chaque lot L1→L7 de la spec : la liste des fichiers à créer/modifier.
Signale tout écart entre la spec et le code réel.
```

## Prompt 1 — L1 Rôles + launched_by (mode **Code**)

```
Implémente le lot L1 de docs/specs/SPEC_vues_controleur_manager.md en suivant docs/specs/PLAN_IMPLEMENTATION.md :
rôles depuis les claims OIDC (HERMES_ROLE_CLAIM / HERMES_ROLE_MAP / HERMES_DEFAULT_ROLE / HERMES_DEV_ROLE),
champ role + can_switch_view dans /api/me, colonnes launched_by / launched_by_name + index via migration idempotente,
remplissage dans la création d'exécution et le rejeu, script scripts/backfill_launched_by.py basé sur activity_logs.
Ajoute les tests pytest correspondants (§5). Lance pytest et ruff, corrige jusqu'au vert, puis résume les changements.
```

## Prompt 2 — L2 Périmètre (mode **Code**)

```
Implémente le lot L2 : get_scope() / apply_scope() et branche-les sur CHAQUE point listé dans PLAN_IMPLEMENTATION.md
(endpoints, export Excel, /api/executions/{run_id}/query, SSE, outils de l'agent LangGraph).
Contrôleur hors périmètre => 404. Écris un test de non-fuite par point d'accès (un contrôleur A ne voit pas un run de B,
un manager voit tout). Lance pytest + ruff jusqu'au vert. Liste à la fin les points couverts et ceux éventuellement non couverts.
```

## Prompt 3 — L3 Endpoints tableaux de bord (mode **Code**)

```
Implémente le lot L3 : fonction pure compute_status() (tableau §3.4) avec tests unitaires par cas,
table closing_milestones + endpoints /api/closing/milestones, puis /api/dashboard/controller et /api/dashboard/manager
avec les schémas Pydantic de la spec (§3.3). Le calcul des KO non jugés réutilise la logique existante des dispositions.
Tests + ruff au vert.
```

## Prompt 4 — L4 Socle front (mode **Code**)

```
Implémente le lot L4 côté Angular : rôle dans AuthService (role$, canSwitchView$), roleGuard, directive *hasRole,
ViewModeService (localStorage protégé par try/catch), PeriodSelectorComponent et RoleSwitchComponent dans l'en-tête existant
(à côté de FR/EN). Services HTTP typés pour /api/dashboard/*. Chaînes FR + EN. Le build Angular doit passer.
```

## Prompt 5 — L5 Workboard contrôleur (mode **Code**)

```
Implémente ControllerWorkboardComponent en reproduisant la STRUCTURE de docs/specs/maquettes/controleur.png
avec le STYLE existant de l'application (réutilise les tuiles KPI de Tendances & Analyses, les variables de couleur existantes).
Remplace l'écran d'accueil actuel ("Bonjour <prénom>") par DashboardComponent qui affiche le Workboard pour un contrôleur.
Les boutons d'action redirigent vers les onglets existants du détail contrôle (Jugements, Lancer, Résultats).
Onglets : Mes tâches du jour / Tous mes contrôles / Mes anomalies (KO non jugés par règle). FR + EN. Build OK.
```

## Prompt 6 — L6 Vue Manager (mode **Code**)

```
Implémente ManagerOverviewComponent d'après docs/specs/maquettes/manager.png, style existant :
6 KPI, barre d'avancement segmentée, Jalons de l'arrêté, Alertes – action requise, Charge par contrôleur,
tableau de tous les contrôles filtrable par contrôleur, bouton Exporter en Excel.
Visible uniquement pour manager/admin (guard + *hasRole), vue par défaut pour un manager, bascule vers son Workboard.
Libellé de sidebar "Mes contrôles" + badge pour un contrôleur. FR + EN. Build OK.
```

## Prompt 7 — L7 Documentation (mode **Code**)

```
Ajoute à DOCUMENTATION_TECHNIQUE.md une section "Rôles, périmètre et tableaux de bord" décrivant : mapping OIDC → rôles,
colonne launched_by et backfill, get_scope/apply_scope et la liste des points filtrés, endpoints /api/dashboard/*,
règles compute_status, composants Angular ajoutés, variables d'environnement. Mets à jour le catalogue des outils de l'agent
pour indiquer qu'ils appliquent le périmètre.
```

---

### Astuce : mode Orchestrator

Tu peux aussi donner à l'**Orchestrator** la consigne :
« Exécute les lots L1 à L7 de docs/specs/PROMPTS_KILO.md, une sous-tâche par lot, en t'arrêtant après chaque lot pour validation. »
Je recommande quand même de valider le lot L2 (sécurité) à la main avant de continuer.
