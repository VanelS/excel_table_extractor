# SPEC — Vues Contrôleur & Manager (HERMES LOD 1.2)

> Spécification d'implémentation destinée à l'agent Kilo Code.
> Maquettes de référence : `docs/specs/maquettes/controleur.png` et `docs/specs/maquettes/manager.png`
> (export PNG du canevas « Hermes — Vues Contrôleur & Manager »).
> Les maquettes définissent la **structure et le contenu**. Le **style** est celui de l'application actuelle (fond lavande), pas celui des anciennes maquettes sombres.

---

## 0. Objectif

Ajouter deux rôles métier à HERMES et un tableau de bord qui s'adapte au rôle :

| Rôle | Ce qu'il voit | Écran d'accueil |
|---|---|---|
| `controller` | Uniquement les contrôles/exécutions **qu'il a lancés** ou dont il est **responsable dans le Planning** | « Mon Workboard » |
| `manager` | **Tous** les contrôles et toutes les exécutions | « Clôture de <mois> » + bascule vers son propre Workboard |
| `admin` | Comme `manager` + Paramètres | inchangé |

Le filtrage est une **règle de sécurité appliquée côté back**, pas un simple filtre d'affichage.

---

## 1. Invariants (à ne jamais casser)

1. **Toute** donnée d'exécution qui sort du back (API REST, export Excel, SSE, agent LangGraph, sandbox DuckDB `/api/executions/{run_id}/query`) passe par le même filtre de périmètre `apply_scope()`.
2. Un contrôleur qui appelle une ressource hors de son périmètre reçoit **404** (pas 403, pour ne pas révéler son existence).
3. Le rôle vient de l'identité OIDC, jamais d'un paramètre envoyé par le front.
4. Les définitions de contrôle versionnées (`data/controls/<control_id>/`) restent **lisibles par tous** (catalogue) ; seules les **exécutions, résultats, jugements et exports** sont filtrés.
5. Aucune régression sur les flux existants : rejeu idempotent (`parent_run_id`), jugements (`dispositions`), export Excel, Planning.
6. Toute action de lancement est tracée dans `activity_logs` avec `launched_by`.

---

## 2. Modèle de données

### 2.1 Rôles

Option retenue : correspondance **groupes OIDC → rôles**, configurable.

```env
# .env / manifests
HERMES_ROLE_CLAIM=groups
HERMES_ROLE_MAP={"GRP_HERMES_MANAGERS":"manager","GRP_HERMES_CONTROLEURS":"controller","GRP_HERMES_ADMINS":"admin"}
HERMES_DEFAULT_ROLE=controller
```

- Si l'utilisateur appartient à plusieurs groupes : `admin > manager > controller`.
- En dev local (sans OIDC) : un utilisateur fictif configurable via `HERMES_DEV_ROLE`.

### 2.2 Exécutions — colonne `launched_by`

Migration SQLite (`hermes.db`), idempotente :

```sql
ALTER TABLE executions ADD COLUMN launched_by TEXT;          -- sub OIDC (ou e-mail)
ALTER TABLE executions ADD COLUMN launched_by_name TEXT;     -- nom affichable
CREATE INDEX IF NOT EXISTS ix_executions_launched_by ON executions(launched_by);
```

- Renseignée par `POST /api/executions` (et `/rerun`) à partir de l'utilisateur courant.
- Un rejeu est attribué à **celui qui relance** ; l'origine reste lisible via `parent_run_id`.
- **Rattrapage de l'historique** : script `scripts/backfill_launched_by.py` qui relit `activity_logs` (entrées de création d'exécution) et complète `launched_by` quand c'est possible ; sinon `NULL` (visible des managers uniquement).

> ⚠️ Adapter le nom réel de la table d'exécutions (vérifier dans le code : modèle SQLAlchemy / requêtes SQL existantes).

### 2.3 Responsable Planning

Le module Planning (`section_setting`) porte déjà `responsable` sur chaque étape. Ajouter **`responsable_id`** (sub OIDC) à côté du libellé, pour pouvoir filtrer de façon fiable. Rétro-compatibilité : si `responsable_id` est absent, on compare sur le nom affiché (insensible à la casse).

### 2.4 Jalons de l'arrêté (nouveau, petit)

```sql
CREATE TABLE IF NOT EXISTS closing_milestones (
  id INTEGER PRIMARY KEY,
  period TEXT NOT NULL,          -- '2026-09'
  label TEXT NOT NULL,
  due_date TEXT NOT NULL,        -- ISO
  status TEXT NOT NULL DEFAULT 'pending',   -- pending | in_progress | done
  sort_order INTEGER NOT NULL DEFAULT 0
);
```

Écriture réservée à `manager`/`admin`.

---

## 3. Back-end (FastAPI)

### 3.1 Identité et périmètre

```python
# app/security/roles.py  (adapter au découpage réel)
class Role(str, Enum):
    controller = "controller"
    manager = "manager"
    admin = "admin"

@dataclass(frozen=True)
class CurrentUser:
    sub: str
    name: str
    email: str | None
    role: Role

def get_current_user(...) -> CurrentUser: ...   # s'appuie sur la session OIDC existante

@dataclass(frozen=True)
class Scope:
    all: bool
    user_sub: str | None
    user_name: str | None

def get_scope(user: CurrentUser = Depends(get_current_user)) -> Scope:
    if user.role in (Role.manager, Role.admin):
        return Scope(all=True, user_sub=None, user_name=None)
    return Scope(all=False, user_sub=user.sub, user_name=user.name)

def apply_scope(query, scope: Scope):
    """Unique point de filtrage des exécutions.
    controller -> launched_by = moi OR exécution d'un contrôle dont je suis responsable Planning sur la période."""
```

- `GET /api/me` renvoie en plus `role` (et `can_switch_view: bool` = manager/admin).

### 3.2 Endpoints à filtrer (liste à compléter en explorant le code)

- `GET /api/executions`, `GET /api/executions/{run_id}`, résultats/synthèse/détail
- `GET|POST /api/controls/{control_id}/dispositions` (jugements)
- export Excel (`steps_process/postprocess` / endpoint d'export)
- `POST /api/executions/{run_id}/query` (sandbox DuckDB)
- Flux SSE de l'agent
- Outils de l'agent LangGraph : `list_executions`, `get_execution`, `query_anomalies`, `analyze_run_data`, etc. → chaque outil reçoit le `Scope` de l'utilisateur de la conversation.

### 3.3 Nouveaux endpoints

```
GET /api/dashboard/controller?period=YYYY-MM
GET /api/dashboard/manager?period=YYYY-MM          (manager/admin, sinon 404)
GET /api/closing/milestones?period=YYYY-MM
PUT /api/closing/milestones/{id}                   (manager/admin)
```

Réponse `controller` :

```json
{
  "period": "2026-09",
  "kpis": {"assigned": 4, "ko_to_judge": 3253, "due_48h": 2, "runs_30d": 7},
  "today": [ControlRow, ...],
  "all": [ControlRow, ...],
  "anomalies": {"run_id": "...", "control_id": "section_setting", "by_rule": [{"rule": "ctrl_unit_mgr_authorized_ok", "count": 1204}]}
}
```

`ControlRow` :

```json
{
  "control_id": "section_setting", "name": "...", "version": "v009",
  "last_run": {"run_id": "...", "at": "2026-10-13T20:04:00", "status": "succeeded"},
  "status": "to_judge | late | to_run | in_progress | blocked | done",
  "ko_unjudged": 3253, "due_at": "2026-10-15T18:00:00",
  "owner": {"sub": "...", "name": "R. Gogajeto"},
  "primary_action": "judge | rerun | run | view"
}
```

Réponse `manager` : mêmes `ControlRow` (tous), plus :

```json
{
  "kpis": {"planned": 10, "done": 4, "in_progress": 2, "blocked_or_late": 2, "ko_to_judge": 4812, "progress_pct": 40},
  "progress": {"done": 4, "in_progress": 2, "blocked": 2, "todo": 2},
  "milestones": [...],
  "alerts": [{"kind": "ko_unjudged|late|blocked", "control_id": "...", "owner": {...}, "message": "...", "action": "..."}],
  "team": [{"owner": {...}, "assigned": 4, "done": 1, "ko_to_judge": 3253, "late": 1}]
}
```

### 3.4 Règles de calcul des statuts (une seule fonction pure, testée)

| Statut | Règle |
|---|---|
| `done` | étape Planning `done` **ou** dernière exécution `succeeded` et 0 KO non jugé |
| `to_judge` | dernière exécution `succeeded` et KO non jugés > 0 |
| `in_progress` | exécution en cours **ou** étape Planning `in_progress` |
| `blocked` | dernière exécution `failed` |
| `late` | `due_at` < maintenant et statut ≠ `done` (prioritaire sur les autres) |
| `to_run` | aucune exécution sur la période |

« KO non jugé » = ligne KO sans disposition active (réutiliser la logique de `n_new_ko` / dispositions existante).

---

## 4. Front-end (Angular)

### 4.1 Socle

- `AuthService` : expose `user$` et `role$` (depuis `/api/me`).
- `roleGuard(roles: Role[])` pour les routes réservées.
- Directive structurelle `*hasRole="['manager','admin']"`.
- `ViewModeService` : `'controller' | 'manager'`, initialisé selon le rôle, mémorisé en `localStorage` (try/catch).

### 4.2 Écrans

| Composant | Route | Contenu (cf. maquettes) |
|---|---|---|
| `DashboardComponent` | `/` (remplace l'écran « Bonjour Rodrigo ») | affiche l'un des deux suivants selon `ViewModeService` |
| `ControllerWorkboardComponent` | — | 4 KPI, onglets *Mes tâches du jour / Tous mes contrôles / Mes anomalies*, tableau, bouton « Nouveau contrôle » |
| `ManagerOverviewComponent` | — | 6 KPI, barre d'avancement segmentée, Jalons, Alertes, Charge par contrôleur, tableau filtrable par contrôleur, export |
| `PeriodSelectorComponent` | en-tête | « Arrêté · <Mois AAAA> », alimente `?period=` |
| `RoleSwitchComponent` | en-tête | bascule Contrôleur / Manager, visible seulement si `can_switch_view` |

- Les actions des lignes **redirigent vers les onglets existants** du détail contrôle (`/controls/:id` → onglet Jugements, Lancer, Résultats) ; on ne duplique pas ces écrans.
- Sidebar : libellé « Contrôles » → « Mes contrôles » pour un contrôleur, avec badge du nombre d'actions à faire ; entrée « Équipe » visible pour manager (phase 2).
- Liste `/controls` : ajouter un filtre `?scope=mine` par défaut pour le contrôleur.
- i18n : toutes les nouvelles chaînes en FR **et** EN (mécanisme existant FR/EN).

### 4.3 Design (reprendre les tokens de l'app, ne pas en créer)

Repérer les variables CSS/SCSS existantes et les réutiliser. À défaut, valeurs observées :

| Usage | Valeur |
|---|---|
| Fond page | `#EFEEF6` (lavande) |
| Cartes | `#FFFFFF`, bordure `#E3E1EE`, rayon 16–18 px |
| Accent / bouton primaire | `#5B21D6`, texte `#FFFFFF` |
| Accent doux (sélection, chips) | `#E7E1FB` / texte `#3B1594` |
| OK / KO / Pending / Retard | `#1F8A4C` / `#C2333B` / `#6D4AE0` / `#B45309` |
| Titres de page en-tête | police mono, espacement 1.5 px |

Tuiles KPI : réutiliser le composant des tuiles de *Tendances & Analyses* (liseré coloré en haut).

---

## 5. Tests (critères d'acceptation)

Back (pytest) :
- [ ] Un contrôleur ne voit dans `/api/executions` que ses exécutions + celles des contrôles dont il est responsable.
- [ ] Un contrôleur reçoit 404 sur `/api/executions/{run_id}` d'un autre contrôleur, sur l'export Excel et sur `/query`.
- [ ] Un manager voit tout.
- [ ] `POST /api/executions` renseigne `launched_by`.
- [ ] Les outils de l'agent respectent le périmètre (test : un contrôleur demande à l'agent les KO d'un run qui n'est pas le sien → refus/absence).
- [ ] `compute_status()` couvre chaque ligne du tableau §3.4.
- [ ] `/api/dashboard/manager` renvoie 404 pour un contrôleur.

Front :
- [ ] Contrôleur : pas de bascule de vue, Workboard affiché à l'accueil.
- [ ] Manager : bascule visible, Vue Clôture par défaut.
- [ ] Changement de période recharge les données.
- [ ] FR/EN complets.

---

## 6. Découpage en lots

| Lot | Contenu | Livrable vérifiable |
|---|---|---|
| L1 | Rôles OIDC + `/api/me.role` + `launched_by` + migration + backfill | tests §5 (rôles, launched_by) |
| L2 | `get_scope` / `apply_scope` sur tous les endpoints + agent | tests de non-fuite |
| L3 | Endpoints dashboard + `compute_status` + jalons | tests unitaires statuts |
| L4 | Front : socle (AuthService, guard, directive, ViewMode, période) | build Angular OK |
| L5 | Front : Workboard contrôleur | revue visuelle vs maquette |
| L6 | Front : Vue Manager | revue visuelle vs maquette |
| L7 | Doc : mettre à jour `DOCUMENTATION_TECHNIQUE.md` (nouvelle section rôles & tableaux de bord) | |

## 7. Questions ouvertes (à confirmer avant L1)

1. Noms exacts des groupes OIDC pour les rôles.
2. Le périmètre contrôleur inclut-il bien « responsable Planning » en plus de « lancé par » ? (hypothèse retenue : oui)
3. « Anomalies KURE » des anciennes maquettes = KO non jugés ? (hypothèse retenue : oui)
4. BlackLine : simple référence/lien externe (phase 2) ou intégration ?
