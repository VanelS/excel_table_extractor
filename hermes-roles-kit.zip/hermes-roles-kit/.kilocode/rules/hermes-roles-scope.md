# Règles projet HERMES — rôles et périmètre

Ces règles s'appliquent à toute tâche touchant aux exécutions, résultats, jugements, exports, tableaux de bord ou à l'agent.

- Référence fonctionnelle : `docs/specs/SPEC_vues_controleur_manager.md`. La lire avant de coder.
- Le filtrage par rôle se fait **côté back**, via `get_scope()` / `apply_scope()` et nulle part ailleurs. Ne jamais filtrer uniquement dans Angular.
- Un contrôleur qui demande une ressource hors périmètre reçoit **404**.
- Le rôle vient de l'identité OIDC (`/api/me`), jamais d'un paramètre de requête ou du front.
- Tout nouvel endpoint ou outil d'agent qui renvoie des données d'exécution doit appeler `apply_scope()` et avoir un test de non-fuite.
- Ne pas modifier les définitions versionnées `data/controls/**` ni le comportement CHAMPION.
- Front : réutiliser les composants et variables de style existants (fond lavande, accent violet). Ne pas importer le thème sombre des anciennes maquettes.
- Front : toute nouvelle chaîne existe en FR et en EN.
- Les lignes des tableaux de bord renvoient vers les onglets existants du détail contrôle ; ne pas dupliquer Jugements/Résultats/Lancer.
- Avancer lot par lot (L1 → L7). À la fin de chaque lot : lancer les tests back (`pytest`), le linter (`ruff`) et le build Angular, puis résumer les fichiers modifiés.
- Ne jamais committer ni pousser sans demande explicite.
