# R5 — Interface : calendrier, occurrences, période au lancement

Maquettes : `docs/specs/maquettes/calendrier.png`, `docs/specs/maquettes/occurrences.png`. Style de l'app, composants de L5/L6.

1. **Paramètres › Calendrier des contrôles** (admin ; lecture seule pour les autres)
   - Bandeau réglages globaux (début d'exercice, semaines ISO, jours fériés) en lecture.
   - Tableau : contrôle, fréquence (pastille), échéance (`J+n ouvrés`), responsable, prochaine échéance.
   - Panneau d'édition du contrôle sélectionné : fréquence (pilules), intervalle, échéance, période proposée au lancement, responsable par défaut, politique des jugements (Reportés / Expirent après N périodes / À refaire à chaque période), validation manager (oui/non). `PUT /api/schedules/{id}`.
2. **Détail contrôle › nouvel onglet « Occurrences »** (entre Planning et Pièces jointes)
   - Pastille « Mensuel · J+11 ouvrés » à côté du titre (aussi sur les cartes de `/controls`).
   - 4 tuiles : échéance en cours, closes dans les délais sur 12 mois, politique des jugements, validation.
   - Histogramme « KO par période » (dernières 6 occurrences, la courante en accent).
   - Tableau : période (libellé + clé + bornes), échéance, responsable, statut, exécutions, KO · jugés, close/validée par, action (Juger, Lancer, Clore, Valider, Voir).
3. **Onglet Lancer** : sélecteur de période présélectionné selon `default_period` ; avertissement si la période est déjà close.
4. **Workboard / Vue Manager** : colonne ou sous-titre « Période » (`period_label`) ; section « Cette semaine » si `this_week` non vide ; tuile « À valider » côté manager si > 0 ; bouton « Valider » dans les lignes concernées.
5. **Tendances & Analyses** : option « Grouper par période » qui utilise `period_key`.

FR + EN. Fin de lot : build Angular OK.
