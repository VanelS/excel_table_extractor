# L3′ — Endpoints tableaux de bord (sur les occurrences)

Plus de recalcul : tout se lit dans `control_occurrences` (filtré par `apply_scope`).

**Arrêté sélectionné** (`period=YYYY-MM`) = occurrences dont `due_at` tombe entre le 1er jour du mois suivant la période et la fin de ce mois. Ainsi, l'arrêté de septembre regroupe le mensuel de septembre, le trimestriel T3, etc. Les hebdomadaires sont renvoyés à part (`this_week`).

`GET /api/dashboard/controller?period=YYYY-MM`
```json
{"period":"2026-09",
 "kpis":{"assigned":4,"ko_to_judge":3253,"due_48h":2,"runs_30d":7},
 "today":[OccRow],"all":[OccRow],"this_week":[OccRow],
 "anomalies":{"occurrence_id":12,"run_id":"...","by_rule":[{"rule":"ctrl_unit_mgr_authorized_ok","count":1204}]}}
```
`today` = statuts `open|to_judge|blocked|late` ou échéance ≤ 48 h.

`GET /api/dashboard/manager?period=YYYY-MM` (controller → 404)
```json
{"kpis":{"planned":10,"done":4,"in_progress":2,"blocked_or_late":2,"ko_to_judge":4812,"progress_pct":40,"to_validate":1},
 "progress":{"done":4,"in_progress":2,"blocked":2,"todo":2},
 "by_frequency":[{"frequency":"monthly","planned":7,"done":3}],
 "milestones":[...], "alerts":[...], "team":[...], "rows":[OccRow], "this_week":[OccRow]}
```
`done` compte `done` + `validated` (et `done` seulement si `requires_validation = 0`). `to_validate` = `done` avec validation requise.

`OccRow`
```json
{"occurrence_id":12,"control_id":"section_setting","name":"...","version":"v009",
 "frequency":"monthly","period_key":"2026-09","period_label":"Septembre 2026",
 "status":"to_judge","ko_unjudged":3253,"due_at":"2026-10-15",
 "owner":{"sub":"...","name":"R. Gogajeto"},
 "last_run":{"run_id":"...","at":"...","status":"succeeded"},
 "primary_action":"judge|run|rerun|close|validate|view"}
```

Jalons : garder `closing_milestones (period, label, due_date, status, sort_order)`, `GET/PUT /api/closing/milestones` (PUT manager/admin).

Tests `tests/test_dashboard.py` : composition de l'arrêté (mensuel + trimestriel), KPI = somme des lignes, 404 manager pour controller, `to_validate`.
