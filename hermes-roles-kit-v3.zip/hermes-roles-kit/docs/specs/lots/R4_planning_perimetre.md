# R4 — Planning par occurrence + périmètre simplifié

## 1. Planning
- Les étapes actuelles du module Planning (`section_setting`) deviennent un **modèle d'étapes** au niveau du contrôle (offsets en jours par rapport au début de période ou à l'échéance).
- Table `occurrence_steps (id, occurrence_id, name, owner_sub, owner_name, start_date, end_date, status, sort_order)`.
- À la création d'une occurrence, les étapes du modèle sont recopiées avec des dates calculées.
- L'onglet Planning d'un contrôle affiche les étapes de l'occurrence sélectionnée (défaut : occurrence ouverte la plus proche de l'échéance). L'export CSV existant reste compatible.
- Migration : les étapes existantes sont rattachées à l'occurrence de leur période (date de début) ; le modèle est initialisé à partir de la dernière série.

## 2. Périmètre (remplace la règle « responsable Planning » de L2)
Dans `apply_scope()` / `ensure_in_scope()`, pour un contrôleur :
`launched_by = moi` **OU** `occurrence.owner_sub = moi` **OU** `occurrence_steps.owner_sub = moi`.
Supprimer la comparaison sur le nom affiché ajoutée en L2.

## 3. Tests
Mettre à jour `tests/test_scope.py` (nouvelle règle) ; `tests/test_planning_occurrences.py` (recopie du modèle, dates calculées, migration).
