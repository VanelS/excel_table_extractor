# R1 — Fréquences et périodes (domaine pur, aucun accès BDD)

Créer `domain/scheduling/` (adapter le chemin à PLAN_IMPLEMENTATION.md) :

```python
class Frequency(str, Enum):
    weekly="weekly"; monthly="monthly"; quarterly="quarterly"
    semiannual="semiannual"; annual="annual"; ad_hoc="ad_hoc"

@dataclass(frozen=True, order=True)
class Period:
    frequency: Frequency
    key: str            # '2026-W41' | '2026-09' | '2026-Q3' | '2026-S2' | '2026' | 'ADHOC-<id>'
    start: date
    end: date           # inclus

    @staticmethod
    def for_date(d: date, freq: Frequency, interval: int = 1, fiscal_start_month: int = 1) -> "Period": ...
    @staticmethod
    def parse(key: str, fiscal_start_month: int = 1) -> "Period": ...
    def next(self, interval: int = 1) -> "Period": ...
    def previous(self, interval: int = 1) -> "Period": ...
    def contains(self, d: date) -> bool: ...
    def label(self, lang: str = "fr") -> str: ...   # 'Septembre 2026', 'T3 2026', 'S41 2026'...

def add_business_days(d: date, n: int, holidays: set[date]) -> date: ...
def due_date(period: Period, offset_days: int, business_days: bool, holidays: set[date]) -> date:
    """Échéance = fin de période + offset (jours ouvrés ou calendaires)."""
```

Règles :
- Semaines ISO (lundi → dimanche), clé `YYYY-Www`.
- `fiscal_start_month` décale trimestres, semestres et années ; clé = année de début d'exercice. Défaut 1 = civil.
- `interval` > 1 : les périodes sont alignées sur le début d'exercice (ex. bimestriel = jan-fév, mar-avr…).
- Réglages globaux (env) : `HERMES_FISCAL_YEAR_START_MONTH=1`, `HERMES_HOLIDAYS_FILE=` (JSON de dates, vide = aucun férié).

Tests `tests/test_periods.py` (paramétrés) :
- `for_date` pour chaque fréquence, bornes et clés ; semaine 53 ; 29 février.
- exercice décalé (`fiscal_start_month=4`) ; `interval=2`.
- `parse(key)` = inverse de `key` ; `next/previous` aller-retour.
- `due_date` : 30/09/2026 + 11 jours ouvrés = 15/10/2026 ; avec un férié.

Fin de lot : `pytest tests/test_periods.py -q --tb=short` + ruff.
