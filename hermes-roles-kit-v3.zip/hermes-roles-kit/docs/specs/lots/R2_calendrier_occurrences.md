# R2 — Calendrier des contrôles + occurrences

## 1. Tables (migration idempotente)
```sql
CREATE TABLE IF NOT EXISTS control_schedules (
  control_id TEXT PRIMARY KEY,
  frequency TEXT NOT NULL,                       -- Frequency
  interval INTEGER NOT NULL DEFAULT 1,
  due_offset_days INTEGER NOT NULL DEFAULT 10,
  due_in_business_days INTEGER NOT NULL DEFAULT 1,
  default_period TEXT NOT NULL DEFAULT 'previous',      -- previous | current
  default_owner_sub TEXT, default_owner_name TEXT,
  disposition_policy TEXT NOT NULL DEFAULT 'carry_over', -- carry_over | per_period | expire_after
  disposition_validity_periods INTEGER,                  -- utilisé si expire_after
  requires_validation INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1,
  updated_at TEXT, updated_by TEXT);

CREATE TABLE IF NOT EXISTS control_occurrences (
  id INTEGER PRIMARY KEY,
  control_id TEXT NOT NULL, period_key TEXT NOT NULL,
  period_start TEXT NOT NULL, period_end TEXT NOT NULL, due_at TEXT NOT NULL,
  owner_sub TEXT, owner_name TEXT,
  status TEXT NOT NULL DEFAULT 'planned',
  control_version TEXT, current_run_id TEXT,
  ko_total INTEGER, ko_unjudged INTEGER,
  closed_at TEXT, closed_by TEXT, validated_at TEXT, validated_by TEXT,
  created_at TEXT NOT NULL,
  UNIQUE(control_id, period_key));
CREATE INDEX IF NOT EXISTS ix_occ_owner ON control_occurrences(owner_sub);
CREATE INDEX IF NOT EXISTS ix_occ_due ON control_occurrences(due_at);
```
Valeurs par défaut = comportement actuel d'Hermes (jugements reportés, pas de validation).

## 2. Statuts d'occurrence
`planned` (période pas finie) → `open` (à faire) → `in_progress` (run en cours) → `to_judge` (KO non jugés) → `done` (clos) → `validated` (si `requires_validation`).
Transverses : `blocked` (dernier run en échec), `late` (échéance dépassée et pas `done/validated`), `waived` (dispensée, motif obligatoire, manager).
`done` est atteint automatiquement quand le dernier run a réussi et `ko_unjudged = 0`, ou manuellement via « Clore ».
Si `requires_validation` : `done` → `validated` uniquement par manager/admin, et l'occurrence ne compte comme terminée qu'une fois validée.

## 3. `OccurrenceService`
- `ensure_occurrences(today)` : pour chaque calendrier actif, crée (idempotent) l'occurrence de la période courante et de la précédente si absente.
- `refresh(occurrence_id)` : recalcule statut + `ko_total/ko_unjudged` à partir du dernier run et des jugements. Appelé sur événements : run lancé, run terminé, jugement saisi.
- `mark_late(now)`, `close(id, user)`, `validate(id, user)` (manager/admin), `waive(id, user, reason)` (manager/admin).
- Chaque action → `activity_logs`.

## 4. Déclencheur quotidien
- Commande `python -m app.jobs.daily_occurrences` = `ensure_occurrences` + `mark_late`. Idempotente.
- Appelée au démarrage de l'API et planifiée chaque jour (CronJob OpenShift ; en local, simple appel au démarrage). Ne lance jamais de contrôle.

## 5. API
```
GET  /api/schedules                      (tous)
PUT  /api/schedules/{control_id}         (admin) → trace activity_logs
GET  /api/controls/{control_id}/occurrences?limit=24   (filtré par apply_scope)
POST /api/occurrences/{id}/close | /validate | /waive
```
`ad_hoc` : pas de génération automatique ; occurrence créée au lancement (`period_key = ADHOC-<date>`).

## 6. Tests `tests/test_occurrences.py`
Idempotence de `ensure_occurrences` ; transitions de statut ; `late` ; validation réservée au manager ; `waive` sans motif refusé.
