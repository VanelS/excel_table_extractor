# R3 — Rattacher les exécutions aux occurrences + reprise de l'existant

## 1. Exécutions
```sql
ALTER TABLE <executions> ADD COLUMN occurrence_id INTEGER REFERENCES control_occurrences(id);
CREATE INDEX IF NOT EXISTS ix_exec_occ ON <executions>(occurrence_id);
```
- `POST /api/executions` accepte `period_key` (optionnel). Absent → `default_period` du calendrier (`previous` ou `current`).
- Le service trouve ou crée l'occurrence, fige `control_version` au premier run, met `current_run_id`, appelle `refresh()`.
- Rejeu : même `occurrence_id` que le run parent.
- Contrôle sans calendrier : occurrence `ad_hoc` créée à la volée (aucune régression).
- Lancer sur une occurrence `done/validated` : autorisé, la repasse en `in_progress` et le trace.

## 2. Jugements (politique générique)
Ajouter à la table des dispositions : `valid_from_period TEXT`, `valid_until_period TEXT` (NULL = sans fin).
À la saisie d'un jugement, selon `disposition_policy` du calendrier :
- `carry_over` → `valid_until_period = NULL` (comportement actuel).
- `per_period` → `valid_until_period = valid_from_period`.
- `expire_after` → `valid_until_period = from + (N-1) périodes`.
Le calcul « KO non jugé » ne retient que les jugements valides pour la période de l'occurrence.

## 3. Reprise de l'existant — `scripts/migrate_occurrences.py`
- Entrée : `data/schedules_seed.csv` (`control_id;frequency;interval;due_offset_days;owner_name`) rempli par l'équipe. Contrôle absent du CSV → `ad_hoc`.
- Crée les `control_schedules`, puis pour chaque exécution existante : période = `Period.for_date(run_date - due_offset_days, freq)` ; crée l'occurrence, rattache le run, `refresh()`.
- Jugements existants : `valid_from_period` = période du run où ils ont été posés, `valid_until_period = NULL`.
- Options `--dry-run` (rapport CSV des rattachements) et `--control <id>`.

## 4. Tests `tests/test_runs_occurrences.py`
Lancement sans `period_key` (previous/current) ; avec `period_key` ; rejeu ; `ad_hoc` ; politique de jugement ×3 ; migration sur une base de test (`--dry-run` ne modifie rien).
