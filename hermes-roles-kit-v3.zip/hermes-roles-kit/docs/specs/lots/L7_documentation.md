# L7 — Documentation

Avant ce lot : mettre un `#` devant `DOCUMENTATION_TECHNIQUE.md` dans `.kilocodeignore`.

Ne PAS relire tout le document : chercher les titres `## ` pour trouver où insérer, puis ajouter une section « Rôles, périmètre et tableaux de bord » (≤ 80 lignes) :
- correspondance OIDC → rôles et variables d'environnement ;
- `launched_by` + script de backfill ;
- `get_scope` / `apply_scope` / `ensure_in_scope` + liste des points filtrés (reprendre le tableau de PLAN_IMPLEMENTATION.md) ;
- endpoints `/api/dashboard/*` et `/api/closing/milestones` ;
- règles de `compute_status` ;
- composants Angular ajoutés ;
- section « Contrôles périodiques » : `Frequency`/`Period`, `control_schedules` (chaque paramètre et sa valeur par défaut), `control_occurrences` et leurs statuts, job quotidien, rattachement des runs, politique de validité des jugements, script `migrate_occurrences.py`.

Dans le catalogue des outils de l'agent, ajouter une mention : « filtré par périmètre utilisateur ».

Après ce lot : enlever le `#` dans `.kilocodeignore`.
