# L0 — Cartographie (mode Architect, AUCUNE modification de code)

But : produire `docs/specs/PLAN_IMPLEMENTATION.md`, court (≤ 120 lignes), qui servira de seule carte du code aux lots suivants.

Recherche ciblée (utiliser la recherche, ne pas ouvrir les fichiers en entier) :
1. Modèle/table des exécutions + fonction(s) qui créent une exécution et un rejeu.
2. Dépendance FastAPI qui fournit l'utilisateur courant + claims OIDC disponibles + endpoint `/api/me`.
3. Tous les points qui renvoient des données d'exécution : endpoints (`@router.get|post` sur executions, results, dispositions, export, query), flux SSE, outils de l'agent LangGraph (`@tool` ou registre d'outils).
4. Stockage des étapes Planning (champ `responsable`).
5. Logique des KO non jugés (dispositions / `n_new_ko`).
6. Angular : service d'auth, fichier de routes, composant d'accueil, composant tuile KPI réutilisable, fichiers i18n FR/EN, variables de couleur.
7. Commandes de test, lint et build.
8. Où sont stockés les jugements (table dispositions, clé `identity_key`) et comment le front choisit le run affiché.
9. Mécanisme de tâche planifiée existant (CronJob OpenShift, APScheduler, aucun) et point de démarrage de l'API.
10. Toute notion existante de fréquence ou de période dans le code ou les JSON de `data/controls/`.

Format attendu de PLAN_IMPLEMENTATION.md :
```
## Back
- executions: <fichier>::<classe/table> ; création: <fichier>::<fonction> ; rejeu: ...
- user courant: ... ; /api/me: ...
- points à filtrer: (tableau fichier | fonction | type)
- planning: ...
- ko non jugés: ...
## Front
- auth: ... ; routes: ... ; accueil: ... ; tuile KPI: ... ; i18n: ... ; couleurs: ...
## Commandes
- tests / lint / build
## Fichiers par lot
- L1  L2  R1  R2  R3  R4  L3′  L4  L5  L6  R5 : fichiers à créer/modifier pour chacun
## Écarts avec la spec
```
