# Prompts Kilo Code — un lot = une nouvelle tâche

Préparation : kit à la racine de `hermes/`, maquettes PNG dans `docs/specs/maquettes/` (`controleur.png`, `manager.png`, `calendrier.png`, `occurrences.png`), branche `feat/roles-et-periodes`.
Après chaque lot : relire le diff, `git commit`, ouvrir une NOUVELLE tâche.

Gabarit : `Implémente @docs/specs/lots/<FICHIER> en t'appuyant sur @docs/specs/PLAN_IMPLEMENTATION.md`

| # | Lot | Fichier | Mode | Modèle |
|---|---|---|---|---|
| 1 | L0 Cartographie | `L0_cartographie.md` (prompt : `Exécute @docs/specs/lots/L0_cartographie.md`) | Architect | puissant |
| 2 | L1 Rôles + launched_by | `L1_roles_launched_by.md` | Code | puissant |
| 3 | L2 Périmètre ⚠️ | `L2_perimetre.md` | Code | puissant |
| 4 | R1 Périodes | `R1_periodes.md` | Code | économique (fonctions pures) |
| 5 | R2 Calendrier + occurrences | `R2_calendrier_occurrences.md` | Code | puissant |
| 6 | R3 Runs ↔ occurrences + reprise ⚠️ | `R3_runs_occurrences.md` | Code | puissant |
| 7 | R4 Planning + périmètre | `R4_planning_perimetre.md` | Code | puissant |
| 8 | L3′ Endpoints tableaux de bord | `L3_dashboard_occurrences.md` | Code | puissant |
| 9 | L4 Socle front | `L4_socle_front.md` | Code | économique |
| 10 | L5 Workboard (+ controleur.png) | `L5_workboard_controleur.md` | Code | économique |
| 11 | L6 Vue Manager (+ manager.png) | `L6_vue_manager.md` | Code | économique |
| 12 | R5 UI calendrier & occurrences (+ calendrier.png, occurrences.png) | `R5_ui_calendrier_occurrences.md` | Code | économique |
| 13 | L7 Documentation | `L7_documentation.md` (prompt : `Exécute ...`) | Code | économique |

Points de contrôle manuels :
- Après L0 : relire/corriger `PLAN_IMPLEMENTATION.md`.
- Après L2 : tester avec `HERMES_DEV_ROLE=controller` puis `manager` (API, export, Assistant global).
- Avant R3 en vrai : remplir `data/schedules_seed.csv` (fréquence de chaque contrôle) et lancer `migrate_occurrences.py --dry-run` ; relire le rapport avant de lancer sans `--dry-run`. Sauvegarder `hermes.db` avant.
- Après R4 : relancer `tests/test_scope.py`.
