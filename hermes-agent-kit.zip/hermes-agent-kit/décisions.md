# Journal des décisions — kit d'intégration de l'agent Hermes

Ce fichier consigne chaque décision prise pour construire le kit : ce qui a été choisi, pourquoi,
et ce qui reste à confirmer. Il complète la spécification (« Hermes — Spécification de l'agent
conversationnel ») ; quand le kit s'en écarte, l'écart est signalé **[Écart]**. La section 10
liste les constats de la revue indépendante et leur traitement ; la section 11, ceux de la
répétition complète de l'intégration sur un dépôt simulé.

Contexte de départ : le code de la banque n'était pas accessible. Le kit est construit à partir
de la documentation technique de HERMES (extraite de la vidéo) et de la spécification. Tout ce
que la documentation ne dit pas est tranché à l'intégration par l'étape de découverte, jamais
deviné : c'est le fil directeur des décisions ci-dessous.

---

## 1. Cadrage

**D-01 — Cible : le dépôt HERMES de la banque.** Pas le dépôt VanelS/hermes, qui n'a servi qu'à
publier la spécification. Source : consigne de l'utilisateur.

**D-02 — Livraison : un zip, intégration par Kilo Code.** Le zip contient le code backend, ses
tests, la procédure, une commande Kilo et des scripts d'outillage. Source : consigne de
l'utilisateur.

**D-03 — Périmètre : backend uniquement.** Moteur de l'agent, outils de phase 1, outils de
jugement de phase 2 (fermés tant que `HERMES_AGENT_PHASE=1`), bac à sable SQL. Le panneau
Angular n'est pas dans ce kit ; la procédure explique comment ajouter les phases 2 et 3.
Source : proposition acceptée (« ok pour le reste »).

**D-04 — Agent désactivé par défaut (`HERMES_AGENT_ENABLED=False`).** Déployer le code et ouvrir
l'agent restent deux décisions distinctes (section 13 de la spécification). Désactivé, le
routeur répond 404 et rien ne démarre.

## 2. Architecture

**D-05 — Les outils appellent l'API existante, dans le même processus.** Passerelle `httpx` +
`ASGITransport` vers l'application elle-même, plutôt qu'un appel direct aux services. Ainsi
l'authentification, le CSRF, la validation d'Origin, les rôles et le journal d'activité
s'appliquent exactement comme pour l'interface, sans dupliquer une règle métier.

**D-06 — Liste blanche de routes par outil.** La passerelle n'accepte que les couples
(méthode, gabarit) déclarés par les outils autorisés pour l'utilisateur et la phase. Chaque
identifiant inséré dans un chemin est validé en entier (`fullmatch` de
`[A-Za-z0-9_-]{1,128}`, saut de ligne final compris) puis encodé. Sont retransmis : les cookies
de session, `X-CSRF-Token`, `Origin`, `Accept-Language`. Une réponse de plus de 5 Mo est
refusée ; aucun fichier binaire ne transite par l'agent. Le délai de 60 s est imposé par la
passerelle elle-même, `ASGITransport` ignorant celui d'httpx.

**D-07 — Marque « via Hermes » par variable de contexte, jamais par en-tête HTTP.** Le graphe pose
une `ContextVar` autour de chaque appel d'outil ; le journal d'activité la lit avec
`activity_annotation()`. Un navigateur ne peut donc pas la forger. Vérifié par les tests jusque
dans une route `def` exécutée dans le pool de threads, à travers un middleware HTTP.

**D-08 — LangGraph 1.x, dépendances du tour dans le contexte d'exécution.** Passerelle, base et
utilisateur passent par `context_schema`/`Runtime`, jamais par l'état : rien de sensible n'est
écrit dans les points de reprise.

**D-09 — `interrupt()` isolé dans un nœud dédié (`await_decision`).** LangGraph réexécute le nœud
interrompu depuis son début à la reprise : rien ne doit précéder l'interruption.

**D-10 — Chaque tour tourne en tâche de fond, détachée de la connexion.** Le flux SSE ne fait
que relayer ses événements : une déconnexion du navigateur n'interrompt ni le tour ni une
action confirmée, et le panneau relit l'état par `GET /conversations/{id}`. L'exécution d'une
action est en plus protégée (`asyncio.shield`) et porte un bail renouvelé tant qu'elle tourne.
En fin de tour, le service attend la fin de l'action en cours avant de libérer le verrou, et
passe en `failed` (« non exécutée ») une action confirmée dont l'exécution n'a pas commencé.
L'entretien horaire traite les cas de redémarrage : bail expiré (« interrompue »), confirmation
restée sans exécution (« non exécutée »).

**D-11 — Tout l'état partagé est en base ; le verrou de tour appartient à son tour.** Verrou,
limite de débit, action en attente, déduplication : la production tourne avec plusieurs
workers. Le verrou porte un jeton : seul le tour qui l'a pris le renouvelle (toutes les
`HERMES_AGENT_TURN_LOCK_S`/3 secondes) et le libère. Un tour est borné par
`HERMES_AGENT_TURN_TIMEOUT_S` (300 s) ; le verrou d'un worker arrêté expire après
`HERMES_AGENT_TURN_LOCK_S` (120 s).

**D-12 — Points de reprise dans une base SQLite séparée**, `agent_checkpoints.db`, placée par
défaut à côté de `hermes.db` (`<DATA_DIR>/db/`, donc sur le même volume persistant), en mode
WAL avec `busy_timeout`, pour ne pas verrouiller `hermes.db`. Purge après 30 jours
d'inactivité ; la conversation passe alors en lecture seule. Vérifié par un test : une action
proposée avant un redémarrage se confirme après.

**D-13 — [Écart] Tables propres à l'agent.** `agent_conversations`, `agent_messages`,
`agent_tool_calls` au lieu d'étendre `ChatConversation`/`ChatMessage` : le Chat v2 et ses
modèles ORM restent intacts, et la migration n'a pas à inspecter des tables créées hors du
runner. Les jetons consommés sont enregistrés dans `agent_messages` et `agent_tool_calls`, et non
dans `llm_calls`, dont le schéma n'est pas documenté.

**D-14 — Migration v016 au SQL figé.** Le gabarit `modeles/v016_agent.py` contient une copie du
schéma (idempotent) et s'aligne à l'intégration sur la forme de `v015.py`, non documentée. Une
migration appliquée ne change plus : toute évolution passera par une v017, et `schema.sql`
décrira le schéma cumulé, utilisé par les tests. `create_schema=True` ne sert qu'aux tests et
au développement.

**D-15 — Dates en ISO 8601 UTC avec microsecondes, partout.** Les comparaisons de chaînes
(expiration, verrou, débit) et l'ordre des messages restent justes même à la seconde près.

**D-16 — Contexte de page : seul le gabarit de route entre dans le prompt.** Les identifiants et
la sélection passent par l'outil `get_page_context`, comme une donnée. Route hors liste blanche
(la table `PAGES`, D-67) ou paramètre hors motif : 422 dès l'API.

## 3. Confirmations

**D-17 — Deux niveaux.** Simple : bouton, ou réponse écrite reconnue sans le modèle (« oui »,
« ok », « confirme », « vas-y »…). Renforcé : bouton uniquement ; une réponse écrite reçoit
« Pour cette action, confirmez avec le bouton de la carte. »

**D-18 — Carte produite par le code de l'outil, jamais par le modèle.** Empreinte SHA-256 du JSON
canonique des paramètres ; seuls les champs déclarés modifiables peuvent changer ; les paramètres
soumis sont revalidés par le modèle Pydantic de l'outil en contexte « soumission », qui peut
exiger ce qui reste facultatif à la proposition (le motif d'un jugement, par exemple).

**D-19 — La version affichée sur la carte de lancement est celle qui s'exécute.** Si la version
championne change entre la proposition et la confirmation, c'est la version montrée qui part.
Une même source ne peut figurer deux fois : la carte montrerait un fichier qui ne part pas.

**D-20 — Motif d'un jugement : pris dans les mots de l'utilisateur, ou vide.** Le motif proposé
par le modèle n'est pré-rempli que s'il figure (à la ponctuation près) dans les messages
récents de l'utilisateur ; sinon il est vidé avec une alerte. Le jugement n'est jamais choisi
par le modèle : sans consigne explicite, l'utilisateur le choisit dans la carte.

**D-21 — Un nouveau message annule l'action en attente,** sauf une confirmation écrite reconnue
pour une action simple. Un événement de fin de run n'annule rien.

**D-22 — Une seule action à la fois.** Une seconde écriture dans le même tour reçoit « une action
à la fois » et n'est pas proposée.

**D-23 — Échec partiel d'un lot de jugements : statut `failed`,** avec la liste des lignes
enregistrées et celles en échec dans `result_summary_json` ; le modèle ne repropose que les
dernières, sur demande.

## 4. Modèles

**D-24 — Modèles désignés par `"<fournisseur>:<identifiant>"`.** Fournisseurs fournis : `openai`
(toute passerelle compatible OpenAI), `anthropic`, `google_genai`, plus `register_provider` pour
réutiliser les clients de `app/services/ai/`. Les identifiants exacts de GPT 5.6 Sol, Sonnet 4.6
et Gemini 3.8 Flash viennent de la configuration de la banque : la procédure interdit de les
inventer.

**D-25 — Délais du modèle.** 30 s d'attente au plus par fragment, 120 s pour l'appel entier
(`HERMES_AGENT_MODEL_TOTAL_TIMEOUT_S`), deux tentatives sur le principal, puis le secours. La
bascule n'a lieu qu'avant le premier fragment envoyé au panneau.

**D-26 — Les outils restent déclarés au modèle même hors budget.** Certains fournisseurs refusent
un historique contenant des appels d'outils sans leur définition ; hors budget, le prompt
demande une réponse et tout appel d'outil est remplacé par un texte.

**D-27 — Le modèle rapide n'est pas appelé par la boucle de conversation dans cette version.** Le
titre d'une conversation est le début du premier message, sans appel au modèle. Le modèle
rapide reste configurable et vérifié par `verifier_modeles.py` et le banc d'essai.

## 5. Outils

**D-28 — 23 outils.** 14 actifs en phase 1 ; 7 désactivés tant que la découverte n'a pas
confirmé leur route ou leur corps de requête (`check_sources`, `dry_run_control`,
`analyze_run_data`, `list_input_files`, et en phase 3 `list_workbooks`, `list_databases`,
`list_dataset_descriptors`) ; 2 de phase 2 (`create_dispositions`, `revoke_disposition`).
`get_execution_audit` et `attach_evidence` sont reportés : endpoints de l'audit non documentés,
zone de transit des pièces jointes non construite.

**D-29 — Noms de champs incertains : plusieurs noms candidats.** Là où la documentation ne donne
pas la forme d'une réponse (`ControlSummary`, liste des jugements…), les outils essaient
plusieurs noms (`first_value`) ; la découverte confirme les bons.

**D-30 — Données personnelles : nettoyage central de tout ce qui part vers le modèle.** En
attendant la décision du RSSI et du DPO (options A ou B de la section 11), chaque résultat
d'outil perd, au départ vers le modèle, les champs d'identité reconnus à leur nom quel qu'il
soit (`*mail*`, `*auteur*`, `*author*`, `*_by`, `full_name`, `login`…) et toutes les adresses
électroniques sont masquées, y compris dans les textes libres et les messages d'erreur. Les
noms de personnes contenus dans les données métier (managers de `section_setting`) ne sont pas
détectables ainsi : ils relèvent de la décision A ou B. Les cartes, affichées seulement dans
l'interface, peuvent montrer l'auteur.

**D-31 — `list_executions` lit jusqu'à 5 pages de 50 runs** et annonce « au moins N » au-delà ;
statut et période sont filtrés localement, l'API ne le fait pas.

**D-32 — `export_report` ne télécharge rien.** Il vérifie le run et renvoie une carte de
téléchargement ; l'URL n'est pas donnée au modèle, qui ne peut donc pas l'écrire lui-même.

**D-33 — `get_compliance_trend` est calculé à partir de `GET /api/executions`,** la source de la
page Analytics n'étant pas documentée.

**D-34 — `create_dispositions` vérifie chaque ligne dans le run avant la carte** (`GET /rows`
filtré par texte et règle) ; 20 lignes au plus ; contrôle et version sont pris du run et cachés
du schéma montré au modèle.

**D-35 — `open_page` prend `run_id` et `control_id` explicites** plutôt qu'un dictionnaire de
paramètres : les modèles remplissent mieux des champs nommés.

**D-36 — Bac à sable SQL, endpoint fermé par défaut.** DuckDB en mémoire ; `SELECT` unique
vérifié par `extract_statements` ; mémoire, threads, débordement disque et chargement
d'extensions bornés ; les données sont chargées, puis l'accès externe est coupé et la
configuration verrouillée ; arrêt à 10 s ou 1 000 lignes. L'endpoint est fourni comme un
constructeur de routeur à trois adaptateurs (`resolve_run`, `generate_sql`, `record_query`)
écrits à l'intégration. Il répond 404 tant que l'agent est désactivé ou l'outil
`analyze_run_data` non activé : le fusionner n'ouvre rien. L'étape 11 ne se fait que sur
demande explicite.

**D-37 — Appels d'outils au JSON illisible : réponse d'erreur, historique sain.** Un appel que
le fournisseur rend illisible (`invalid_tool_calls`) reçoit un résultat d'erreur
« arguments illisibles » ; sans cela, il resterait sans réponse dans l'historique et certains
fournisseurs refuseraient tous les tours suivants.

## 6. API et flux

**D-38 — Sept endpoints `/api/agent`.** [Écart] L'endpoint de pièces jointes de la spécification
est reporté avec `attach_evidence`. SSE par `sse-starlette`, avec `X-Accel-Buffering: no` et
`Cache-Control: no-store` pour le reverse-proxy Nginx. Codes : 404 (conversation d'un autre
utilisateur, agent désactivé), 409 (tour en cours, action déjà traitée), 422 (empreinte ou
champs refusés), 429 (débit).

**D-39 — Fragments et jetons.** `message.delta` porte l'identifiant du message du modèle, pour
regrouper les fragments. Les jetons de tous les appels au modèle d'un tour sont additionnés et
rattachés à la réponse finale, ou à l'action proposée quand le tour s'arrête sur une carte.
Derrière une passerelle, ils ne sont comptés que si elle les donne en diffusion (D-69).

**D-40 — Renvoi du navigateur (même `request_id`) : la réponse enregistrée est rejouée** sans
rappeler le modèle ; 409 si le message est encore en cours de traitement.

**D-41 — Plafond d'étapes du graphe : `2 × HERMES_AGENT_MAX_ITERATIONS + 10`,** au-dessus des
budgets du tour.

**D-42 — Limite de débit atomique ; événements de fin de run contrôlés.** Le comptage des
messages de l'utilisateur et l'insertion du nouveau forment une seule instruction : des
requêtes parallèles ne la dépassent pas. Un événement `run_completed` n'est retenu que pour un
run lancé ou rejoué par une action de la même conversation, et une seule fois ; sinon il est
ignoré, sans appel au modèle.

## 7. Tests et compatibilité

**D-43 — Banc de test autonome.** Une application HERMES factice reproduit les barrières
documentées (cookie de session, CSRF, Origin, rôles, formes de réponse) ; un modèle simulé
rejoue des réponses écrites d'avance, en fragments, avec pauses et appels illisibles au besoin.
Les tests sont synchrones et lancent leur scénario avec `asyncio.run` : ils ne dépendent ni de
pytest-asyncio ni du greffon anyio. Ils ignorent les variables `HERMES_AGENT_*` du poste.

**D-44 — Compatibilité vérifiée sur trois jeux de versions,** toute la suite de tests verte,
avertissements traités comme des erreurs :
- récent : FastAPI 0.143, Starlette 1.7, sse-starlette 3.5, langgraph 1.2.14,
  langchain-core 1.6.9, langchain-openai 1.7, pydantic 2.14 ;
- minimums documentés par la banque : langgraph 1.2.12, langchain-core 1.4.7,
  langchain-openai 1.3.3, pydantic 2.13.5, pydantic-settings 2.13.1, sse-starlette 3.4.11 ;
- ancien : FastAPI 0.115.14, Starlette 0.46.2, sse-starlette 2.4.1, langgraph 1.2.12,
  langchain-core 1.4.7.

La documentation de la banque cite FastAPI `~=0.115` et sse-starlette `~=3.4`, deux
contraintes incompatibles entre elles (Starlette) : la combinaison réellement installée est
l'une des deux dernières, et le kit fonctionne avec chacune (D-64).

**D-45 — Tests rangés dans `tests/agent/`, en paquet Python,** pour ne pas dépendre de la
configuration d'import de la suite existante. Les tests que seule l'application réelle peut
faire (protection CSRF de `/api/agent`, marque « via Hermes » dans le vrai journal) sont fournis
en gabarit, `modeles/test_integration_banque.py`, à compléter avec les fixtures de la banque.

## 8. Livraison et procédure

**D-46 — Commande Kilo dans `.kilo/commands/integrer-agent-hermes.md`,** format actuel de Kilo
Code (l'espace de travail de la banque a déjà un dossier `.kilo/`). Les anciens workflows
`.kilocode/workflows/` sont migrés automatiquement par la nouvelle extension.

**D-47 — Tout se passe dans le dépôt `hermes_back`.** L'espace de travail est un métadépôt et
`hermes_back`, `hermes_front` deux dépôts Git distincts : branche, commits, rapports
(`hermes_back/docs/agent-hermes/`) et demande de fusion vivent dans `hermes_back`. La procédure
interdit `stash`, `clean`, `reset` et `checkout -- …`.

**D-48 — Scripts d'outillage copiés dans `hermes_back/scripts/agent/`** et lancés depuis
`hermes_back` avec l'interpréteur du venv ; ils ajoutent le dossier courant au chemin d'import
et n'échouent pas sur une console Windows qui ne sait pas afficher un caractère.

**D-49 — La procédure s'arrête plutôt que de deviner.** Conditions d'arrêt : versions sous les
minimums vérifiés (langgraph 1.2, langchain-core 1.4, pydantic-settings 2.7), fichier du kit
déjà présent dans le dépôt, fichiers suivis modifiés, suite de tests déjà rouge, information
introuvable. Elle ne copie pas les trois `__init__.py` de premier niveau du kit, copie ceux de
l'agent et des tests, et ne modifie aucune route existante hormis la marque « via Hermes ».

**D-50 — Rapport d'intégration tenu par l'agent de code.** Gabarit fourni ; il sert de
description à la demande de fusion. L'agent de code y consigne ses propres décisions, avec leur
raison, à côté d'une copie de ce journal.

**D-51 — Le code propre à la banque est isolé dans un seul module, `integration.py`.** Les
fichiers du kit restent proches du kit : une version suivante se compare et s'applique
fichier par fichier, en reportant les ajustements de l'étape 8 (valeurs de `PAGES`, noms de
champs candidats, statuts, gabarits de routes) et la mise en forme du dépôt. La répétition l'a
fait une fois (D-73).

**D-52 — Modèles : réutiliser la configuration LLM existante est l'option recommandée.** Un
fournisseur « banque » écrit dans `integration.py` (`register_bank_models`) construit le client
à partir de la configuration de `app/services/ai/` : aucun nouveau secret. Il est enregistré
automatiquement au démarrage de l'agent et par les scripts (`load_integration`), qui
construisent donc les modèles de la même façon.

**D-53 — Configuration locale dans `agent.env`, jamais dans `.env`.** Un `Settings`
d'application qui refuse les clés inconnues ne démarrerait plus avec des `HERMES_AGENT_*` dans
`.env`. L'agent lit `.env` puis `agent.env` (non versionné) ; une valeur vide vaut « non
renseignée ». En déploiement, ce sont des variables d'environnement.

**D-54 — La découverte lit la table des routes sans démarrer l'application.** Elle compare les
champs que chaque outil lit ou envoie aux modèles Pydantic réels et sort en erreur (code 2) si
un outil actif par défaut n'a pas sa route. Ses indices de contrôle de rôle ne regardent que le
nom des fonctions de dépendance (jamais le chemin du module) et ne prouvent rien : la procédure
exige de lire chaque route qui modifie et d'en noter le contrôle de rôle. Elle lit aussi les
routeurs inclus paresseusement (D-63) et compare les pages de l'interface à `PAGES`, noms de
paramètres compris (D-68).

**D-55 — Essai de bout en bout sans effet.** Il ouvre la session de développement (`/api/login`
avec `IS_DEV_MODE=True`) ou réutilise des cookies, joue un tour de consultation, fait proposer
un lancement puis le refuse. Vérifié derrière un vrai serveur uvicorn : le flux SSE arrive au
fil de l'eau. Il échoue si une réponse vient du modèle de secours (D-71).

**D-56 — Banc d'essai au premier pas.** Le banc envoie au modèle le vrai prompt et les vrais
outils filtrés par rôle et phase, et compare le premier outil choisi et ses arguments, sans
appeler l'API ni envoyer de donnée de la banque. 15 cas d'exemple sont fournis ; les 80
demandes réelles restent à recueillir auprès des analystes. `verifier_modeles.py` n'envoie que
deux questions de synthèse.

**D-57 — Commandes données pour PowerShell et Bash.** L'environnement de développement de la
banque tourne sous Windows (`sync-dev.ps1`, `start.ps1`). Les variables posées pour l'essai de
bout en bout sont retirées ensuite.

**D-58 — La documentation technique de la banque n'est pas modifiée par l'intégration.** Le
texte à y ajouter est proposé dans le rapport ; l'équipe l'applique.

**D-59 — Migration avant branchement.** L'étape 5 crée les tables, l'étape 6 branche l'agent :
le test d'intégration de l'étape 6 a besoin des tables. La migration se vérifie sur une copie
de la base, deux fois de suite, jamais sur la base de production.

**D-60 — La marque « via Hermes » se lit à la création de l'entrée du journal, dans la
requête,** et ne change rien hors agent (`description` identique, `None` compris). Le journal
d'activité étant asynchrone, la lire dans le thread d'écriture la perdrait.

**D-61 — Une confirmation écrite ne vaut que si l'action attend encore sa décision dans le
graphe.** Sinon le message est traité comme une nouvelle demande et l'action annulée.

## 9. Reporté ou hors du kit

**D-62 — Non couvert par cette version, à traiter avant ou pendant l'ouverture :**
- panneau Angular (chantier séparé, dans `hermes_front`) ;
- `get_execution_audit`, `attach_evidence`, endpoint de pièces jointes ;
- trace des tours dans MLflow (la façade `app/core/tracking.py` n'est pas documentée ; à
  brancher par un callback LangChain) ;
- tâche périodique des indicateurs de production et alerte de consommation par utilisateur
  (les données sont dans `agent_tool_calls` et `agent_messages`) ;
- pseudonymisation des données personnelles (option B) : seuls le retrait et le masquage sont
  en place ;
- chiffrement au repos des points de reprise (sérialiseur chiffré de LangGraph), à décider ;
- réconciliation automatique de l'état réel après une action « interrompue » : le modèle est
  seulement invité à vérifier dans l'application avant toute nouvelle proposition.

## 10. Revue indépendante : constats et traitement

Deux relectures indépendantes ont été faites avant livraison, l'une du code (sécurité,
concurrence, LangGraph), l'autre de la procédure (exécutable par un agent de code sans autre
contexte). Chaque constat a été vérifié par une sonde ; tous ont été corrigés, et un test de
non-régression couvre chaque correction de code (`tests/agent/test_robustesse.py` pour la
plupart).

| Gravité | Constat | Traitement |
| --- | --- | --- |
| Majeur | Une action pouvait rester `confirmed` sans jamais s'exécuter si la connexion tombait avant l'exécution | D-10 : tours détachés, solde des confirmations sans suite, entretien |
| Majeur | Adresses électroniques transmises au modèle sous des noms de colonnes non prévus | D-30 : nettoyage central, masquage des adresses |
| Majeur | Deux tours pouvaient se chevaucher (verrou sans propriétaire, délais non bornés) | D-11, D-06, D-25 : jeton, renouvellement, délais imposés |
| Majeur | Un appel d'outil illisible bloquait la conversation | D-37 |
| Mineur | Verrou libéré pendant l'exécution d'une écriture après déconnexion | D-10 : attente de l'action avant libération |
| Mineur | Carte de lancement pouvant afficher une source non envoyée | D-19 : sources uniques |
| Mineur | Limite de débit contournable (événements, requêtes parallèles) | D-42 |
| Mineur | Identifiant accepté avec un saut de ligne final | D-06 : `fullmatch` |
| Mineur | Gabarit de migration incompatible avec une connexion SQLAlchemy | D-14 : les deux types de connexion |
| Bloquant | Règle des `__init__.py` contraire à l'étape de copie (agent sans outils) | D-49 ; vérification des 23 outils à l'étape 3 |
| Bloquant | Procédure écrite pour un dépôt unique, alors que l'espace de travail est un métadépôt | D-47 |
| Bloquant | Option de modèles recommandée invérifiable par les scripts | D-52 : `load_integration` |
| Majeur | Variables de l'agent dans `.env` pouvant empêcher l'application de démarrer | D-53 |
| Majeur | Extrait du journal d'activité cassant sur `description` vide, marque jamais vérifiée | D-60, D-45 : extrait corrigé, test d'intégration |
| Majeur | Endpoint SQL ouvert dès sa fusion | D-36 |
| Majeur | Indice de contrôle de rôle trompeur | D-54 |
| Majeur | Vérification de migration impossible telle qu'écrite | Étape 5 réécrite, commande testée sous PowerShell et Bash |
| Majeur | Vérifications de branchement trop faibles | D-45 : test d'intégration CSRF sur l'application réelle |
| Mineur | Numéros d'étape périmés, nombre de tests faux, minimums de version, configuration locale, emplacement de la base de reprise, caches dans le paquet, Ruff, confirmation avant `push`, encodage de la console | Corrigés (D-12, D-48, D-49, D-53, D-57) |

## 11. Répétition de l'intégration : constats et décisions

La procédure a été déroulée à la lettre, depuis le zip livré, sur un espace de travail simulé
aussi proche que possible de ce que décrit la documentation : métadépôt avec `hermes_back` et
`hermes_front` en dépôts distincts ; `create_app` avec routeurs inclus, validation d'Origin et
CORS ; `Settings` qui refuse les clés inconnues de `.env` ; migrations numérotées découvertes
par nom de fichier (fonction `migrate`, table `applied_migrations`) ; journal d'activité
asynchrone (file et thread d'écriture) ; session de développement par `/api/login` ; routes
Angular qui diffèrent de la documentation (`/controls/:id`, `/loader`, `/settings`) ; passerelle
LLM compatible OpenAI, configurée dans `app/services/ai/`, servant Chat Completions et, selon
l'essai, Responses. Étapes 1 à 10 et 12 faites ; l'étape 11 ne se fait que sur demande. Chaque
écart a été corrigé dans le kit, puis l'étape rejouée.

**D-63 — Vérifications indépendantes de la façon dont FastAPI range ses routes.** Les versions
récentes (0.143) incluent les routeurs paresseusement : `app.routes` ne contient plus les routes
une à une, et la vérification de l'étape 6 tombait en erreur. Elle lit désormais le schéma
OpenAPI, API publique valable pour toutes les versions. La découverte lit les deux formes : les
routes aplaties et les contextes effectifs des routeurs inclus (chemin complet, dépendances
cumulées, modèles de corps et de réponse). Test : routeurs imbriqués avec dépendance au niveau
du routeur.

**D-64 — sse-starlette 2 pris en charge, tests compris.** sse-starlette 2 garde un événement
global lié à la première boucle d'événements qui l'utilise ; le banc de test ouvrant une boucle
par scénario (plusieurs pour simuler un redémarrage), 61 tests sur 134 échouaient avec FastAPI
0.115.
Le banc le remet à zéro avant chaque boucle. Sans effet en production (une boucle par
processus) ni à partir de sse-starlette 3.

**D-65 — Relevé des versions tolérant aux paquets absents.** La commande de l'étape 2 affiche
« absent » au lieu d'échouer : deux dépendances ne sont installées qu'à l'étape 4.

**D-66 — La migration se vérifie par comparaison de schéma.** La commande de l'étape 5 lisait
une table `schema_migrations` que la documentation ne garantit pas (le runner simulé tenait
`applied_migrations`). `verifier_migration.py` compare, en lecture seule, les tables `agent_*`
de la copie migrée (colonnes : type, NOT NULL, défaut, clé primaire ; index : colonnes,
unicité, SQL) à celles que crée `schema.sql`, et l'étape 5 fait relever la table de suivi du
runner au lieu de la supposer.

**D-67 — Les pages de l'interface dans une seule table, `PAGES`.** Les chemins de l'interface
figuraient en dur à neuf endroits (liste blanche du contexte de page, description et
paramètres d'`open_page`, suggestion de `capabilities`, liens de cinq outils, tests) : les
aligner sur `app.routes.ts` à l'étape 8 aurait laissé des liens morts et des tests rouges.
`PAGES` (clé stable → chemin) et `PAGE_IDS` (page → identifiant porté), dans `domain.py`, en
sont la seule source ; `page_url`, `page_params` et `page_of` en dérivent ; un `PAGES` mal
modifié fait échouer le chargement ; une page retirée fait disparaître ses liens (pas de carte
« lien » vide) ; les tests sont écrits à partir de `PAGES`. Vérifié pendant la répétition :
`PAGES` aligné sur d'autres chemins, paramètre renommé compris, toute la suite reste verte.

**D-68 — Les paramètres de route de l'interface se comparent exactement.** Le panneau enverra
les gabarits de `app.routes.ts`, comparés tels quels à la liste blanche. La découverte, qui
comparait les seules formes, signale désormais une même page dont le paramètre est nommé
autrement (`/controls/:controlId` contre `/controls/:id`).

**D-69 — Jetons comptés derrière une passerelle.** langchain-openai coupe le comptage des
jetons en diffusion dès qu'une URL de passerelle est donnée : chaque tour aurait enregistré 0
jeton, sans erreur. Le fournisseur `openai` et le gabarit `integration.py` passent
`stream_usage` (`HERMES_AGENT_STREAM_USAGE`, vrai par défaut, à couper seulement si la
passerelle refuse l'option) ; `verifier_modeles.py` dit si les jetons sont comptés.

**D-70 — L'API OpenAI appelée devient un réglage explicite (`HERMES_AGENT_OPENAI_API`).**
Laissé à lui-même, langchain-openai envoie GPT 5.6 Sol vers `/responses` en version 1.7, vers
`/chat/completions` en 1.3 : l'API appelée change avec la version de la bibliothèque. Sur une
passerelle qui ne sert que Chat Completions, le modèle principal échouait (404) et le modèle de
secours répondait à sa place. `chat`, `responses` ou `auto` (par défaut, choix de
langchain-openai) ; l'étape 9 fait fixer la valeur sur ce que sert la passerelle et ce
qu'appelle déjà `app/services/ai/` ; `verifier_modeles.py` annonce l'API de chaque modèle et
oriente en cas d'échec. L'agent fonctionne avec les deux API : essai de bout en bout réussi en
Chat Completions et en Responses (contenu en blocs, appels d'outils en fragments, jetons), et
un test couvre les réponses en blocs sur deux tours.

**D-71 — Une bascule vers le modèle de secours se voit.** Le fournisseur marque le rôle du
modèle qui a répondu ; `message.completed` porte `fallback` ; l'essai de bout en bout échoue
quand une réponse vient du secours, même si la conversation aboutit (il affichait « Essai
réussi » avec un principal en panne) ; l'annexe C donne le diagnostic.

**D-72 — Le contrat SSE du panneau est écrit dans `app/api/agent.py`.** La procédure y renvoyait
l'équipe du panneau sans que le module le décrive : chaque événement, ses données, les formes de
cartes et les statuts d'action y sont listés.

**D-73 — Les tests du kit restent valables après l'intégration.** Un test supposait l'absence
d'`integration.py` et devenait faux dès l'étape 9, alors que la procédure interdit de modifier
un test : il ne dépend plus du module réel. Les autres tenaient compte de l'état intégré
(gabarit de migration absent, `PAGES` aligné, scripts dans `scripts/agent/`). Une mise à jour du
kit a été appliquée à la répétition en cours d'intégration (D-51) : fichiers recopiés, valeurs
de `PAGES` reportées, suite verte.

**D-74 — Contrôle qualité avec la configuration Ruff de la banque.** Avec les règles par défaut
de Ruff 0.16 (plus larges que les précédentes), l'étape 12 relevait 95 constats et 37 fichiers
à reformater. Le kit passe désormais ces règles et le jeu F, E, W, B, sauf B008 (`Depends` en
valeur par défaut, usage normal de FastAPI) et E501 (longueur de ligne), laissés à la convention
du dépôt ; les captures d'exception larges des scripts de diagnostic sont justifiées ; les
imports des modules d'outils sont déclarés dans `__all__`. La mise en forme du kit (88 colonnes)
se refait avec la configuration du dépôt, en commit séparé. Le contrôle des secrets vise les
fichiers de configuration : la documentation et les scripts d'essai citent
`HERMES_AGENT_ENABLED=True` normalement.

**D-75 — Gabarit `integration.py` corrigé.** Sa consigne de suppression se lisait à contresens ;
elle dit maintenant quelle fonction garder dans quel cas. L'exemple de fabrique passe
`stream_usage` et `use_responses_api`, et lit la configuration au premier tour.

**D-76 — Résultats bruts de la découverte hors du dépôt.** Le rapport Markdown se commite ; le
JSON va dans le dossier du kit, exclu du métadépôt.

| Étape | Constat | Traitement |
| --- | --- | --- |
| 2 | Relevé des versions en erreur sur un paquet pas encore installé | D-65 |
| 5 | Vérification fondée sur une table de suivi supposée (`schema_migrations`) | D-66 |
| 6 | Vérification des routes en erreur avec FastAPI récent | D-63 |
| 8 | Découverte aveugle aux routeurs inclus paresseusement | D-63 |
| 8 | Chemins de l'interface en dur à neuf endroits : alignement impossible sans casser liens et tests | D-67 |
| 8 | Paramètre de route renommé non signalé | D-68 |
| 9 | Consigne du gabarit `integration.py` à contresens | D-75 |
| 9 | GPT 5.6 Sol envoyé vers `/responses` : 404 sur une passerelle Chat Completions, bascule silencieuse | D-70, D-71 |
| 9 | Jetons à 0 en diffusion derrière une passerelle | D-69 |
| 9 | Test du kit faux après l'étape 9 | D-73 |
| 10 | Essai déclaré réussi alors que le modèle de secours répondait | D-71 |
| 12 | 95 constats Ruff, 37 fichiers à reformater, contrôle des secrets trompeur | D-74 |
| — | sse-starlette 2 (FastAPI 0.115) : 61 tests sur 134 en échec | D-64 |
| — | Contrat SSE du panneau absent du module qui devait le décrire | D-72 |

**Dernière passe, rejouée d'un bout à l'autre depuis le zip livré** (code définitif ; seul ce
journal a été complété ensuite) : étapes 1 à 10 et 12 sans écart, neuf commits dans
`hermes_back`.
- Suite existante : verte avant comme après.
- Tests : 134 du kit dans le dépôt, 138 avec ceux de la banque, 141 pour la suite complète.
- Migration : appliquée deux fois sur une copie (v016, puis rien), schéma conforme.
- Branchement : sept routes `/api/agent` ; POST refusé sans jeton CSRF (403), accepté avec (201).
- Journal d'activité : marque « via Hermes » relue dans la base, `description` inchangée hors
  agent.
- Découverte : trois écarts de pages signalés, corrigés dans `PAGES`, suite verte.
- Modèles : principal, secours et rapide vérifiés, jetons comptés.
- Essai de bout en bout réussi en Chat Completions et en Responses.
- Ruff : aucun constat hors B008 et E501 ; 39 fichiers remis en forme à 100 colonnes, en un
  commit, suite verte.

Hors du champ de la répétition : l'étape 11 (sur demande), la demande de fusion (pas de dépôt
distant), et le code réel de la banque. La répétition éprouve la procédure et le kit ; les
hypothèses H-01 à H-13 restent à confirmer sur le vrai code.

---

## Hypothèses à confirmer à l'intégration

| # | Hypothèse | Où elle est vérifiée |
| --- | --- | --- |
| H-01 | La dépendance « utilisateur courant » renvoie `sub`, `email` et `roles` (forme `CurrentUserResponse`) | Étape 6 (adaptateur `to_user_context`) |
| H-02 | Le CSRF est vérifié par une dépendance, la dépendance d'authentification ou un middleware ; la validation d'Origin est un middleware global | Étape 6 (test d'intégration) |
| H-03 | Chaque route qui modifie vérifie le rôle côté backend (prérequis de phase 0) | Étape 8, lecture de chaque route |
| H-04 | Noms des champs de `ControlSummary`, `ExecutionSummary` et de la liste des jugements | Rapport de découverte |
| H-05 | Statuts d'un run en cours : `pending`, `running` | Étape 8 |
| H-06 | `control_date` attendu au format `AAAA-MM-JJ` | Lecture de `ExecutionCreateRequest` |
| H-07 | Le paramètre `search` de `GET /rows` cherche dans `identity_key` | Étape 8 ; sinon `create_dispositions` refuse les lignes |
| H-08 | `POST /rerun` accepte un corps vide `{}` | Lecture de `RerunRequest` |
| H-09 | Les routes Angular sont celles de la section 4.1 de la documentation | `decouvrir_routes.py --front` ; écarts corrigés dans `PAGES` (étape 8) |
| H-12 | La passerelle LLM sert l'API OpenAI que langchain-openai choisit pour chaque modèle (Responses pour GPT 5.6 Sol en 1.7) | `verifier_modeles.py` ; sinon `HERMES_AGENT_OPENAI_API` (étape 9) |
| H-13 | La passerelle donne les jetons en diffusion (`stream_options.include_usage`) | `verifier_modeles.py` (« jetons en diffusion ») |
| H-10 | Le journal d'activité stocke `description` en JSON (dictionnaire) | Étape 7 (test d'intégration) |
| H-11 | Le `Settings` de l'application refuse ou accepte les clés inconnues de `.env` | Étape 1 ; décide où vont les variables locales |
