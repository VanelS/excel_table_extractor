# Kit d'intégration de l'agent Hermes — backend

Implémentation Python de l'agent conversationnel Hermes décrit dans la spécification
(« Hermes — Spécification de l'agent conversationnel »), prête à être intégrée dans le dépôt
`hermes_back` de HERMES par un agent de code. Elle couvre la phase 1 (consulter, lancer,
rejouer) et prépare la phase 2 (juger, révoquer), fermée par défaut.

## Utilisation avec Kilo Code

1. Décompresser le zip à la racine de l'espace de travail HERMES : le dossier
   `hermes-agent-kit/` apparaît à côté de `hermes_back/` et `hermes_front/`.
2. Copier `hermes-agent-kit/.kilo/commands/integrer-agent-hermes.md` dans le dossier
   `.kilo/commands/` de l'espace de travail. (Ancienne extension Kilo : `.kilocode/workflows/`,
   commande `/integrer-agent-hermes.md`.)
3. Dans Kilo Code, lancer `/integrer-agent-hermes`. L'agent suit `PROCEDURE_INTEGRATION.md`
   étape par étape, travaille sur une branche de `hermes_back`, s'arrête quand une information
   manque et tient un rapport dans `hermes_back/docs/agent-hermes/rapport-integration.md`.

Sans Kilo, la procédure se suit à la main : elle est écrite pour un développeur autant que pour
un agent.

## Ce que contient le kit

| Élément | Contenu |
| --- | --- |
| `hermes_back/app/services/agent/` | Moteur LangGraph, passerelle API interne, confirmations, persistance, 23 outils |
| `hermes_back/app/api/agent.py` | Sept endpoints `/api/agent` (conversations, messages en SSE, décisions) |
| `hermes_back/app/services/run_query.py` | Bac à sable SQL DuckDB en lecture seule et son routeur, fermé par défaut |
| `hermes_back/tests/agent/` | 134 tests sur une application HERMES factice et un modèle simulé |
| `outils/` | Découverte des routes, vérification de la migration, vérification des modèles, essai de bout en bout, banc d'essai |
| `modeles/` | Gabarits : migration v016, adaptateurs `integration.py`, tests d'intégration côté banque, rapport |
| `PROCEDURE_INTEGRATION.md` | La procédure, en douze étapes et quatre annexes |
| `décisions.md` | Toutes les décisions de conception, les corrections issues de la revue et les hypothèses à vérifier |
| `requirements-agent.txt`, `agent.env.example` | Dépendances et variables `HERMES_AGENT_*` |

## Principes

- **Les outils appellent l'API existante**, dans le même processus, avec la session de
  l'utilisateur : authentification, CSRF, Origin, rôles et journal d'activité s'appliquent comme
  pour l'interface. Aucune règle métier n'est dupliquée.
- **Aucune écriture sans carte.** Une écriture devient une action proposée, affichée en carte
  produite par le code, puis exécutée telle que l'utilisateur l'a confirmée.
- **Un tour va au bout même si le navigateur se déconnecte.** Il tourne en tâche de fond ; le
  flux SSE ne fait que relayer ses événements, et le panneau relit l'état de la conversation.
- **Rien n'est deviné.** Ce que la documentation technique ne précise pas (noms de champs,
  corps de requête, routes non documentées) se confirme à l'intégration par la découverte ; les
  outils dont la route n'est pas documentée sont livrés désactivés.
- **Désactivé par défaut.** Déployer le code et ouvrir l'agent restent deux décisions.

## Faire tourner les tests du kit seul

Avec Python 3.12 et les dépendances de `requirements-agent.txt` (plus `fastapi` et `pytest`) :

```bash
cd hermes-agent-kit/hermes_back
python -m pytest tests/agent -q
```

Vérifié sur trois jeux de versions, avertissements traités comme des erreurs : les minimums
documentés par la banque (langgraph 1.2.12, langchain-core 1.4.7, pydantic 2.13,
pydantic-settings 2.13.1, sse-starlette 3.4), FastAPI 0.115 avec sse-starlette 2.4, et des
versions récentes (FastAPI 0.143). Avant livraison :
- une revue indépendante du code et de la procédure ; ses constats et leurs corrections sont
  dans `décisions.md` (section 10) ;
- une répétition complète de l'intégration depuis le zip, étapes 1 à 10 et 12, sur un dépôt
  `hermes_back` simulé (métadépôt, routeurs inclus, `Settings` strict, migrations numérotées,
  journal d'activité asynchrone, routes Angular différentes de la documentation, passerelle
  LLM compatible OpenAI) ; ce qu'elle a corrigé est dans `décisions.md` (section 11).

## Écarts avec la spécification

Détaillés dans `décisions.md` :
- tables propres à l'agent (`agent_*`) au lieu d'étendre `ChatConversation` et `ChatMessage` ;
  jetons enregistrés dans ces tables plutôt que dans `llm_calls` ;
- `get_execution_audit`, `attach_evidence` et l'endpoint de pièces jointes reportés ;
- titre de conversation tiré du premier message, sans appel au modèle rapide.

## Et ensuite

- Le panneau Angular (section 9 de la spécification), dans `hermes_front`, consomme les
  endpoints et les événements SSE de `app/api/agent.py`.
- Avant d'activer l'agent : les prérequis de la phase 0 (section 13 de la spécification) et les
  points ouverts du rapport d'intégration.
