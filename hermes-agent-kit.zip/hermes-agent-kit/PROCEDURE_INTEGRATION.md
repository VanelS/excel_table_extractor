# Procédure d'intégration de l'agent Hermes

Destinataire : l'agent de code (Kilo Code) qui intègre le kit dans HERMES, ou le développeur
qui le guide. La procédure se suit dans l'ordre ; chaque étape se termine par une vérification
et un commit. La commande Kilo `/integrer-agent-hermes` la déroule.

Ce que le kit apporte : le moteur de l'agent (LangGraph), 23 outils qui appellent l'API
existante, sept endpoints `/api/agent`, un bac à sable SQL, leurs tests (sur une application
factice) et des scripts d'outillage. Ce qu'il n'apporte pas : le panneau Angular.

Le kit a été écrit à partir de la documentation technique, sans accès au code. Tout ce que la
documentation ne dit pas se constate dans le code pendant l'intégration ; rien ne se devine.

---

## 0. Règles, à respecter à chaque étape

1. **Ne rien inventer.** Nom de dépendance, chemin, champ d'API, identifiant de modèle, URL :
   tout se lit dans le code ou la configuration. Introuvable : s'arrêter, écrire la question
   dans le rapport (section 8) et la poser au développeur.
2. **Ne jamais écraser un fichier existant.** Un fichier du kit qui existe déjà dans le dépôt :
   s'arrêter. Ne pas copier `app/__init__.py`, `app/api/__init__.py` ni `app/services/__init__.py`
   du kit (ils ne servent qu'à le faire tourner seul) ; ceux de `app/services/agent/`,
   `app/services/agent/tools/` et `tests/agent/` sont **indispensables** et se copient.
3. **Ne modifier aucune route existante.** Seule exception : la marque « via Hermes » du journal
   d'activité (étape 7). Une route qui ne vérifie pas le rôle se signale ; elle ne se corrige
   pas sans accord.
4. **L'agent reste désactivé** (`HERMES_AGENT_ENABLED=False`) dans tout ce qui est commité.
   Aucun secret, aucune URL de production, aucun identifiant de modèle inventé dans le code,
   la configuration versionnée ou les commits.
5. **Dépôts.** La racine de l'espace de travail est un métadépôt ; `hermes_back` et
   `hermes_front` sont deux dépôts Git distincts. Ce kit ne touche que **`hermes_back`** :
   branche, commits et demande de fusion s'y font (`git -C hermes_back …`). Ne jamais lancer
   `git stash`, `git clean`, `git reset` ni `git checkout -- …` : signaler l'état et s'arrêter.
6. **Commandes backend : depuis `hermes_back`, avec l'interpréteur du venv.**
   - Windows (PowerShell) : `.\.venv\Scripts\python.exe …` ;
   - Linux, macOS : `.venv/bin/python …` ;
   - ou activer le venv (`.\.venv\Scripts\Activate.ps1`, `source .venv/bin/activate`) puis `python …`.
   Dans la suite, `python` désigne cet interpréteur.
7. **Demander confirmation** avant `pip install`, la suite de tests complète, tout démarrage de
   l'application, `git push` et l'ouverture de la demande de fusion.
8. **Tenir le rapport** `hermes_back/docs/agent-hermes/rapport-integration.md` (gabarit :
   `KIT/modeles/rapport-integration.md`). Chaque décision prise pendant l'intégration y est
   consignée avec sa raison (section 4 du rapport).
9. **Un commit par étape**, message en français préfixé `agent-hermes :`.
10. **Ne jamais affaiblir un test** pour le faire passer. Si l'application factice des tests
    diffère de l'API réelle, c'est la factice qu'on aligne sur le réel, et on le consigne.
11. **L'étape 11 (endpoint SQL) ne se fait que sur demande explicite** du développeur.

Dans la suite, `KIT` désigne le dossier `hermes-agent-kit/` décompressé à la racine de l'espace
de travail, à côté de `hermes_back/` et `hermes_front/`.

---

## 1. Préparer

**Actions**

1. Si la racine de l'espace de travail est elle-même un dépôt Git, ajouter
   `hermes-agent-kit/` à son `.git/info/exclude` : le kit n'est jamais commité.
2. Vérifier qu'aucun fichier **suivi** de `hermes_back` n'est modifié :
   `git -C hermes_back status --porcelain --untracked-files=no` doit être vide. Sinon,
   s'arrêter et le signaler (règle 5).
3. Créer la branche : `git -C hermes_back switch -c feat/agent-hermes` (depuis la branche
   d'intégration habituelle).
4. Créer `hermes_back/docs/agent-hermes/` ; y copier `KIT/modeles/rapport-integration.md` sous
   le nom `rapport-integration.md` et `KIT/décisions.md` (journal des décisions du kit).
5. Lancer la suite de tests backend existante (avec confirmation) et noter le résultat dans le
   rapport (section 6). **S'arrêter** si elle est déjà rouge : ne pas corriger les tests des autres.
6. Lire, sans rien modifier, et remplir la section 1 du rapport (fichier et ligne pour chaque
   besoin) :
   - `AGENTS.md` ;
   - `hermes_back/app/api/app.py` : `create_app`, cycle de vie, middlewares, `include_router` ;
   - `hermes_back/app/api/deps.py` : utilisateur courant, session de base, CSRF ;
   - `hermes_back/app/core/config.py` : réglages, `DATA_DIR`, et la politique `extra` du
     `Settings` (refuse-t-il les clés inconnues de `.env` ?) ;
   - `hermes_back/app/core/database.py` : moteur SQLAlchemy de `hermes.db` ;
   - `hermes_back/app/core/migrations/runner.py` et `versions/v015.py` ;
   - `hermes_back/app/infrastructure/activity_logger.py` ;
   - `hermes_back/app/services/ai/` et `app/api/ai_sql.py` ;
   - `hermes_back/app/api/executions.py` et `app/core/repository.py` (lecture des lignes d'un run) ;
   - `hermes_back/requirements.txt` (ou `pyproject.toml`), et la configuration de pytest et Ruff.

**Vérification** : section 1 du rapport remplie, sans case « ? ». **Commit** : le rapport initial.

---

## 2. Vérifier les versions

**Actions** : relever les versions installées et remplir la section 2 du rapport.

```bash
python -c "import sys, importlib.metadata as m; print(sys.version); [print(p, (lambda d: d.version if d else 'absent')(next(iter(m.distributions(name=p)), None))) for p in ('fastapi', 'langgraph', 'langchain-core', 'pydantic', 'pydantic-settings', 'sse-starlette', 'httpx', 'duckdb', 'SQLAlchemy', 'langgraph-checkpoint-sqlite', 'langchain-openai')]"
```

`absent` est normal pour `langgraph-checkpoint-sqlite` et `langchain-openai` : l'étape 4 les
ajoute.

**S'arrêter si** une version est sous le minimum requis : Python 3.12, langgraph 1.2,
langchain-core 1.4, pydantic-settings 2.7, sse-starlette 2. Monter langgraph ou langchain-core
touche aussi le pipeline de contrôle : c'est une décision d'équipe.

La suite de tests du kit passe entière, avertissements traités comme des erreurs, avec FastAPI
0.115 (Starlette 0.46, sse-starlette 2.4) et FastAPI 0.143 (Starlette 1.7, sse-starlette 3.4
et 3.5), langgraph 1.2.12 et 1.2.14, langchain-core 1.4.7 et 1.6.9. Une version installée
différente de celles-ci, mais au-dessus des minimums, ne bloque pas : la noter dans le
rapport, l'étape 4 la validera.

---

## 3. Copier les fichiers du kit

Copier avec les outils de fichiers, après avoir vérifié que **chaque destination n'existe pas** :

| Source (`KIT/…`) | Destination |
| --- | --- |
| `hermes_back/app/services/agent/` (dossier entier, `__init__.py`, `tools/` et `schema.sql` compris) | `hermes_back/app/services/agent/` |
| `hermes_back/app/api/agent.py` | `hermes_back/app/api/agent.py` |
| `hermes_back/app/services/run_query.py` | `hermes_back/app/services/run_query.py` |
| `hermes_back/tests/agent/` (dossier entier, `__init__.py` compris) | `hermes_back/tests/agent/` |
| `outils/*.py` et `outils/banc/` | `hermes_back/scripts/agent/` |

Ne copier ni `__pycache__/` ni autre dossier de cache s'il en apparaît.

**Vérification** : les imports, et les 23 outils chargés.

```bash
python -c "import app.services.agent.wiring, app.api.agent, app.services.run_query; from app.services.agent.registry import load_tools; n = len(load_tools()); assert n == 23, n; print(n, 'outils')"
```

**Commit** : `agent-hermes : ajout du code de l'agent (désactivé)`.

---

## 4. Dépendances

**Actions**

1. Comparer `KIT/requirements-agent.txt` au fichier de dépendances. Ajouter seulement ce qui
   manque, **dans la convention du fichier** : épinglé à la main (`~=`, `>=`), ajouter les
   lignes à la main ; produit par `pip freeze`, installer puis régénérer.
2. `httpx` devient une dépendance d'exécution (passerelle interne) : s'il n'était qu'en
   dépendance de test, le déplacer.
3. Installer (avec confirmation) : `python -m pip install -r requirements.txt`.
4. Noter les nouvelles dépendances dans le rapport : elles passent par l'audit SCA
   (CxSCA / Nexus IQ) du pipeline.

**Vérification** : les tests du kit passent, sans l'application de la banque.

```bash
python -m pytest tests/agent -q
```

Attendu : 134 tests réussis. Un échec ici vient de l'environnement (version, dépendance,
configuration de pytest) : le corriger ou s'arrêter, jamais modifier le test.

**Commit** : `agent-hermes : dépendances`.

---

## 5. Migration v016

**Actions**

1. Lire `runner.py` : comment les migrations sont déclarées, comment les appliquer à une base
   donnée (commande, fonction, variable `DATA_DIR`…) et dans quelle table il enregistre celles
   déjà appliquées.
2. Copier `KIT/modeles/v016_agent.py` en `hermes_back/app/core/migrations/versions/v016.py`,
   puis **l'aligner sur `v015.py`** : nom et signature de la fonction, constantes, déclaration
   au runner, docstring (remplacer l'en-tête « GABARIT »). Garder le SQL tel quel : il est figé
   dans le fichier, et une migration appliquée ne change plus. Toute évolution future passera
   par une v017.
3. Si le runner tient une liste des migrations, y ajouter v016.

**Vérification** : sur une **copie** de la base de développement (jamais la base de production) :

1. y appliquer les migrations **deux fois**, de la façon relevée au point 1 ; la seconde ne
   doit rien appliquer ;
2. comparer son schéma à celui du code :

   ```bash
   python scripts/agent/verifier_migration.py <chemin de la copie>
   ```

   Attendu : `Schéma de l'agent conforme à schema.sql : 3 tables, 7 index.` Un écart vient de
   l'alignement : revenir au SQL du gabarit, ne jamais modifier `schema.sql` ;
3. lire la table où le runner enregistre les migrations appliquées (relevée au point 1) : la
   version 16 y figure une seule fois.

**Commit** : `agent-hermes : migration v016`.

---

## 6. Brancher l'agent dans `create_app`

**Actions**

1. **Utilisateur courant.** Lire ce que renvoie la dépendance relevée en section 1.
   - Un objet ou un dictionnaire avec `sub`, `email` et `roles` (forme `CurrentUserResponse`) :
     `default_user_mapper` suffit.
   - Autre forme : copier `KIT/modeles/integration.py` en
     `hermes_back/app/services/agent/integration.py`, écrire `to_user_context`, supprimer les
     fonctions inutiles.
2. **CSRF.** Trois cas, à identifier dans le code :
   - une dépendance FastAPI séparée : la passer en `csrf_dependency` ;
   - un contrôle fait dans la dépendance d'authentification elle-même (la documentation le
     place dans cette couche) : ne rien passer ;
   - un middleware global : ne rien passer.
   Vérifier que le nom de l'en-tête CSRF de l'application figure dans
   `HERMES_AGENT_FORWARD_HEADERS` (par défaut `x-csrf-token,origin,accept-language`).
3. **Cycle de vie.** Dans le cycle de vie existant de `create_app`, autour du `yield` :

   ```python
   from app.services.agent.wiring import agent_lifespan, include_agent_router

   async with agent_lifespan(app, engine=<moteur de hermes.db>, data_dir=<DATA_DIR des réglages>):
       yield
   ```

   - Le moteur existant, jamais un second moteur sur `hermes.db`.
   - `data_dir` place la base de reprise `agent_checkpoints.db` à côté de `hermes.db`, donc sur
     le même volume persistant en production.
   - Si l'application utilise `@app.on_event("startup"/"shutdown")` au lieu d'un `lifespan`,
     ouvrir le contexte avec un `contextlib.AsyncExitStack` au démarrage, le fermer à l'arrêt.
4. **Routeur**, après les autres `include_router` :

   ```python
   include_agent_router(
       app,
       current_user=<dépendance utilisateur courant>,
       to_user_context=<integration.to_user_context, si écrite ; sinon omettre>,
       csrf_dependency=<dépendance CSRF, ou omettre>,
   )
   ```
5. **Hôte et HTTPS.** La passerelle appelle l'application avec l'hôte de
   `HERMES_AGENT_INTERNAL_BASE_URL` (`http://hermes.internal`). Avec un `TrustedHostMiddleware`
   ou une redirection HTTPS, choisir une valeur acceptée et la consigner.
6. **Test d'intégration.** Copier `KIT/modeles/test_integration_banque.py` en
   `hermes_back/tests/agent/test_integration_banque.py` et compléter la partie « create_app »
   avec les fixtures de la suite existante (base de test migrée à l'étape 5, session,
   jeton CSRF).

**Vérification**

```bash
python -c "from app.api.app import create_app; s = create_app().openapi(); print(sorted(f'{m.upper()} {p}' for p, ops in s['paths'].items() if p.startswith('/api/agent') for m in ops))"
python -m pytest tests/agent -q
```

La commande lit le schéma OpenAPI et non `app.routes` : les versions récentes de FastAPI
incluent les routeurs paresseusement, et `app.routes` ne contient alors plus les routes une à
une.

Attendu : les sept routes `/api/agent/…` (`GET capabilities`, `GET` et `POST conversations`,
`GET conversations/{conversation_id}`, `POST …/messages`, `POST …/decision`,
`POST …/archive`) ; tous les tests verts, y compris
`test_agent_routes_follow_the_application_security` : agent activé, un `POST` sans jeton CSRF
est refusé (403), avec jeton il passe (201). Ce test est la seule preuve que l'agent hérite bien
de la protection de l'application. Agent désactivé, `/api/agent/*` répond 404 : c'est voulu.

**Commit** : `agent-hermes : branchement dans create_app (désactivé par défaut)`.

---

## 7. Marque « via Hermes » dans le journal d'activité

**Actions** : dans `activity_logger.py`, là où une entrée est **créée** (dans la requête), ajouter
la marque à `description` :

```python
from app.services.agent.context import activity_annotation

mark = activity_annotation()
if mark:
    description = {**(description or {}), **mark}
```

Points d'attention :
- Hors agent, `activity_annotation()` renvoie `{}` : la `description` reste strictement
  identique, `None` compris.
- La marque vient d'une variable de contexte posée pendant l'appel d'outil. Le journal étant
  asynchrone, elle se lit **au moment où l'entrée est créée dans la requête**, pas dans le thread
  ou la tâche qui écrit en base plus tard, où elle serait vide.
- Si `description` est une chaîne et non un dictionnaire, ajouter les mêmes champs dans le
  format existant, et consigner la décision.

**Vérification** : compléter la partie « journal d'activité » de
`tests/agent/test_integration_banque.py` (fonction réelle du journal, entrée relue), puis
`python -m pytest tests/agent -q`. Le journal ne trace que les actions réglementaires : l'essai
de bout en bout de l'étape 10 ne suffit pas à le vérifier.

**Commit** : `agent-hermes : marque « via Hermes » dans le journal d'activité`.

---

## 8. Découverte et ajustement du catalogue

**Actions**

1. Lancer la découverte :

   ```bash
   python scripts/agent/decouvrir_routes.py --app app.api.app:create_app --factory --front ../hermes_front/src/app/app.routes.ts --sortie docs/agent-hermes/rapport-decouverte.md --json ../hermes-agent-kit/decouverte.json
   ```

   Le rapport Markdown se commite ; le JSON (résultats bruts) reste hors du dépôt. Si
   `create_app` exige des arguments, écrire un petit module qui construit l'application et
   passer `--app module:app` sans `--factory`.
2. Lire le rapport et traiter, dans l'ordre :
   1. **Route absente** pour un outil actif par défaut : chercher la route réelle dans le code.
      Même chemin avec d'autres noms de paramètres : rien à faire. Autre chemin : corriger le
      gabarit dans le module de l'outil (déclaration `routes=` **et** appel `gateway.call`).
      Aucune route : désactiver l'outil (`HERMES_AGENT_DISABLED_TOOLS`).
   2. **Champs lus** (« logique → champ réel ») : pour un champ « absent », trouver son vrai
      nom dans le modèle de réponse ou la fonction, puis l'ajouter aux noms candidats de
      `tools/_common.py` (`_CONTROL_FIELDS`, `_RUN_FIELDS`) ou de `tools/dispositions.py`.
   3. **Corps envoyés** : « champs inconnus du modèle » ou « obligatoires non envoyés » : aligner
      le corps de l'outil sur le modèle réel (par exemple le format de `control_date`).
   4. **Contrôle de rôle** : pour **chaque route qui modifie** appelée par un outil, lire la
      fonction et noter dans le rapport le fichier et la ligne du contrôle de rôle, **quoi que
      dise l'indice du rapport** (il ne regarde que les noms des dépendances). Sans contrôle :
      section 8 du rapport, prérequis de phase 0. Ne pas corriger sans accord.
   5. **Statuts d'un run** : relever les valeurs réelles (en cours, terminé, en échec) et
      ajuster `RUNNING_STATUSES` dans `tools/_common.py`.
   6. **Pages de l'interface** : la table `PAGES` de `domain.py` est le seul endroit du kit où
      figurent les chemins de l'interface (liste blanche du contexte de page, outil
      `open_page`, liens des cartes, tests). En corriger les **valeurs** pour qu'elles
      reprennent exactement les chemins complets de `app.routes.ts`, **noms de paramètres
      compris** (`/controls/:id` si l'interface l'écrit ainsi) : le panneau enverra ces
      gabarits, comparés tels quels. Ne jamais changer les clés. Une page que l'interface
      n'a pas : retirer son entrée (ses liens disparaissent des cartes). Le rapport liste les
      trois cas ; pour un chemin enfant, le reconstituer avec celui de son parent. Les tests
      du kit sont écrits à partir de `PAGES` : ils passent avant comme après.
   7. **Paramètre `search` de `GET /rows`** : vérifier qu'il cherche dans `identity_key`, sinon
      adapter `_find_row` dans `tools/dispositions.py` (sans quoi les jugements seront refusés).
   8. **Outils désactivés par défaut** : `check_sources`, `dry_run_control` et
      `list_input_files` (phase 1) ; pour chacun dont la route existe, lire le modèle de corps,
      adapter l'outil, ajouter la route à l'application factice et un test, puis l'activer par
      `HERMES_AGENT_ENABLED_TOOLS`. Les outils du chargeur (`list_workbooks`, `list_databases`,
      `list_dataset_descriptors`) sont de phase 3 : les activer n'a d'effet qu'avec
      `HERMES_AGENT_PHASE=3`. Tout cela peut attendre une itération : le consigner.
3. Toute modification d'un outil : aligner l'application factice (`tests/agent/fake_hermes.py`)
   sur l'API **réelle**, puis relancer `python -m pytest tests/agent -q`.

**Vérification** : relancer la découverte ; plus aucun outil actif sans route ; section 5 du
rapport remplie.

**Commit** : `agent-hermes : catalogue aligné sur l'API réelle`.

---

## 9. Modèles

**Actions**

1. Lire `app/services/ai/` : comment l'application appelle les modèles (passerelle, URL,
   authentification, identifiants de GPT 5.6 Sol, Claude Sonnet 4.6 et Gemini 3.8 Flash), et
   quelle API OpenAI elle appelle pour chacun : Chat Completions (`chat.completions`,
   `/chat/completions`) ou Responses (`responses`, `/responses`).
2. Choisir, et consigner :
   - **A. Réutiliser la configuration existante (recommandé)** : écrire `register_bank_models`
     dans `integration.py` (gabarit fourni). Elle est appelée automatiquement au démarrage de
     l'agent et par les scripts ; elle ne construit aucun client, seulement une fabrique
     utilisée au premier tour. Puis `HERMES_AGENT_MODEL=banque:<identifiant exact>`. Aucun
     nouveau secret.
   - **B. Passerelle compatible OpenAI dédiée** : `HERMES_AGENT_MODEL=openai:<identifiant>`,
     `HERMES_AGENT_OPENAI_BASE_URL`, clé dans le coffre de secrets.
   - **C. Un SDK par fournisseur** : `anthropic:` ou `google_genai:`, avec le paquet LangChain
     correspondant (étape 4).
3. **API OpenAI** (options A et B). Laissé à lui-même, langchain-openai choisit l'API selon le
   modèle **et selon sa propre version** : GPT 5.6 Sol passe par `/responses` en 1.7, par
   `/chat/completions` en 1.3. Une montée de version pourrait donc changer l'API appelée. Fixer
   `HERMES_AGENT_OPENAI_API` à `chat` ou `responses`, l'API que la passerelle sert et que
   `app/services/ai/` appelle déjà ; `auto` seulement si la passerelle sert les deux. Si les
   modèles exigent des API différentes, choisir dans la fabrique de `integration.py` selon
   `model_id`, et le consigner.
4. Rôles des modèles (section 8 de la spécification) : principal et secours départagés par le
   banc d'essai ; rapide a priori Gemini 3.8 Flash. Sans résultat du banc, mettre le candidat
   proposé par l'équipe et le noter « provisoire ».
5. **Configuration.**
   - Déploiements : variables d'environnement (valeurs Helm), avec `HERMES_AGENT_ENABLED=False`.
     Reporter la liste de `KIT/agent.env.example` dans les modèles d'environnement du dépôt.
   - Poste de développement : `hermes_back/agent.env`, lu par l'agent seul, et ajouté au
     `.gitignore` de `hermes_back`. **Pas dans `.env`** si le `Settings` de l'application refuse
     les clés inconnues (section 1) : il ne démarrerait plus.

**Vérification** (poste de développement, avec confirmation) :

```bash
python scripts/agent/verifier_modeles.py
```

Attendu, pour chaque modèle renseigné : l'API OpenAI annoncée est celle du point 3, réponse
simple, appel d'outil `list_executions` reconnu, diffusion, et « jetons en diffusion :
comptés » ; résumé « principal OK ». Noter les latences. En cas d'écart :
- échec 404 d'un modèle en API Responses : la passerelle ne sert pas `/responses` (point 3) ;
- « NON COMPTÉS » : la passerelle ignore `stream_options`, ou la fabrique de `integration.py`
  ne passe pas `stream_usage` ; sinon les jetons de l'agent seront enregistrés à 0. Le
  corriger, ou le consigner si la passerelle ne peut pas les donner.

**Commit** : `agent-hermes : configuration des modèles`.

---

## 10. Essai de bout en bout en développement

**Actions** (avec confirmation) :

1. Démarrer l'application comme d'habitude (`start.ps1` ou la commande uvicorn du dépôt), en
   développement, avec `IS_DEV_MODE=True` et `HERMES_AGENT_ENABLED=True` **pour cette session
   seulement** :
   - PowerShell : `$env:IS_DEV_MODE="True"; $env:HERMES_AGENT_ENABLED="True"; <commande>`
   - Bash : `IS_DEV_MODE=True HERMES_AGENT_ENABLED=True <commande>`
2. Dans un autre terminal (depuis `hermes_back`) :

   ```bash
   python scripts/agent/essai_agent.py --base http://localhost:8000 --origin http://localhost:4200 --connexion-dev --avec-action --controle section_setting
   ```

   Le script ouvre la session de développement, lit les capacités, joue un tour de
   consultation, fait proposer un lancement puis **le refuse** : rien n'est exécuté.
3. Arrêter l'application. En PowerShell, retirer les variables, qui restent sinon dans le
   terminal : `Remove-Item Env:IS_DEV_MODE, Env:HERMES_AGENT_ENABLED`.

**Vérification** : « Essai réussi. » Résultats dans la section 7 du rapport. L'essai échoue
aussi quand une réponse vient du modèle de secours : la conversation aboutit, mais le modèle
principal est en échec ; revenir à l'étape 9.

---

## 11. Bac à sable SQL (`analyze_run_data`) — sur demande explicite seulement

**Actions**

1. Dans `integration.py`, écrire `resolve_run`, `generate_sql` et `record_query` en
   **réutilisant** le code de `GET /rows`, de `ai_sql.py` et du modèle `GeneratedSqlQuery`
   (les docstrings du gabarit disent quoi lire).
2. Dans `create_app` :

   ```python
   from app.services.run_query import build_run_query_router
   from app.services.agent import integration

   app.include_router(build_run_query_router(
       current_user=<dépendance utilisateur courant>,
       csrf_dependency=<dépendance CSRF, ou omettre>,
       resolve_run=integration.resolve_run,
       generate_sql=integration.generate_sql,
       record_query=integration.record_query,
   ))
   ```

   L'endpoint répond 404 tant que l'agent est désactivé ou que l'outil n'est pas activé : le
   fusionner n'ouvre rien.
3. Ajouter un test avec un vrai petit parquet (modèle : `tests/agent/test_run_query.py`).
4. Pour l'ouvrir en développement : `HERMES_AGENT_ENABLED_TOOLS=analyze_run_data`.

**Vérification** : un `POST /api/executions/{run_id}/query` en développement renvoie des lignes ;
une requête qui tenterait de lire un fichier échoue en 422.

**Commit** : `agent-hermes : endpoint d'analyse SQL en lecture seule`.

---

## 12. Contrôle qualité et livraison

**Actions**

1. `ruff check` puis `ruff format --check` sur les fichiers ajoutés, avec la configuration du
   dépôt.
   - Le kit passe les règles par défaut de Ruff 0.16 et les règles F, E, W, B, sauf deux :
     B008 (`Depends(...)` en valeur par défaut, l'usage normal de FastAPI) et E501 (longueur
     de ligne : 74 lignes de texte du prompt, de SQL ou de docstring dépassent 100 colonnes).
     Si le dépôt signale l'une d'elles, reprendre la convention qu'il applique à
     son propre code (`extend-immutable-calls`, exclusion par fichier, chaînes coupées sans
     en changer le contenu…) ; ne jamais désactiver une règle pour tout le dépôt.
   - Mise en forme : le kit est formaté à 88 colonnes. Si `ruff format --check` le signale,
     lancer `ruff format` sur les fichiers ajoutés et commiter ce changement mécanique seul
     (`agent-hermes : mise en forme selon la configuration du dépôt`).
2. Suite de tests backend complète (avec confirmation) : même résultat qu'en étape 1, plus les
   tests du kit et ceux ajoutés pendant l'intégration.
3. Vérifier qu'aucun fichier de configuration commité (`.env*`, `*.toml`, `*.ini`, `*.yaml`,
   valeurs Helm…) n'active l'agent (`HERMES_AGENT_ENABLED` à `True`) ou ne contient une clé,
   une URL de production ou un identifiant de modèle inventé, et que `agent.env` n'est pas
   suivi (`git -C hermes_back ls-files agent.env` ne renvoie rien). Les mentions de
   `HERMES_AGENT_ENABLED=True` dans la documentation et les scripts d'essai sont normales.
4. Compléter le rapport : sections 3 à 9. En section 9, **proposer** (sans l'appliquer) le
   texte à ajouter à `DOCUMENTATION_TECHNIQUE.md`.
5. Avec confirmation : pousser la branche de `hermes_back` et ouvrir la demande de fusion, avec
   le rapport comme description. Y rappeler ce qui reste à décider avant d'activer l'agent :
   section 8 du rapport et section 14 de la spécification.

Le panneau Angular est un chantier séparé, dans le dépôt `hermes_front` : il consomme les sept
endpoints et les événements SSE décrits dans `app/api/agent.py` et la section 10 de la
spécification.

---

## Annexe A — Ajouter un outil

1. Choisir le module de `app/services/agent/tools/` selon le domaine, ou en créer un,
   l'importer dans `tools/__init__.py` et l'ajouter à son `__all__`.
2. Écrire le modèle d'arguments : identifiants avec `pattern=ID_PATTERN`, descriptions en
   français dans le vocabulaire métier, aucun champ libre inutile.
3. Déclarer l'outil :

   ```python
   @hermes_tool(
       name="promote_champion",
       label="Promouvoir une version",
       description="Désigne la version active d'un contrôle…",
       args=PromoteArgs,
       min_role=Role.ADMIN,
       phase=3,
       confirmation=Confirmation.REINFORCED,
       routes=(("GET", "/api/controls/{control_id}"), ("PUT", "/api/controls/{control_id}/champion")),
   )
   async def promote_champion(ctx: ToolContext, args: PromoteArgs) -> ToolOutcome:
       response = await ctx.gateway.call("PUT", "/api/controls/{control_id}/champion",
                                         path_params={"control_id": args.control_id},
                                         json_body={"version": args.version})
       if not response.ok:
           return http_failure(response, f"Promotion de {args.version}")
       return ToolOutcome(content=f"{args.version} est la version championne.", result={...})

   @promote_champion.card
   async def promote_champion_card(ctx: ToolContext, args: PromoteArgs) -> CardDraft:
       ...  # lit l'état actuel, construit titre, champs, effet, alertes
   ```

4. Règles : toute route appelée est déclarée dans `routes=` ; un outil d'écriture a une carte,
   un rôle minimal au-dessus de USER et un niveau de confirmation ; les résultats passent par
   `reduce_rows` ; aucune écriture hors carte. Le nettoyage des données personnelles est fait
   au départ vers le modèle, pour tous les outils.
5. Tests : ajouter la route à `tests/agent/fake_hermes.py` (forme réelle), un test de l'outil
   et, pour une écriture, un test carte → confirmation → exécution.
6. Relancer la découverte : la nouvelle route doit apparaître « présente ».

## Annexe B — Phases 2 et 3

- **Ouvrir la phase 2** (`HERMES_AGENT_PHASE=2`) : seulement quand le critère de la spécification
  est atteint (cibles du banc, recette par 3 à 5 analystes) et que le panneau sait afficher les
  champs modifiables d'une carte. `create_dispositions` et `revoke_disposition` sont prêts.
  `attach_evidence` demande d'abord la zone de transit des pièces jointes
  (`POST /api/agent/conversations/{id}/attachments`, section 9 de la spécification).
- **Phase 3** : `validate_control_definition` (nouvel endpoint `POST /api/controls/validate`),
  `create_control` (enveloppe `{control_id, definition}`), `create_control_version`,
  `promote_champion` (carte avec écarts et dry-run, alerte si la formule de l'`identity_key`
  change), `remove_categorization_rule` (201 vaut succès), `list_templates`, `upload_template`.
  Toutes en confirmation renforcée sauf les lectures et `upload_template` (simple). Suivre
  l'annexe A ; les outils de lecture du chargeur sont déjà écrits (désactivés).

## Annexe C — Dépannage

| Symptôme | Cause probable | Action |
| --- | --- | --- |
| 404 sur `/api/agent/*` | Agent désactivé, ou routeur non inclus | `HERMES_AGENT_ENABLED`, étape 6 |
| L'application ne démarre plus après l'ajout des variables | `HERMES_AGENT_*` mises dans `.env`, refusées par le `Settings` | Les déplacer dans `agent.env` (étape 9) |
| 403 sur un `POST /api/agent/…` | Origin hors `CORS_ORIGINS`, en-tête CSRF absent | Panneau : envoyer `X-CSRF-Token` ; vérifier l'origine |
| 403 renvoyé par un outil | Rôle insuffisant (normal), ou en-tête CSRF non retransmis | `HERMES_AGENT_FORWARD_HEADERS` doit contenir l'en-tête réel |
| 400 « Invalid host header » sur les outils | `TrustedHostMiddleware` | `HERMES_AGENT_INTERNAL_BASE_URL` avec un hôte accepté |
| 307 sur les outils | Redirection HTTPS | `HERMES_AGENT_INTERNAL_BASE_URL=https://…` |
| Les réponses arrivent d'un bloc | Mise en mémoire tampon du proxy | Nginx : `proxy_buffering off` pour `/api/agent` (l'en-tête `X-Accel-Buffering: no` est déjà envoyé) ; route OpenShift : `haproxy.router.openshift.io/timeout` d'au moins 120 s |
| « database is locked » pendant un tour | Transaction d'écriture ouverte pendant un appel d'outil (souvent une dépendance d'authentification qui écrit sans valider) | Valider (commit) avant le flux ; ne pas ouvrir de transaction autour des appels |
| 409 « Un tour est déjà en cours » | Un tour tourne encore, éventuellement après une déconnexion du navigateur : il va jusqu'au bout | Attendre ; un tour est borné par `HERMES_AGENT_TURN_TIMEOUT_S` (300 s) ; le verrou d'un worker arrêté expire après `HERMES_AGENT_TURN_LOCK_S` (120 s) |
| Outil sans données, champs vides | Noms de champs différents de la documentation | Étape 8, point 2 |
| 422 « route inconnue » à l'envoi d'un message depuis le panneau | Le panneau envoie un gabarit de route absent de `PAGES` | Aligner `PAGES` sur `app.routes.ts` (étape 8, point 2.6) |
| `ModelUnavailable` | Passerelle, clé, identifiant, quota, délai | `verifier_modeles.py` |
| Réponses avec `fallback: true`, « appel au modèle … en échec » dans le journal | Modèle principal en échec : API OpenAI non servie par la passerelle (404), identifiant, quota | `verifier_modeles.py` ; `HERMES_AGENT_OPENAI_API` (étape 9, point 3) |
| Jetons enregistrés à 0 | La passerelle ignore `stream_options`, ou `stream_usage` absent de la fabrique de `integration.py` | Étape 9 ; `HERMES_AGENT_STREAM_USAGE` |
| Action en `failed` « interrompue » ou « non exécutée » | Redémarrage pendant l'exécution, ou tour arrêté avant | Vérifier l'état réel dans l'application (run créé ?) avant de relancer |
| Plusieurs pods | Base de reprise SQLite non partagée | Affinité de session, ou `langgraph-checkpoint-postgres` (section 10 de la spécification) |

## Annexe D — Contenu du kit

| Chemin | Rôle |
| --- | --- |
| `hermes_back/app/services/agent/config.py` | Réglages `HERMES_AGENT_*` |
| `…/domain.py` | Rôles, utilisateur, contexte de page, table `PAGES` des pages de l'interface (seul endroit où figurent leurs chemins) |
| `…/registry.py` | Décorateur `@hermes_tool`, filtrage par rôle, phase et catalogue |
| `…/gateway.py` | Passerelle API interne |
| `…/context.py` | Marque « via Hermes » (variable de contexte) |
| `…/actions.py` | Cartes, empreintes, champs modifiables, confirmation écrite |
| `…/graph.py` | Graphe LangGraph d'un tour |
| `…/llm.py`, `…/prompts.py` | Modèles (principal, secours), prompt système versionné |
| `…/reduce.py` | Réduction des résultats et retrait des données personnelles |
| `…/store.py`, `…/schema.sql` | Persistance et schéma (cumulé ; la migration v016 en fige une copie) |
| `…/service.py`, `…/wiring.py` | Tours détachés de la connexion, décisions, SSE ; branchement dans l'application |
| `…/tools/` | Les 23 outils |
| `hermes_back/app/api/agent.py` | Les sept endpoints `/api/agent` |
| `hermes_back/app/services/run_query.py` | Bac à sable SQL et son routeur (fermé par défaut) |
| `hermes_back/tests/agent/` | Application factice, modèle simulé, 134 tests |
| `outils/` | Découverte des routes, vérification de la migration, vérification des modèles, essai de bout en bout, banc d'essai |
| `modeles/` | Gabarits : migration v016, `integration.py`, tests d'intégration, rapport |
| `décisions.md` | Journal des décisions de conception du kit |
