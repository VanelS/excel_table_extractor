"""v016 — Tables de l'agent Hermes (conversations, messages, appels d'outils).

GABARIT À ALIGNER SUR `app/core/migrations/versions/v015.py` avant de le copier en `v016.py` :
même nom de fonction, même signature, mêmes constantes (numéro, description), même façon
d'être déclaré au runner (liste explicite, découverte par nom de fichier…). Seul le corps
ci-dessous est propre à l'agent.

Le SQL est figé ici, copie de `app/services/agent/schema.sql` à la version 1.0 du kit : une
migration appliquée ne doit plus changer. Toute évolution du schéma passe par une nouvelle
migration (v017…). Toutes les instructions sont idempotentes (`IF NOT EXISTS`).

Ne pas activer l'agent dans cette migration : elle crée seulement des tables vides.
"""

from __future__ import annotations

from typing import Any

VERSION = 16
DESCRIPTION = "Tables de l'agent Hermes (conversations, messages, appels d'outils)"

SCHEMA_V016 = """
CREATE TABLE IF NOT EXISTS agent_conversations (
    id TEXT PRIMARY KEY,
    user_sub TEXT NOT NULL,
    scope TEXT NOT NULL DEFAULT 'global',
    run_id TEXT,
    title TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    archived_at TEXT,
    purged_at TEXT,
    turn_lock_until TEXT,
    turn_lock_owner TEXT
);

CREATE INDEX IF NOT EXISTS ix_agent_conversations_user ON agent_conversations(user_sub, updated_at);

CREATE TABLE IF NOT EXISTS agent_messages (
    id TEXT PRIMARY KEY,
    conversation_id TEXT NOT NULL,
    user_sub TEXT NOT NULL,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    request_id TEXT,
    model_name TEXT,
    prompt_version TEXT,
    input_tokens INTEGER,
    output_tokens INTEGER,
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS ix_agent_messages_conv ON agent_messages(conversation_id, created_at);

CREATE INDEX IF NOT EXISTS ix_agent_messages_user ON agent_messages(user_sub, role, created_at);

CREATE UNIQUE INDEX IF NOT EXISTS ux_agent_messages_request
    ON agent_messages(conversation_id, request_id) WHERE request_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS agent_tool_calls (
    id TEXT PRIMARY KEY,
    conversation_id TEXT NOT NULL,
    message_id TEXT,
    user_sub TEXT NOT NULL,
    tool_name TEXT NOT NULL,
    kind TEXT NOT NULL,
    level TEXT,
    model_call_id TEXT,
    args_json TEXT NOT NULL,
    submitted_json TEXT,
    payload_hash TEXT,
    card_json TEXT,
    status TEXT NOT NULL,
    lease_until TEXT,
    proposed_at TEXT NOT NULL,
    decided_at TEXT,
    executed_at TEXT,
    expires_at TEXT,
    http_status INTEGER,
    result_summary_json TEXT,
    error TEXT,
    model_name TEXT,
    prompt_version TEXT,
    input_tokens INTEGER,
    output_tokens INTEGER
);

CREATE INDEX IF NOT EXISTS ix_agent_tool_calls_conv ON agent_tool_calls(conversation_id, status);

CREATE INDEX IF NOT EXISTS ix_agent_tool_calls_user ON agent_tool_calls(user_sub, proposed_at);

CREATE INDEX IF NOT EXISTS ix_agent_tool_calls_model_call ON agent_tool_calls(model_call_id);
"""


def statements() -> list[str]:
    return [s.strip() for s in SCHEMA_V016.split(";") if s.strip()]


def upgrade(conn: Any) -> None:
    """`conn` : la connexion que le runner passe aux migrations, sqlite3 ou SQLAlchemy."""
    for statement in statements():
        if hasattr(conn, "exec_driver_sql"):  # Connection SQLAlchemy 2.x
            conn.exec_driver_sql(statement)
        else:  # sqlite3.Connection
            conn.execute(statement)
