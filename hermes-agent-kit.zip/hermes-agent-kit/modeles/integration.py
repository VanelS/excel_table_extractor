"""Adaptateurs de l'agent Hermes propres à l'application de la banque.

GABARIT : à copier en `hermes_back/app/services/agent/integration.py`, puis à compléter en
lisant le code existant (étapes 6, 9 et 11 de la procédure). Ne garder que les fonctions
nécessaires, supprimer les autres (et les imports devenus inutiles) :
- `to_user_context` : seulement si `default_user_mapper` ne sait pas lire l'utilisateur
  courant (étape 6) ;
- `register_bank_models` : seulement si les modèles passent par la configuration de
  app/services/ai (étape 9, option A) ;
- `resolve_run`, `generate_sql`, `record_query` : seulement pour activer `analyze_run_data`
  (étape 11).

Règle : aucun identifiant de modèle, URL ou secret écrit en dur ici. Tout vient de la
configuration existante de l'application.
"""

from __future__ import annotations

from typing import Any

from app.services.agent.domain import UserContext
from app.services.run_query import RunData


# -- Étape 6 : utilisateur courant ----------------------------------------------------------
def to_user_context(user: Any) -> UserContext:
    """Convertit ce que renvoie la dépendance « utilisateur courant » de app/api/deps.py.

    Exemple, si elle renvoie un objet de session : UserContext(sub=user.user_id,
    email=user.email, roles=frozenset(user.claims["roles"])). Lever ValueError si
    l'utilisateur n'a pas d'identifiant : l'API répondra 401.
    """
    raise NotImplementedError("à écrire à partir de app/api/deps.py")


# -- Étape 9 : modèles ----------------------------------------------------------------------
def register_bank_models() -> None:
    """Enregistre un fournisseur « banque » qui réutilise la configuration LLM existante.

    Exemple pour une passerelle compatible OpenAI déjà configurée dans app/core/config.py :

        from langchain_openai import ChatOpenAI
        from app.services.agent.llm import register_provider

        def factory(model_id, agent_settings):
            return ChatOpenAI(
                model=model_id,
                base_url=<URL de la passerelle, lue dans la configuration existante>,
                api_key=<clé, lue dans la configuration existante>,
                timeout=agent_settings.model_timeout_s,
                max_retries=0,
                stream_usage=agent_settings.stream_usage,  # sinon 0 jeton enregistré
                use_responses_api=agent_settings.use_responses_api,  # étape 9
            )

        register_provider("banque", factory)

    Puis : HERMES_AGENT_MODEL=banque:<identifiant exact du modèle dans la configuration>.
    Inutile de l'appeler soi-même : `agent_lifespan` et les scripts d'outillage l'appellent
    (`load_integration`). Elle ne construit aucun client, seulement la fabrique : la
    configuration se lit dans `factory`, au premier tour, jamais à l'enregistrement.
    """
    raise NotImplementedError("à écrire à partir de app/services/ai/")


# -- Étape 11 : bac à sable SQL (analyze_run_data) -----------------------------------------
def resolve_run(run_id: str, user: Any) -> RunData:
    """Mêmes contrôles et même lecture que GET /api/executions/{run_id}/rows.

    - lever l'HTTPException de l'application si le run est absent ou non visible (404/403) ;
    - `parquet_path` : `untracked/runs/{run_id}/{timestamp}_processed.parquet`, tel que la
      route /rows le retrouve (réutiliser sa fonction, ne pas recalculer le chemin) ;
    - `dispositions` : jugements actifs du contrôle, comme /rows les applique
      (clés identity_key, rule_name, judgment, reason).
    """
    raise NotImplementedError(
        "à écrire à partir de app/api/executions.py et app/core/repository.py"
    )


async def generate_sql(question: str, tables: dict[str, Any]) -> str:
    """Appelle le service qui sert POST /api/ai/sql (fonction Python, pas la route HTTP).

    `tables` décrit run_rows, dispositions et anomalies (noms et types de colonnes) : le
    passer au générateur comme schéma. Renvoyer la requête SQL seule.
    """
    raise NotImplementedError("à écrire à partir de app/api/ai_sql.py")


def record_query(
    *, user: Any, run_id: str, question: str, sql: str, row_count: int
) -> None:
    """Trace la requête dans generated_sql_queries, comme le fait ai_sql.py."""
    raise NotImplementedError("à écrire à partir du modèle GeneratedSqlQuery")
