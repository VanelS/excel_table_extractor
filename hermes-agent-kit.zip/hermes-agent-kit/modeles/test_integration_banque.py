"""Tests d'intégration de l'agent Hermes dans l'application de la banque (étapes 6 et 7).

GABARIT : à copier en `hermes_back/tests/agent/test_integration_banque.py`, puis à compléter
avec les fixtures de la suite existante (client authentifié, base de test, jeton CSRF). Les
tests du kit tournent sur une application factice ; ceux-ci vérifient ce qu'elle ne peut pas
voir : le vrai `create_app`, la vraie protection CSRF, le vrai journal d'activité.

Chaque `pytest.skip` marque un trou à combler. Une fois complété, plus aucun ne doit rester.
"""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from app.services.agent.context import AgentCallContext, agent_call_scope

MARK = AgentCallContext("conv_test", "tc_test", "start_execution", "u-test")


# -- Étape 7 : marque « via Hermes » dans le journal d'activité ------------------------------
def create_activity_entry(description):
    """Crée une entrée avec la fonction réelle du journal (activity_logger.py), puis relit
    la `description` enregistrée (décodée si besoin). À écrire."""
    pytest.skip("à écrire : appel réel du journal d'activité et relecture de l'entrée")


def test_activity_log_carries_the_hermes_mark():
    with agent_call_scope(MARK):
        stored = create_activity_entry({"control_id": "section_setting"})
    assert stored["via"] == "hermes"
    assert stored["agent_tool_call_id"] == "tc_test"
    assert stored["control_id"] == "section_setting"


@pytest.mark.parametrize("description", [None, {"control_id": "section_setting"}])
def test_activity_log_is_unchanged_outside_the_agent(description):
    assert create_activity_entry(description) == description


# -- Étape 6 : branchement dans create_app ---------------------------------------------------
@pytest.fixture
def agent_app(tmp_path, monkeypatch):
    """Application réelle, agent activé, sur une base de test (jamais celle de développement)."""
    monkeypatch.setenv("HERMES_AGENT_ENABLED", "True")
    monkeypatch.setenv(
        "HERMES_AGENT_CHECKPOINT_DB", str(tmp_path / "agent_checkpoints.db")
    )
    pytest.skip(
        "à écrire : base de test migrée (v016 comprise), comme la suite existante"
    )
    from app.api.app import create_app

    return create_app()


def authenticate(client: TestClient) -> dict[str, str]:
    """Ouvre une session comme le fait la suite existante et renvoie les en-têtes d'une
    requête qui modifie : {"Origin": <origine autorisée>, "X-CSRF-Token": <jeton>}. À écrire."""
    pytest.skip("à écrire : session de test de la suite existante")


def test_agent_routes_follow_the_application_security(agent_app):
    with TestClient(
        agent_app
    ) as client:  # `with` déclenche le cycle de vie, donc l'agent
        headers = authenticate(client)
        assert client.get("/api/agent/capabilities").status_code == 200
        without_csrf = {k: v for k, v in headers.items() if k.lower() != "x-csrf-token"}
        refused = client.post("/api/agent/conversations", json={}, headers=without_csrf)
        assert refused.status_code == 403
        created = client.post("/api/agent/conversations", json={}, headers=headers)
        assert created.status_code == 201
        conversation = client.get(f"/api/agent/conversations/{created.json()['id']}")
        assert conversation.status_code == 200
