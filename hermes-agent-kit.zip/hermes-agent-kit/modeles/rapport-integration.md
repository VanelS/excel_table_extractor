# Rapport d'intégration — agent Hermes

> Tenu à jour à chaque étape de `PROCEDURE_INTEGRATION.md`. Il sert de description à la demande
> de fusion. Chaque décision prise pendant l'intégration est consignée en section 4, avec sa
> raison ; chaque point non tranché va en section 8.

- Dépôt : `hermes_back`
- Branche :
- Version du kit : 1.0
- Intégré par :
- Date :

## 1. Points d'ancrage trouvés dans le code

| Besoin | Fichier et ligne | Remarque |
| --- | --- | --- |
| Fabrique `create_app` et cycle de vie (lifespan ou on_event) | | |
| Moteur SQLAlchemy de `hermes.db` | | |
| Dépendance « utilisateur courant » et forme renvoyée | | |
| Dépendance ou middleware CSRF, nom de l'en-tête | | |
| Middleware de validation d'Origin | | |
| Journal d'activité : création d'une entrée, construction de `description` | | |
| Clients LLM et identifiants des modèles configurés | | |
| Service de génération SQL (`/api/ai/sql`) | | |
| Lecture des lignes d'un run (chemin du parquet, jugements actifs) | | |
| Format des migrations (`runner.py`, `v015.py`) | | |
| Middlewares d'hôte ou de HTTPS (TrustedHost, redirection) | | |
| `DATA_DIR` et emplacement de `hermes.db` | | |
| Politique `extra` du `Settings` (clés inconnues de `.env`) | | |
| Configuration de pytest et de Ruff | | |

## 2. Versions

| Paquet | Version installée | Minimum du kit | Conforme |
| --- | --- | --- | --- |
| Python | | 3.12 | |
| fastapi | | — | |
| langgraph | | 1.2 | |
| langchain-core | | 1.4 | |
| pydantic-settings | | 2.7 | |
| sse-starlette | | 2 | |
| langgraph-checkpoint-sqlite | | 3 | |
| langchain-openai | | 1 | |

## 3. Fichiers ajoutés ou modifiés

| Fichier | Ajouté / modifié | Étape |
| --- | --- | --- |

## 4. Journal des décisions d'intégration

| # | Décision | Raison | Étape |
| --- | --- | --- | --- |

## 5. Découverte

- Rapport complet : `hermes_back/docs/agent-hermes/rapport-decouverte.md`
- Outils désactivés (route absente) :
- Outils activés après vérification :
- Noms de champs corrigés dans les outils :
- Contrôle de rôle de chaque route qui modifie (fichier:ligne, ou « absent » : prérequis de phase 0) :
- Pages de l'interface : valeurs de `PAGES` (`domain.py`) corrigées, entrées retirées :

## 6. Tests

| Suite | Avant intégration | Après intégration |
| --- | --- | --- |
| Tests existants du backend | | |
| `tests/agent` (kit) | — | |
| `tests/agent/test_integration_banque.py` | — | |

## 7. Essai de bout en bout (développement)

- Commande :
- Résultat :
- Marque « via Hermes » : test d'intégration de l'étape 7 :
- Modèles (`verifier_modeles.py`) :

## 8. Points ouverts

Prérequis de la spécification avant d'activer l'agent (section 13) et questions restées sans
réponse pendant l'intégration.

- [ ] Rôles vérifiés par chaque route qui modifie
- [ ] Données habilitées pour les modèles (RSSI, DPO) : option A ou B
- [ ] Architecture d'exécution (workers, pods, base de reprise partagée)
- [ ] Accès et quotas des trois modèles

## 9. Proposition pour DOCUMENTATION_TECHNIQUE.md

Texte proposé (non appliqué) : endpoints `/api/agent`, migration v016, variables
`HERMES_AGENT_*`, base `agent_checkpoints.db`, marque « via Hermes » du journal d'activité.
