"""Endpoints /api/agent (section 10 de la spécification).

Toutes les routes passent par la dépendance d'authentification de l'application ; les POST
passent aussi par sa dépendance CSRF et par la validation d'Origin existante (middleware).
Une conversation qui n'appartient pas à l'utilisateur répond 404, comme une conversation absente.

Flux SSE de `POST …/messages` et `POST …/decision` (contrat du panneau Angular) : chaque
événement a un nom (`event:`) et des données JSON (`data:`).

- `message.delta` {id, text} : fragment de réponse ; `id` regroupe les fragments d'un message.
- `tool.started` {tool, label, call_id} : un outil démarre (`label` est à afficher).
- `tool.completed` {tool, call_id, ok, card} : `card` vaut null ou une carte d'affichage,
  selon `kind` : `table` {title, columns, rows, link}, `run` {run_id, control_id, status,
  current_node, counters, link}, `link` {title, link}, `download` {title, url, filename}.
  Un `link` vaut null quand l'interface n'a pas la page (table `PAGES`).
- `ui.navigate` {route, params, url} : ouvrir la page `url` de l'interface.
- `action.proposed` {action_id, tool, label, level, title, fields, impact, warnings, editable,
  payload_hash, expires_at} : carte d'action ; `level` vaut `simple` ou `reinforced` (bouton
  seulement). La décision se poste avec `payload_hash` et les champs modifiés.
- `action.updated` {action_id, status, result?, card?} : `status` parmi `confirmed`,
  `executing`, `executed`, `failed`, `rejected`, `expired`, `cancelled`.
- `message.completed` {message_id, content, model, fallback, usage} : réponse enregistrée ;
  `fallback` vrai si le modèle de secours a répondu à la place du principal.
- `error` {code, message} : le tour s'arrête (`TurnTimeout`, `ModelUnavailable`…).
- `done` {interrupted} : fin du flux ; `interrupted` vrai si une action attend sa décision.

Le tour se poursuit côté serveur si le flux est coupé : relire `GET /conversations/{id}`.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Path, Request, Response
from sse_starlette.sse import EventSourceResponse

from app.services.agent.domain import UserContext
from app.services.agent.gateway import RequestMeta
from app.services.agent.service import (
    AgentError,
    AgentService,
    ConversationIn,
    DecisionIn,
    MessageIn,
    PreparedTurn,
)

CONVERSATION_ID = Path(pattern=r"^conv_[0-9a-f]{32}$")
ACTION_ID = Path(pattern=r"^act_[0-9a-f]{32}$")
_SSE_HEADERS = {"Cache-Control": "no-store", "X-Accel-Buffering": "no"}


def build_agent_router(
    *,
    current_user: Callable[..., Any],
    to_user_context: Callable[[Any], UserContext],
    csrf_dependency: Callable[..., Any] | None = None,
    prefix: str = "/api/agent",
) -> APIRouter:
    router = APIRouter(prefix=prefix, tags=["agent"])
    post_dependencies = (
        [Depends(csrf_dependency)] if csrf_dependency is not None else []
    )

    def get_user(raw_user: Any = Depends(current_user)) -> UserContext:
        try:
            return to_user_context(raw_user)
        except ValueError as exc:
            raise HTTPException(
                status_code=401, detail="Utilisateur non reconnu."
            ) from exc

    def get_service(request: Request) -> AgentService:
        service = getattr(request.app.state, "hermes_agent", None)
        if service is None:
            raise HTTPException(status_code=404, detail="Agent Hermes désactivé.")
        return service

    def meta(request: Request, service: AgentService) -> RequestMeta:
        return RequestMeta.from_request(request, service.settings.forward_headers)

    async def guarded(coro: Any) -> Any:
        try:
            return await coro
        except AgentError as exc:
            raise HTTPException(status_code=exc.status, detail=exc.detail) from exc

    def stream(turn: PreparedTurn) -> EventSourceResponse:
        return EventSourceResponse(turn.events(), ping=15, headers=_SSE_HEADERS)

    @router.get("/capabilities")
    async def capabilities(
        route: str | None = None,
        user: UserContext = Depends(get_user),
        service: AgentService = Depends(get_service),
    ) -> dict[str, Any]:
        return await service.capabilities(user, route)

    @router.post("/conversations", status_code=201, dependencies=post_dependencies)
    async def create_conversation(
        body: ConversationIn,
        user: UserContext = Depends(get_user),
        service: AgentService = Depends(get_service),
    ) -> dict[str, Any]:
        return await service.create_conversation(user, body)

    @router.get("/conversations")
    async def list_conversations(
        user: UserContext = Depends(get_user),
        service: AgentService = Depends(get_service),
    ) -> list[dict[str, Any]]:
        return await service.list_conversations(user)

    @router.get("/conversations/{conversation_id}")
    async def get_conversation(
        conversation_id: str = CONVERSATION_ID,
        user: UserContext = Depends(get_user),
        service: AgentService = Depends(get_service),
    ) -> dict[str, Any]:
        return await guarded(service.get_conversation(user, conversation_id))

    @router.post(
        "/conversations/{conversation_id}/messages", dependencies=post_dependencies
    )
    async def post_message(
        body: MessageIn,
        request: Request,
        conversation_id: str = CONVERSATION_ID,
        user: UserContext = Depends(get_user),
        service: AgentService = Depends(get_service),
    ) -> EventSourceResponse:
        turn = await guarded(
            service.prepare_message(user, conversation_id, body, meta(request, service))
        )
        return stream(turn)

    @router.post(
        "/conversations/{conversation_id}/actions/{action_id}/decision",
        dependencies=post_dependencies,
    )
    async def post_decision(
        body: DecisionIn,
        request: Request,
        conversation_id: str = CONVERSATION_ID,
        action_id: str = ACTION_ID,
        user: UserContext = Depends(get_user),
        service: AgentService = Depends(get_service),
    ) -> EventSourceResponse:
        turn = await guarded(
            service.prepare_decision(
                user, conversation_id, action_id, body, meta(request, service)
            )
        )
        return stream(turn)

    @router.post(
        "/conversations/{conversation_id}/archive",
        status_code=204,
        dependencies=post_dependencies,
    )
    async def archive(
        conversation_id: str = CONVERSATION_ID,
        user: UserContext = Depends(get_user),
        service: AgentService = Depends(get_service),
    ) -> Response:
        await guarded(service.archive(user, conversation_id))
        return Response(status_code=204)

    return router
