"""Bac à sable SQL DuckDB pour `POST /api/executions/{run_id}/query` (section 11 de la spécification).

Garanties, dans l'ordre d'application :
1. Une seule instruction, de type SELECT, vérifiée par l'analyseur de DuckDB (`extract_statements`).
2. Connexion en mémoire bornée : `memory_limit`, `threads`, `max_temp_directory_size` (aucun
   débordement sur disque), extensions ni installées ni chargées automatiquement.
3. Le parquet du run et les jugements actifs sont chargés en mémoire, puis l'accès externe est
   coupé (`enable_external_access = false`) et la configuration verrouillée
   (`lock_configuration = true`) : la requête ne peut ni lire un fichier ni rouvrir l'accès.
4. Arrêt après `timeout_s` secondes (`interrupt()` déclenché par une minuterie) ou `max_rows` lignes.

Tables visibles par la requête :
- `run_rows` : la table finale du run (`{timestamp}_processed.parquet`) ;
- `dispositions` : jugements actifs (identity_key, rule_name, judgment, reason) ;
- `anomalies` : vue `run_rows` + jugement actif, comme `GET /rows`, si les colonnes de jointure existent.

Le routeur fourni en bas de module a besoin de trois adaptateurs propres à l'application :
`resolve_run` (droits et chemin du parquet, comme `GET /rows`), `generate_sql` (le service
de `POST /api/ai/sql`) et, en option, `record_query` (table `generated_sql_queries`).
"""

from __future__ import annotations

import datetime as dt
import decimal
import functools
import inspect
import re
import threading
import uuid
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import duckdb
from fastapi import Request
from pydantic import BaseModel, Field

_SIZE_RE = re.compile(r"^\d+(\.\d+)?\s?(B|KB|MB|GB|KiB|MiB|GiB)$")
_RULE_COLUMNS = ("control_rule", "rule_name")


class QueryRejected(ValueError):
    """Requête refusée avant exécution (plusieurs instructions, autre chose qu'un SELECT)."""


class QueryTimeout(RuntimeError):
    pass


@dataclass(frozen=True)
class SandboxLimits:
    memory_limit: str = "512MB"
    threads: int = 2
    timeout_s: float = 10.0
    max_rows: int = 1000

    def __post_init__(self) -> None:
        if not _SIZE_RE.match(self.memory_limit):
            raise ValueError(f"memory_limit invalide : {self.memory_limit!r}")
        if not 1 <= self.threads <= 16:
            raise ValueError("threads doit être entre 1 et 16")


@dataclass
class QueryResult:
    sql: str
    columns: list[str]
    rows: list[dict[str, Any]]
    row_count: int
    truncated: bool

    def as_dict(self) -> dict[str, Any]:
        return {
            "sql": self.sql,
            "columns": self.columns,
            "rows": self.rows,
            "row_count": self.row_count,
            "truncated": self.truncated,
        }


@dataclass
class RunData:
    """Ce que `resolve_run` doit fournir pour un run visible par l'utilisateur."""

    parquet_path: str | Path
    dispositions: list[dict[str, Any]] = field(default_factory=list)


def check_select(sql: str) -> str:
    """Renvoie l'instruction si elle est un SELECT unique, sinon lève `QueryRejected`."""
    try:
        statements = duckdb.extract_statements(sql)
    except duckdb.Error as exc:
        raise QueryRejected(f"requête illisible : {exc}") from exc
    if len(statements) != 1:
        raise QueryRejected("une seule instruction est acceptée")
    statement = statements[0]
    if statement.type != duckdb.StatementType.SELECT:
        raise QueryRejected("seule une instruction SELECT est acceptée")
    return statement.query.strip()


def _connect(limits: SandboxLimits) -> duckdb.DuckDBPyConnection:
    con = duckdb.connect(":memory:")
    con.execute(f"SET memory_limit = '{limits.memory_limit}'")
    con.execute(f"SET threads = {int(limits.threads)}")
    con.execute("SET max_temp_directory_size = '0B'")
    con.execute("SET autoinstall_known_extensions = false")
    con.execute("SET autoload_known_extensions = false")
    con.execute("SET allow_community_extensions = false")
    return con


def _lock(con: duckdb.DuckDBPyConnection) -> None:
    con.execute("SET enable_external_access = false")
    con.execute("SET lock_configuration = true")


def _load(
    con: duckdb.DuckDBPyConnection,
    parquet_path: str | Path,
    dispositions: list[dict[str, Any]],
) -> None:
    con.execute(
        "CREATE TABLE run_rows AS SELECT * FROM read_parquet(?)", [str(parquet_path)]
    )
    con.execute(
        "CREATE TABLE dispositions (identity_key VARCHAR, rule_name VARCHAR, "
        "judgment VARCHAR, reason VARCHAR)"
    )
    rows = [
        (
            d.get("identity_key"),
            d.get("rule_name") or d.get("control_rule"),
            d.get("judgment"),
            d.get("reason"),
        )
        for d in dispositions
    ]
    if rows:
        con.executemany("INSERT INTO dispositions VALUES (?, ?, ?, ?)", rows)
    columns = {r[0] for r in con.execute("DESCRIBE run_rows").fetchall()}
    rule_column = next((c for c in _RULE_COLUMNS if c in columns), None)
    if "identity_key" in columns and rule_column:
        con.execute(
            "CREATE VIEW anomalies AS SELECT r.*, d.judgment AS active_judgment, "
            "d.reason AS active_reason FROM run_rows r LEFT JOIN dispositions d "
            f'ON r.identity_key = d.identity_key AND r."{rule_column}" = d.rule_name'
        )


def describe_run(parquet_path: str | Path) -> dict[str, list[dict[str, str]]]:
    """Schéma des tables, à donner au générateur de SQL. Ne lit que les métadonnées."""
    con = _connect(SandboxLimits())
    try:
        described = con.execute(
            "DESCRIBE SELECT * FROM read_parquet(?)", [str(parquet_path)]
        ).fetchall()
    finally:
        con.close()
    run_columns = [{"name": r[0], "type": r[1]} for r in described]
    tables = {
        "run_rows": run_columns,
        "dispositions": [
            {"name": n, "type": "VARCHAR"}
            for n in ("identity_key", "rule_name", "judgment", "reason")
        ],
    }
    names = {c["name"] for c in run_columns}
    if "identity_key" in names and any(c in names for c in _RULE_COLUMNS):
        tables["anomalies"] = run_columns + [
            {"name": "active_judgment", "type": "VARCHAR"},
            {"name": "active_reason", "type": "VARCHAR"},
        ]
    return tables


def _jsonable(value: Any) -> Any:
    if isinstance(value, (dt.datetime, dt.date, dt.time)):
        return value.isoformat()
    if isinstance(value, decimal.Decimal):
        return float(value)
    if isinstance(value, uuid.UUID):
        return str(value)
    if isinstance(value, (bytes, bytearray, memoryview)):
        return None
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    return value


def run_select(
    sql: str,
    *,
    parquet_path: str | Path,
    dispositions: list[dict[str, Any]] | None = None,
    limits: SandboxLimits = SandboxLimits(),
) -> QueryResult:
    """Exécute un SELECT unique dans le bac à sable. Bloquant : appeler depuis un thread."""
    statement = check_select(sql)
    con = _connect(limits)
    timer = threading.Timer(limits.timeout_s, con.interrupt)
    try:
        _load(con, parquet_path, dispositions or [])
        _lock(con)
        timer.start()
        try:
            cursor = con.execute(statement)
            columns = [d[0] for d in cursor.description or []]
            fetched = cursor.fetchmany(limits.max_rows + 1)
        except duckdb.InterruptException as exc:
            raise QueryTimeout(
                f"requête interrompue après {limits.timeout_s:g} secondes"
            ) from exc
    finally:
        timer.cancel()
        con.close()
    truncated = len(fetched) > limits.max_rows
    rows = [
        {c: _jsonable(v) for c, v in zip(columns, r, strict=True)}
        for r in fetched[: limits.max_rows]
    ]
    return QueryResult(
        sql=statement,
        columns=columns,
        rows=rows,
        row_count=len(rows),
        truncated=truncated,
    )


# -- endpoint ----------------------------------------------------------------------------------
class RunQueryIn(BaseModel):
    """Corps de `POST /api/executions/{run_id}/query`."""

    question: str = Field(min_length=3, max_length=500)


async def _call(fn: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
    """Adaptateur async tel quel ; adaptateur sync dans un thread (pas d'I/O bloquant ici)."""
    from anyio import to_thread

    if inspect.iscoroutinefunction(fn):
        return await fn(*args, **kwargs)
    result = await to_thread.run_sync(functools.partial(fn, *args, **kwargs))
    return await result if inspect.isawaitable(result) else result


def agent_tool_open(request: Request) -> bool:
    """Ouvert seulement si l'agent est actif et l'outil `analyze_run_data` activé (phase comprise)."""
    service = getattr(request.app.state, "hermes_agent", None)
    if service is None:
        return False
    from app.services.agent.registry import is_enabled, load_tools

    spec = load_tools().get("analyze_run_data")
    return (
        spec is not None
        and is_enabled(spec, service.settings)
        and spec.phase <= service.settings.phase
    )


def build_run_query_router(
    *,
    current_user: Callable[..., Any],
    resolve_run: Callable[[str, Any], RunData | Awaitable[RunData]],
    generate_sql: Callable[[str, dict[str, Any]], str | Awaitable[str]],
    record_query: Callable[..., Any] | None = None,
    csrf_dependency: Callable[..., Any] | None = None,
    is_open: Callable[[Any], bool] = agent_tool_open,
    limits: SandboxLimits = SandboxLimits(),
    prefix: str = "/api/executions",
) -> Any:
    """Routeur de `POST {prefix}/{run_id}/query`.

    - `resolve_run(run_id, user)` : vérifie les droits comme `GET /rows` et renvoie `RunData` ;
      lève l'`HTTPException` de l'application (404, 403) sinon.
    - `generate_sql(question, tables)` : appelle le service existant de `POST /api/ai/sql`.
    - `record_query(user=, run_id=, question=, sql=, row_count=)` : trace dans `generated_sql_queries`.
    - `is_open(request)` : l'endpoint répond 404 tant que cette fonction renvoie faux. Par défaut,
      il suit l'agent : actif seulement avec `HERMES_AGENT_ENABLED` et l'outil activé.
    """
    from anyio import to_thread
    from fastapi import APIRouter, Depends, HTTPException
    from fastapi import Path as PathParam

    router = APIRouter(prefix=prefix, tags=["executions"])
    dependencies = [Depends(csrf_dependency)] if csrf_dependency else []

    @router.post("/{run_id}/query", dependencies=dependencies)
    async def query_run(
        body: RunQueryIn,
        request: Request,
        run_id: str = PathParam(pattern=r"^[A-Za-z0-9_-]{1,128}$"),
        user: Any = Depends(current_user),
    ) -> dict[str, Any]:
        if not is_open(request):
            raise HTTPException(status_code=404, detail="Analyse SQL désactivée.")
        run = await _call(resolve_run, run_id, user)
        tables = await to_thread.run_sync(describe_run, run.parquet_path)
        sql = await _call(generate_sql, body.question, tables)
        try:
            result = await to_thread.run_sync(
                functools.partial(
                    run_select,
                    sql,
                    parquet_path=run.parquet_path,
                    dispositions=run.dispositions,
                    limits=limits,
                )
            )
        except (QueryRejected, QueryTimeout) as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
        except duckdb.Error as exc:
            raise HTTPException(
                status_code=422, detail=f"requête invalide : {str(exc)[:300]}"
            ) from exc
        if record_query is not None:
            await _call(
                record_query,
                user=user,
                run_id=run_id,
                question=body.question,
                sql=result.sql,
                row_count=result.row_count,
            )
        return result.as_dict()

    return router
