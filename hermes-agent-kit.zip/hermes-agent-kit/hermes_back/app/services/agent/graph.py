"""Graphe LangGraph d'un tour de conversation (section 5 de la spécification).

    call_model ─▶ run_tools ─▶ propose_action ─▶ await_decision ─▶ execute_action ─▶ call_model
        │             │                              └────────────▶ close_action  ─▶ call_model
        ▼             └──────────────▶ call_model
       FIN

Points d'attention :
- `await_decision` ne contient que `interrupt()` : à la reprise, LangGraph réexécute le nœud
  interrompu depuis son début ; rien ne doit donc y précéder l'interruption.
- L'action confirmée s'exécute dans une tâche protégée (`asyncio.shield`), enregistrée par
  conversation : le service attend sa fin avant de libérer le verrou de tour, et son bail est
  renouvelé tant qu'elle tourne.
- Les dépendances du tour (passerelle, base, utilisateur) passent par le contexte d'exécution
  LangGraph, jamais par l'état : rien de tout cela n'est écrit dans les points de reprise.
- Tout ce qui part vers le modèle passe par `scrub` / `mask_text` : champs d'identité retirés,
  adresses électroniques masquées.
"""

from __future__ import annotations

import asyncio
import functools
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Annotated, Any, TypedDict
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from anyio import to_thread
from langchain_core.messages import (
    AIMessage,
    AnyMessage,
    HumanMessage,
    SystemMessage,
    ToolMessage,
)
from langgraph.config import get_stream_writer
from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import add_messages
from langgraph.runtime import Runtime
from langgraph.types import interrupt
from pydantic import ValidationError

from .actions import (
    CANCELLED,
    CONFIRMED,
    EXECUTED,
    EXECUTING,
    EXPIRED,
    FAILED,
    OUTCOME_TEXT,
    PROPOSED,
    REJECTED,
    build_card,
    validate_submitted,
)
from .config import AgentSettings
from .context import AgentCallContext, agent_call_scope
from .domain import PageContext, UserContext
from .gateway import ApiGateway, GatewayError, GatewayTimeout
from .llm import ModelProvider, message_text
from .prompts import PROMPT_VERSION, build_system_prompt
from .reduce import compact, mask_text, scrub
from .registry import ToolContext, ToolOutcome, ToolSpec
from .store import AgentStore, iso, new_id, utcnow

log = logging.getLogger("hermes.agent.graph")

# Clé posée dans les arguments d'un appel d'outil illisible (JSON invalide du modèle).
INVALID_ARGS_KEY = "_arguments_illisibles"


class HermesState(TypedDict, total=False):
    messages: Annotated[list[AnyMessage], add_messages]
    iterations: int
    tool_calls: int
    pending_tool_call: dict[str, Any] | None
    pending_action_id: str | None
    decision: dict[str, Any] | None


@dataclass
class TurnContext:
    conversation_id: str
    user: UserContext
    page_context: PageContext | None
    gateway: ApiGateway
    store: AgentStore
    settings: AgentSettings
    tools: dict[str, ToolSpec]
    models: ModelProvider
    # Actions en cours d'exécution, par conversation (registre tenu par le service).
    executions: dict[str, set[asyncio.Task[Any]]] = field(default_factory=dict)


# -- utilitaires ------------------------------------------------------------------------
def _emit(event: str, data: dict[str, Any]) -> None:
    get_stream_writer()({"event": event, "data": data})


def _today(settings: AgentSettings) -> str:
    # Fuseau absent de la machine (Windows sans tzdata) ou invalide : date UTC.
    try:
        return datetime.now(ZoneInfo(settings.timezone)).strftime("%d/%m/%Y")
    except (ZoneInfoNotFoundError, ValueError):
        return utcnow().strftime("%d/%m/%Y")


def _tool_context(ctx: TurnContext, tool_call_id: str) -> ToolContext:
    async def recent_user_texts() -> list[str]:
        return await to_thread.run_sync(
            ctx.store.recent_user_texts, ctx.conversation_id
        )

    return ToolContext(
        gateway=ctx.gateway,
        settings=ctx.settings,
        user=ctx.user,
        conversation_id=ctx.conversation_id,
        tool_call_id=tool_call_id,
        page_context=ctx.page_context,
        emit=lambda payload: get_stream_writer()(payload),
        recent_user_texts=recent_user_texts,
    )


def _content(outcome: ToolOutcome, settings: AgentSettings) -> str:
    """Résultat d'outil tel qu'il part vers le modèle : nettoyé, réduit, tronqué."""
    if isinstance(outcome.content, str):
        return mask_text(outcome.content)[: settings.max_chars_to_model]
    return compact(scrub(outcome.content), settings.max_chars_to_model)


def _tool_message(text: str, call_id: str, *, error: bool) -> ToolMessage:
    return ToolMessage(
        content=mask_text(text),
        tool_call_id=call_id,
        status="error" if error else "success",
    )


def _short_error(exc: ValidationError) -> str:
    return "; ".join(
        f"{'.'.join(str(p) for p in e['loc']) or 'arguments'} : {e['msg']}"
        for e in exc.errors()[:5]
    )


def _dangling_ids(messages: list[AnyMessage]) -> set[str]:
    answered = {m.tool_call_id for m in messages if isinstance(m, ToolMessage)}
    return {
        tc["id"]
        for m in messages
        if isinstance(m, AIMessage)
        for tc in m.tool_calls
        if tc["id"] not in answered
    }


def _status_text(row: dict[str, Any] | None) -> str:
    """Réponse de synthèse d'un appel resté sans réponse dans l'historique du graphe."""
    if row is None:
        return "Appel interrompu, sans résultat."
    status, error = row["status"], row.get("error") or ""
    if status == EXECUTED:
        return mask_text(
            f"Action exécutée : {row.get('result_summary_json') or 'sans détail'}"
        )
    if status == FAILED and (error.startswith(("interrompue", "non exécutée"))):
        return (
            f"Action {error}. Son état réel est à vérifier dans l'application (par exemple la "
            "liste des runs) avant toute nouvelle proposition."
        )
    if status == FAILED:
        return mask_text(f"Action en échec : {error or 'erreur inconnue'}")
    return OUTCOME_TEXT.get(status, f"Statut : {status}")


def prepare_history(
    messages: list[AnyMessage], limit: int, statuses: dict[str, dict[str, Any]]
) -> list[AnyMessage]:
    """Historique envoyé au modèle : réparé, puis limité aux `limit` derniers messages.

    - Réparation : tout appel d'outil sans réponse (tour annulé, action annulée par un nouveau
      message) reçoit une réponse de synthèse tirée de la base, placée juste après son groupe.
    - Coupe : la fenêtre commence toujours à un message de l'utilisateur, pour ne jamais
      séparer un appel d'outil de son résultat.
    """
    answered = {m.tool_call_id for m in messages if isinstance(m, ToolMessage)}
    known_ids = {
        tc["id"] for m in messages if isinstance(m, AIMessage) for tc in m.tool_calls
    }
    repaired: list[AnyMessage] = []
    i = 0
    while i < len(messages):
        message = messages[i]
        i += 1
        if isinstance(message, ToolMessage) and message.tool_call_id not in known_ids:
            continue  # réponse orpheline
        repaired.append(message)
        if isinstance(message, AIMessage) and message.tool_calls:
            while i < len(messages) and isinstance(messages[i], ToolMessage):
                repaired.append(messages[i])
                i += 1
            for call in message.tool_calls:
                if call["id"] not in answered:
                    repaired.append(
                        ToolMessage(
                            content=_status_text(statuses.get(call["id"])),
                            tool_call_id=call["id"],
                        )
                    )
    start = max(0, len(repaired) - limit)
    while start > 0 and not isinstance(repaired[start], HumanMessage):
        start -= 1
    return repaired[start:]


def _shielded(
    coro: Any, registry: dict[str, set[asyncio.Task[Any]]], key: str
) -> asyncio.Future[Any]:
    """Lance `coro` dans une tâche que l'annulation de l'appelant n'interrompt pas."""
    task = asyncio.ensure_future(coro)
    tasks = registry.setdefault(key, set())
    tasks.add(task)

    def forget(done: asyncio.Task[Any]) -> None:
        tasks.discard(done)
        if not tasks:
            registry.pop(key, None)

    task.add_done_callback(forget)
    return asyncio.shield(task)


async def wait_executions(
    registry: dict[str, set[asyncio.Task[Any]]],
    conversation_id: str | None,
    *,
    timeout: float,
) -> None:
    """Attend la fin des actions en cours (d'une conversation, ou de toutes)."""
    if conversation_id is None:
        tasks = {t for group in registry.values() for t in group}
    else:
        tasks = set(registry.get(conversation_id, ()))
    if tasks and timeout > 0:
        await asyncio.wait(tasks, timeout=timeout)


def _repair_invalid_calls(ai: AIMessage) -> AIMessage:
    """Appels d'outils au JSON illisible : convertis en appels marqués, auxquels `run_tools`
    répond par une erreur. Sinon ils resteraient sans réponse dans l'historique et certains
    fournisseurs refuseraient tous les tours suivants."""
    invalid = list(getattr(ai, "invalid_tool_calls", None) or [])
    if not invalid:
        return ai
    calls = list(ai.tool_calls) + [
        {
            "name": c.get("name") or "inconnu",
            "args": {INVALID_ARGS_KEY: str(c.get("args") or "")[:200]},
            "id": c.get("id") or new_id("call"),
            "type": "tool_call",
        }
        for c in invalid
    ]
    return AIMessage(
        content=ai.content,
        tool_calls=calls,
        id=ai.id,
        response_metadata=ai.response_metadata,
        usage_metadata=ai.usage_metadata,
    )


# -- nœuds ------------------------------------------------------------------------------
async def call_model(
    state: HermesState, runtime: Runtime[TurnContext]
) -> dict[str, Any]:
    ctx = runtime.context
    settings = ctx.settings
    iterations = state.get("iterations", 0)
    over_budget = (
        iterations >= settings.max_iterations
        or state.get("tool_calls", 0) >= settings.max_tool_calls
    )
    messages = state.get("messages", [])
    dangling = _dangling_ids(messages)
    statuses = (
        await to_thread.run_sync(
            ctx.store.statuses_by_model_call, ctx.conversation_id, list(dangling)
        )
        if dangling
        else {}
    )
    history = prepare_history(messages, settings.history_messages, statuses)
    system = SystemMessage(
        content=build_system_prompt(
            user=ctx.user,
            page_route=ctx.page_context.route if ctx.page_context else None,
            today=_today(settings),
            over_budget=over_budget,
        )
    )
    # Les outils restent déclarés même hors budget : certains fournisseurs refusent un
    # historique contenant des appels d'outils sans leur définition.
    tools = [spec.model_schema() for spec in ctx.tools.values()] or None
    ai = _repair_invalid_calls(await ctx.models.invoke([system, *history], tools=tools))
    for tool_call in ai.tool_calls:  # certains fournisseurs omettent l'identifiant
        if not tool_call.get("id"):
            tool_call["id"] = new_id("call")
    if over_budget and ai.tool_calls:
        ai = AIMessage(
            content=(message_text(ai) + "\n\n").lstrip()
            + "Limite d'appels atteinte pour cette demande : précisez-la pour continuer.",
            id=ai.id,
            response_metadata=ai.response_metadata,
            usage_metadata=ai.usage_metadata,
        )
    return {"messages": [ai], "iterations": iterations + 1}


def after_model(state: HermesState) -> str:
    last = state["messages"][-1]
    return "run_tools" if isinstance(last, AIMessage) and last.tool_calls else END


async def _run_read(
    ctx: TurnContext, spec: ToolSpec, call: dict[str, Any]
) -> ToolMessage:
    record_id = new_id("tc")
    started = iso(utcnow())
    base = {
        "id": record_id,
        "conversation_id": ctx.conversation_id,
        "user_sub": ctx.user.sub,
        "tool_name": spec.name,
        "kind": "read",
        "model_call_id": call["id"],
        "args_json": json.dumps(
            call.get("args") or {}, ensure_ascii=False, default=str
        ),
        "proposed_at": started,
        "prompt_version": PROMPT_VERSION,
    }
    try:
        args = spec.args_model.model_validate(call.get("args") or {})
    except ValidationError as exc:
        message = f"Arguments invalides pour {spec.name} : {_short_error(exc)}"
        await to_thread.run_sync(
            ctx.store.insert_tool_call, {**base, "status": "error", "error": message}
        )
        return _tool_message(message, call["id"], error=True)

    _emit(
        "tool.started", {"tool": spec.name, "label": spec.label, "call_id": record_id}
    )
    try:
        with agent_call_scope(
            AgentCallContext(ctx.conversation_id, record_id, spec.name, ctx.user.sub)
        ):
            outcome = await spec.handler(_tool_context(ctx, record_id), args)
    except GatewayError as exc:
        outcome = ToolOutcome(
            content=f"Appel refusé par la passerelle : {exc}", ok=False, error=str(exc)
        )
    except Exception as exc:  # une erreur d'outil ne doit pas faire tomber le tour
        log.exception("outil %s en erreur", spec.name)
        outcome = ToolOutcome(
            content="Erreur technique pendant l'appel de l'outil.",
            ok=False,
            error=repr(exc),
        )
    content = _content(outcome, ctx.settings)
    await to_thread.run_sync(
        ctx.store.insert_tool_call,
        {
            **base,
            "status": "ok" if outcome.ok else "error",
            "executed_at": iso(utcnow()),
            "http_status": outcome.http_status,
            "result_summary_json": compact(outcome.result, 2000)
            if outcome.result is not None
            else None,
            "error": outcome.error,
        },
    )
    _emit(
        "tool.completed",
        {"tool": spec.name, "call_id": record_id, "ok": outcome.ok, "card": outcome.ui},
    )
    return ToolMessage(
        content=content,
        tool_call_id=call["id"],
        status="success" if outcome.ok else "error",
    )


async def run_tools(
    state: HermesState, runtime: Runtime[TurnContext]
) -> dict[str, Any]:
    ctx = runtime.context
    last = state["messages"][-1]
    assert isinstance(last, AIMessage)
    used = state.get("tool_calls", 0)
    budget = max(0, ctx.settings.max_tool_calls - used)
    replies: list[ToolMessage] = []
    reads: list[tuple[ToolSpec, dict[str, Any]]] = []
    pending: dict[str, Any] | None = None
    for call in last.tool_calls:
        spec = ctx.tools.get(call["name"])
        if INVALID_ARGS_KEY in (call.get("args") or {}):
            replies.append(
                _tool_message(
                    f"Arguments illisibles (JSON invalide) pour {call['name']} : "
                    "renvoyez l'appel avec des arguments valides.",
                    call["id"],
                    error=True,
                )
            )
        elif spec is None:
            replies.append(
                _tool_message(
                    "Outil indisponible pour cet utilisateur ou dans la phase ouverte : "
                    f"{call['name']}.",
                    call["id"],
                    error=True,
                )
            )
        elif spec.is_write:
            if pending is None:
                pending = dict(call)
            else:
                replies.append(
                    _tool_message(
                        "Une action à la fois : refaites cette demande après la décision "
                        "sur l'action en cours.",
                        call["id"],
                        error=True,
                    )
                )
        else:
            reads.append((spec, call))
    allowed, skipped = reads[:budget], reads[budget:]
    for _spec, call in skipped:
        replies.append(
            _tool_message(
                "Budget d'appels atteint pour ce tour : non exécuté.",
                call["id"],
                error=True,
            )
        )
    if pending is not None and budget - len(allowed) <= 0:
        replies.append(
            _tool_message(
                "Budget d'appels atteint pour ce tour : action non proposée.",
                pending["id"],
                error=True,
            )
        )
        pending = None
    results = await asyncio.gather(
        *(_run_read(ctx, spec, call) for spec, call in allowed)
    )
    return {
        "messages": [*results, *replies],
        "tool_calls": used + len(allowed),
        "pending_tool_call": pending,
    }


def after_tools(state: HermesState) -> str:
    return "propose_action" if state.get("pending_tool_call") else "call_model"


async def propose_action(
    state: HermesState, runtime: Runtime[TurnContext]
) -> dict[str, Any]:
    ctx = runtime.context
    call = state["pending_tool_call"] or {}
    spec = ctx.tools[call["name"]]

    def refuse(text: str) -> dict[str, Any]:
        return {
            "messages": [_tool_message(text, call["id"], error=True)],
            "pending_tool_call": None,
            "pending_action_id": None,
        }

    try:
        parsed = spec.args_model.model_validate(call.get("args") or {})
    except ValidationError as exc:
        return refuse(f"Arguments invalides pour {spec.name} : {_short_error(exc)}")
    action_id = new_id("act")
    assert spec.card_builder is not None
    try:
        with agent_call_scope(
            AgentCallContext(ctx.conversation_id, action_id, spec.name, ctx.user.sub)
        ):
            draft = await spec.card_builder(_tool_context(ctx, action_id), parsed)
    except GatewayError as exc:
        return refuse(f"Action impossible à préparer : {exc}")
    except ValueError as exc:  # refus métier explicite du constructeur de carte
        return refuse(f"Action impossible à préparer : {exc}")

    args = {**parsed.model_dump(mode="json"), **draft.overrides}
    now = utcnow()
    expires = now + timedelta(minutes=ctx.settings.action_ttl_minutes)
    card = build_card(spec, draft, action_id=action_id, args=args, expires_at=expires)
    await to_thread.run_sync(
        ctx.store.insert_tool_call,
        {
            "id": action_id,
            "conversation_id": ctx.conversation_id,
            "user_sub": ctx.user.sub,
            "tool_name": spec.name,
            "kind": "write",
            "level": spec.confirmation.value,
            "model_call_id": call["id"],
            "args_json": json.dumps(args, ensure_ascii=False, default=str),
            "payload_hash": card.payload_hash,
            "card_json": card.model_dump_json(),
            "status": PROPOSED,
            "proposed_at": iso(now),
            "expires_at": iso(expires),
            "prompt_version": PROMPT_VERSION,
        },
    )
    _emit("action.proposed", card.model_dump(mode="json"))
    return {"pending_action_id": action_id}


def after_propose(state: HermesState) -> str:
    return "await_decision" if state.get("pending_action_id") else "call_model"


def await_decision(state: HermesState) -> dict[str, Any]:
    # Rien avant interrupt() : ce nœud est réexécuté depuis son début à la reprise.
    decision = interrupt({"action_id": state.get("pending_action_id")})
    return {"decision": decision}


def after_decision(state: HermesState) -> str:
    return (
        "execute_action"
        if (state.get("decision") or {}).get("decision") == "confirm"
        else "close_action"
    )


async def _renew_lease(ctx: TurnContext, action_id: str) -> None:
    """Renouvelle le bail de l'action tant qu'elle s'exécute (section 7 de la spécification)."""
    lease = ctx.settings.action_lease_s
    while True:
        await asyncio.sleep(max(1.0, lease / 3))
        until = iso(utcnow() + timedelta(seconds=lease))
        await to_thread.run_sync(
            functools.partial(ctx.store.update_tool_call, action_id, lease_until=until)
        )


async def _execute_and_record(
    ctx: TurnContext, spec: ToolSpec, args: Any, action_id: str
) -> ToolOutcome:
    heartbeat = asyncio.ensure_future(_renew_lease(ctx, action_id))
    try:
        with agent_call_scope(
            AgentCallContext(ctx.conversation_id, action_id, spec.name, ctx.user.sub)
        ):
            outcome = await spec.handler(_tool_context(ctx, action_id), args)
    except GatewayTimeout as exc:
        outcome = ToolOutcome(
            content=(
                f"{exc}. L'état réel de l'action est inconnu : le vérifier dans "
                "l'application avant toute nouvelle tentative."
            ),
            ok=False,
            error=f"état inconnu : {exc}",
        )
    except GatewayError as exc:
        outcome = ToolOutcome(
            content=f"Appel refusé par la passerelle : {exc}", ok=False, error=str(exc)
        )
    except Exception as exc:
        log.exception("action %s en erreur", spec.name)
        outcome = ToolOutcome(
            content="Erreur technique pendant l'action.", ok=False, error=repr(exc)
        )
    finally:
        heartbeat.cancel()
    await to_thread.run_sync(
        lambda: ctx.store.update_tool_call(
            action_id,
            status=EXECUTED if outcome.ok else FAILED,
            executed_at=iso(utcnow()),
            lease_until=None,
            http_status=outcome.http_status,
            result_summary_json=compact(outcome.result, 4000)
            if outcome.result is not None
            else None,
            error=outcome.error,
        )
    )
    return outcome


def _close(call: dict[str, Any], text: str, *, error: bool = True) -> dict[str, Any]:
    return {
        "messages": [_tool_message(text, call["id"], error=error)],
        "pending_tool_call": None,
        "pending_action_id": None,
        "decision": None,
    }


async def execute_action(
    state: HermesState, runtime: Runtime[TurnContext]
) -> dict[str, Any]:
    ctx = runtime.context
    call = state["pending_tool_call"] or {}
    action_id = state.get("pending_action_id") or ""
    action = await to_thread.run_sync(ctx.store.get_tool_call, action_id)
    if action is None or action["status"] != CONFIRMED:
        return _close(
            call,
            f"Action non exécutée : statut {action['status'] if action else 'inconnu'}.",
        )
    spec = ctx.tools.get(action["tool_name"])
    if spec is None:  # rôle ou phase changés depuis la proposition
        await to_thread.run_sync(
            lambda: ctx.store.transition(
                action_id,
                CONFIRMED,
                FAILED,
                error="outil plus autorisé pour cet utilisateur",
            )
        )
        _emit("action.updated", {"action_id": action_id, "status": FAILED})
        return _close(
            call, "Action non exécutée : outil plus autorisé pour cet utilisateur."
        )
    try:
        args = validate_submitted(
            spec, json.loads(action["submitted_json"] or action["args_json"])
        )
    except ValidationError as exc:
        reason = f"paramètres invalides : {_short_error(exc)}"
        await to_thread.run_sync(
            lambda: ctx.store.transition(action_id, CONFIRMED, FAILED, error=reason)
        )
        _emit("action.updated", {"action_id": action_id, "status": FAILED})
        return _close(call, f"Action non exécutée : {reason}.")
    lease = iso(utcnow() + timedelta(seconds=ctx.settings.action_lease_s))
    moved = await to_thread.run_sync(
        lambda: ctx.store.transition(action_id, CONFIRMED, EXECUTING, lease_until=lease)
    )
    if not moved:
        return _close(call, "Action déjà traitée.")
    _emit("action.updated", {"action_id": action_id, "status": EXECUTING})
    outcome = await _shielded(
        _execute_and_record(ctx, spec, args, action_id),
        ctx.executions,
        ctx.conversation_id,
    )
    status = EXECUTED if outcome.ok else FAILED
    _emit(
        "action.updated",
        {
            "action_id": action_id,
            "status": status,
            "result": outcome.result,
            "card": outcome.ui,
        },
    )
    text = f"Action {'exécutée' if outcome.ok else 'en échec'} : {_content(outcome, ctx.settings)}"
    result = _close(call, text, error=not outcome.ok)
    result["tool_calls"] = state.get("tool_calls", 0) + 1
    return result


async def close_action(
    state: HermesState, runtime: Runtime[TurnContext]
) -> dict[str, Any]:
    # Le statut est déjà en base et déjà annoncé au panneau par le service (prepare_decision).
    call = state["pending_tool_call"] or {}
    status = {"reject": REJECTED, "expired": EXPIRED}.get(
        (state.get("decision") or {}).get("decision", ""), CANCELLED
    )
    return _close(call, OUTCOME_TEXT[status])


def build_graph(checkpointer: Any) -> Any:
    graph = StateGraph(HermesState, context_schema=TurnContext)
    graph.add_node("call_model", call_model)
    graph.add_node("run_tools", run_tools)
    graph.add_node("propose_action", propose_action)
    graph.add_node("await_decision", await_decision)
    graph.add_node("execute_action", execute_action)
    graph.add_node("close_action", close_action)
    graph.add_edge(START, "call_model")
    graph.add_conditional_edges("call_model", after_model, ["run_tools", END])
    graph.add_conditional_edges(
        "run_tools", after_tools, ["propose_action", "call_model"]
    )
    graph.add_conditional_edges(
        "propose_action", after_propose, ["await_decision", "call_model"]
    )
    graph.add_conditional_edges(
        "await_decision", after_decision, ["execute_action", "close_action"]
    )
    graph.add_edge("execute_action", "call_model")
    graph.add_edge("close_action", "call_model")
    return graph.compile(checkpointer=checkpointer)
