"""Configuration de l'agent, lue dans les variables d'environnement `HERMES_AGENT_*`."""

from __future__ import annotations

import re
from typing import Annotated, Literal

from pydantic import Field, SecretStr, field_validator
from pydantic_settings import BaseSettings, NoDecode, SettingsConfigDict

_RATE_RE = re.compile(r"^\s*(\d+)\s*/\s*(\d+)\s*(s|min|h)\s*$")
_UNIT_S = {"s": 1, "min": 60, "h": 3600}


def _split_csv(value: object) -> object:
    """Accepte `a,b,c` en plus du JSON dans les variables d'environnement de type liste."""
    if isinstance(value, str):
        return [item.strip() for item in value.split(",") if item.strip()]
    return value


class AgentSettings(BaseSettings):
    # `agent.env` (non versionné) porte les valeurs locales : les mettre dans `.env` ferait
    # échouer un `Settings` d'application qui refuse les clés inconnues (extra="forbid").
    # Une variable vide vaut « non renseignée » : la valeur par défaut s'applique.
    model_config = SettingsConfigDict(
        env_prefix="HERMES_AGENT_",
        env_file=(".env", "agent.env"),
        extra="ignore",
        env_ignore_empty=True,
    )

    # Activation et phase : désactivé par défaut, la phase n'ouvre que ses outils.
    enabled: bool = False
    phase: int = Field(default=1, ge=1, le=3)

    # Modèles, au format "<fournisseur>:<identifiant>" (ex. "openai:<id>").
    # Les identifiants exacts viennent de la configuration de app/services/ai/ : ne pas les inventer.
    model: str = ""
    fast_model: str = ""
    fallback_model: str = ""
    model_timeout_s: float = 30.0  # délai de connexion et d'attente de chaque fragment
    model_total_timeout_s: float = 120.0  # durée maximale d'un appel, fragments compris
    # Jetons comptés en diffusion (`stream_options.include_usage`). LangChain le coupe par
    # défaut dès qu'une URL de passerelle est donnée : sans lui, les jetons enregistrés
    # vaudraient 0. À passer à False seulement si la passerelle refuse l'option.
    stream_usage: bool = True
    # API OpenAI des fournisseurs openai et banque : "chat" (/chat/completions), "responses"
    # (/responses), ou "auto" : choix de langchain-openai selon le modèle et sa propre version
    # (GPT 5.6 Sol passe par /responses en 1.7, pas en 1.3). À fixer à l'étape 9 selon ce que
    # sert la passerelle et ce qu'appelle déjà app/services/ai.
    openai_api: Literal["auto", "chat", "responses"] = "auto"
    openai_base_url: str | None = None
    openai_api_key: SecretStr | None = None
    anthropic_base_url: str | None = None
    anthropic_api_key: SecretStr | None = None
    google_api_key: SecretStr | None = None

    # Budgets et limites (section 10 de la spécification).
    max_iterations: int = 8
    max_tool_calls: int = 15
    history_messages: int = 20
    max_rows_to_model: int = 50
    max_chars_to_model: int = 12_000
    max_batch_dispositions: int = 20
    action_ttl_minutes: int = 15
    action_lease_s: int = (
        300  # bail d'une action en cours, renouvelé pendant l'exécution
    )
    turn_lock_s: int = 120  # verrou de tour, renouvelé tant que le tour tourne
    turn_timeout_s: float = 300.0  # durée maximale d'un tour
    rate_limit: str = "30/5min"

    # Points de reprise LangGraph. Vide : <DATA_DIR>/db/agent_checkpoints.db, à côté de
    # hermes.db (DATA_DIR est passé par `agent_lifespan(data_dir=...)`).
    checkpoint_db: str | None = None
    checkpoint_ttl_days: int = 30

    # Catalogue : forcer l'activation ou la désactivation d'outils après la découverte.
    enabled_tools: Annotated[list[str], NoDecode] = []
    disabled_tools: Annotated[list[str], NoDecode] = []

    # Passerelle API interne.
    forward_headers: Annotated[list[str], NoDecode] = [
        "x-csrf-token",
        "origin",
        "accept-language",
    ]
    internal_base_url: str = "http://hermes.internal"
    gateway_timeout_s: float = 60.0
    max_response_bytes: int = 5_000_000

    timezone: str = "Europe/Paris"

    @field_validator(
        "enabled_tools", "disabled_tools", "forward_headers", mode="before"
    )
    @classmethod
    def _csv(cls, value: object) -> object:
        return _split_csv(value)

    @field_validator("rate_limit")
    @classmethod
    def _check_rate(cls, value: str) -> str:
        if not _RATE_RE.match(value):
            raise ValueError(
                "format attendu : '<messages>/<durée><s|min|h>', par exemple '30/5min'"
            )
        return value

    @property
    def rate_limit_count(self) -> int:
        match = _RATE_RE.match(self.rate_limit)
        assert match is not None
        return int(match.group(1))

    @property
    def rate_limit_window_s(self) -> int:
        match = _RATE_RE.match(self.rate_limit)
        assert match is not None
        return int(match.group(2)) * _UNIT_S[match.group(3)]

    @property
    def use_responses_api(self) -> bool | None:
        """Valeur de `use_responses_api` pour ChatOpenAI (None : choix de langchain-openai)."""
        return {"auto": None, "chat": False, "responses": True}[self.openai_api]
