"""Registre des outils : déclaration, filtrage par rôle et par phase, schémas pour le modèle.

Chaque outil déclare les routes qu'il appelle ; la passerelle n'accepte que celles-là.
Un outil d'écriture déclare en plus un constructeur de carte (`@outil.card`), exécuté par
le code et jamais rédigé par le modèle.
"""

from __future__ import annotations

import copy
import importlib
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel

from .domain import Confirmation, PageContext, Role, UserContext

if TYPE_CHECKING:
    from .config import AgentSettings
    from .gateway import ApiGateway


@dataclass(frozen=True)
class RouteRef:
    method: str
    template: str


@dataclass
class ToolOutcome:
    """Résultat d'un outil : `content` part vers le modèle, `ui` vers le panneau."""

    content: Any
    ui: dict[str, Any] | None = None
    ok: bool = True
    http_status: int | None = None
    error: str | None = None
    result: dict[str, Any] | None = None  # résumé conservé dans agent_tool_calls


@dataclass
class CardField:
    label: str
    value: str


@dataclass
class EditableField:
    name: str
    label: str
    kind: str  # "enum" | "text"
    value: str | None = None
    options: list[str] = field(default_factory=list)
    required: bool = True
    min_length: int = 0
    max_length: int = 1000


@dataclass
class CardDraft:
    """Contenu d'une carte d'action, produit par le code de l'outil."""

    title: str
    fields: list[CardField]
    impact: str
    warnings: list[str] = field(default_factory=list)
    editable: list[EditableField] = field(default_factory=list)
    # Valeurs de pré-remplissage à substituer aux arguments du modèle (ex. motif vidé).
    overrides: dict[str, Any] = field(default_factory=dict)


@dataclass
class ToolContext:
    gateway: ApiGateway
    settings: AgentSettings
    user: UserContext
    conversation_id: str
    tool_call_id: str
    page_context: PageContext | None
    emit: Callable[[dict[str, Any]], None]
    recent_user_texts: Callable[[], Awaitable[list[str]]]


Handler = Callable[[ToolContext, Any], Awaitable[ToolOutcome]]
CardBuilder = Callable[[ToolContext, Any], Awaitable[CardDraft]]


class ToolSpec:
    def __init__(
        self,
        *,
        name: str,
        label: str,
        description: str,
        args_model: type[BaseModel],
        min_role: Role,
        phase: int,
        confirmation: Confirmation,
        routes: tuple[RouteRef, ...],
        handler: Handler,
        editable_fields: tuple[str, ...] = (),
        enabled_by_default: bool = True,
        status_note: str = "",
    ) -> None:
        self.name = name
        self.label = label
        self.description = description
        self.args_model = args_model
        self.min_role = min_role
        self.phase = phase
        self.confirmation = confirmation
        self.routes = routes
        self.handler = handler
        self.editable_fields = editable_fields
        self.enabled_by_default = enabled_by_default
        self.status_note = status_note
        self.card_builder: CardBuilder | None = None

    @property
    def is_write(self) -> bool:
        return self.confirmation is not Confirmation.NONE

    def card(self, builder: CardBuilder) -> CardBuilder:
        """Décorateur : enregistre le constructeur de carte d'un outil d'écriture."""
        self.card_builder = builder
        return builder

    def model_schema(self) -> dict[str, Any]:
        """Définition au format OpenAI, acceptée par les intégrations LangChain."""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": _inline_schema(self.args_model.model_json_schema()),
            },
        }

    def describe(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "label": self.label,
            "min_role": self.min_role.value,
            "phase": self.phase,
            "confirmation": self.confirmation.value,
            "routes": [f"{r.method} {r.template}" for r in self.routes],
            "enabled_by_default": self.enabled_by_default,
            "status_note": self.status_note,
        }


REGISTRY: dict[str, ToolSpec] = {}


def hermes_tool(
    *,
    name: str,
    label: str,
    description: str,
    args: type[BaseModel],
    min_role: Role = Role.USER,
    phase: int = 1,
    confirmation: Confirmation = Confirmation.NONE,
    routes: tuple[tuple[str, str], ...] = (),
    editable_fields: tuple[str, ...] = (),
    enabled_by_default: bool = True,
    status_note: str = "",
) -> Callable[[Handler], ToolSpec]:
    def decorator(handler: Handler) -> ToolSpec:
        if name in REGISTRY:
            raise ValueError(f"outil déclaré deux fois : {name}")
        spec = ToolSpec(
            name=name,
            label=label,
            description=description,
            args_model=args,
            min_role=min_role,
            phase=phase,
            confirmation=confirmation,
            routes=tuple(RouteRef(m.upper(), t) for m, t in routes),
            handler=handler,
            editable_fields=editable_fields,
            enabled_by_default=enabled_by_default,
            status_note=status_note,
        )
        REGISTRY[name] = spec
        return spec

    return decorator


def load_tools() -> dict[str, ToolSpec]:
    """Importe les modules d'outils (une seule fois) et vérifie leur cohérence."""
    importlib.import_module(f"{__package__}.tools")
    for spec in REGISTRY.values():
        if spec.is_write and spec.card_builder is None:
            raise RuntimeError(f"l'outil d'écriture {spec.name} n'a pas de carte")
        unknown = set(spec.editable_fields) - set(spec.args_model.model_fields)
        if unknown:
            raise RuntimeError(
                f"{spec.name} : champs modifiables inconnus {sorted(unknown)}"
            )
    return REGISTRY


def is_enabled(spec: ToolSpec, settings: AgentSettings) -> bool:
    if spec.name in settings.disabled_tools:
        return False
    return spec.enabled_by_default or spec.name in settings.enabled_tools


def tools_for(user: UserContext, settings: AgentSettings) -> dict[str, ToolSpec]:
    """Outils présentés au modèle : activés, ouverts par la phase et permis par le rôle."""
    return {
        name: spec
        for name, spec in load_tools().items()
        if is_enabled(spec, settings)
        and spec.phase <= settings.phase
        and user.can(spec.min_role)
    }


def allowed_routes(tools: dict[str, ToolSpec]) -> set[tuple[str, str]]:
    return {(r.method, r.template) for spec in tools.values() for r in spec.routes}


def _inline_schema(schema: dict[str, Any]) -> dict[str, Any]:
    """Remplace les $ref par leur définition et retire les titres : certains fournisseurs les refusent."""
    defs = schema.get("$defs", {})

    def resolve(node: Any, mapping: bool = False) -> Any:
        if isinstance(node, dict):
            if (
                mapping
            ):  # {nom de propriété: schéma} : un champ peut s'appeler « title »
                return {name: resolve(sub) for name, sub in node.items()}
            if "$ref" in node:
                target = resolve(copy.deepcopy(defs[node["$ref"].split("/")[-1]]))
                siblings = {k: v for k, v in node.items() if k not in ("$ref", "title")}
                return {**target, **resolve(siblings)}
            return {
                k: resolve(v, mapping=(k == "properties"))
                for k, v in node.items()
                if k not in ("title", "$defs")
            }
        if isinstance(node, list):
            return [resolve(item) for item in node]
        return node

    resolved = resolve(schema)
    resolved.setdefault("type", "object")
    resolved.setdefault("properties", {})
    return resolved
