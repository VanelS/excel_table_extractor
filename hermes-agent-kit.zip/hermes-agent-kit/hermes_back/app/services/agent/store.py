"""Persistance de l'agent : conversations, messages, appels d'outils, verrou et débit.

Tout est tenu en base, jamais en mémoire : la production tourne avec plusieurs workers.
Chaque méthode ouvre une transaction courte et la valide aussitôt : aucune écriture de
l'agent ne reste ouverte pendant un appel à la passerelle (SQLite n'a qu'un écrivain).
Les méthodes sont synchrones ; le service les appelle via `anyio.to_thread.run_sync`.
"""

from __future__ import annotations

import uuid
from collections.abc import Iterable
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from sqlalchemy import Engine, text
from sqlalchemy.exc import IntegrityError

SCHEMA_SQL = Path(__file__).with_name("schema.sql")

_TOOL_CALL_COLUMNS = frozenset(
    {
        "message_id",
        "level",
        "model_call_id",
        "args_json",
        "submitted_json",
        "payload_hash",
        "card_json",
        "status",
        "lease_until",
        "decided_at",
        "executed_at",
        "expires_at",
        "http_status",
        "result_summary_json",
        "error",
        "model_name",
        "prompt_version",
        "input_tokens",
        "output_tokens",
    }
)


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def iso(moment: datetime) -> str:
    """Format unique des dates en base : les comparaisons de chaînes restent justes."""
    return moment.astimezone(timezone.utc).isoformat(timespec="microseconds")


def new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex}"


class DuplicateRequest(Exception):
    pass


class RateLimitExceeded(Exception):
    pass


def _rows(result: Any) -> list[dict[str, Any]]:
    return [dict(r._mapping) for r in result]


class AgentStore:
    def __init__(self, engine: Engine) -> None:
        self.engine = engine

    # -- schéma -------------------------------------------------------------------
    def ensure_schema(self, sql_path: Path = SCHEMA_SQL) -> None:
        """Pour les tests et le développement ; en production, c'est la migration v016."""
        with self.engine.begin() as conn:
            for statement in schema_statements(sql_path):
                conn.execute(text(statement))

    # -- conversations ------------------------------------------------------------
    def create_conversation(
        self, user_sub: str, scope: str = "global", run_id: str | None = None
    ) -> dict[str, Any]:
        now = iso(utcnow())
        row: dict[str, Any] = {
            "id": new_id("conv"),
            "user_sub": user_sub,
            "scope": scope,
            "run_id": run_id,
            "created_at": now,
            "updated_at": now,
        }
        with self.engine.begin() as conn:
            conn.execute(
                text(
                    "INSERT INTO agent_conversations (id, user_sub, scope, run_id, created_at, updated_at) "
                    "VALUES (:id, :user_sub, :scope, :run_id, :created_at, :updated_at)"
                ),
                row,
            )
        return self.get_conversation(row["id"]) or row

    def get_conversation(self, conversation_id: str) -> dict[str, Any] | None:
        with self.engine.connect() as conn:
            rows = _rows(
                conn.execute(
                    text("SELECT * FROM agent_conversations WHERE id = :id"),
                    {"id": conversation_id},
                )
            )
        return rows[0] if rows else None

    def list_conversations(
        self, user_sub: str, limit: int = 50
    ) -> list[dict[str, Any]]:
        with self.engine.connect() as conn:
            return _rows(
                conn.execute(
                    text(
                        "SELECT id, scope, run_id, title, created_at, updated_at, purged_at FROM agent_conversations "
                        "WHERE user_sub = :u AND archived_at IS NULL ORDER BY updated_at DESC LIMIT :n"
                    ),
                    {"u": user_sub, "n": limit},
                )
            )

    def update_conversation(self, conversation_id: str, **fields: Any) -> None:
        allowed = {"title", "archived_at", "purged_at"}
        fields = {k: v for k, v in fields.items() if k in allowed}
        fields["updated_at"] = iso(utcnow())
        assignments = ", ".join(f"{k} = :{k}" for k in fields)
        with self.engine.begin() as conn:
            conn.execute(
                text(f"UPDATE agent_conversations SET {assignments} WHERE id = :id"),
                {**fields, "id": conversation_id},
            )

    def set_title_if_empty(self, conversation_id: str, title: str) -> None:
        with self.engine.begin() as conn:
            conn.execute(
                text(
                    "UPDATE agent_conversations SET title = :t WHERE id = :id AND title IS NULL"
                ),
                {"t": title, "id": conversation_id},
            )

    # Verrou de tour : il appartient au tour qui l'a pris (jeton), qui le renouvelle tant qu'il
    # tourne et le libère à la fin. Un tour ne peut ni prolonger ni libérer le verrou d'un autre.
    def acquire_turn_lock(self, conversation_id: str, ttl_s: int, token: str) -> bool:
        now = utcnow()
        with self.engine.begin() as conn:
            result = conn.execute(
                text(
                    "UPDATE agent_conversations SET turn_lock_until = :until, turn_lock_owner = :token, "
                    "updated_at = :now "
                    "WHERE id = :id AND (turn_lock_until IS NULL OR turn_lock_until < :now)"
                ),
                {
                    "until": iso(now + timedelta(seconds=ttl_s)),
                    "now": iso(now),
                    "id": conversation_id,
                    "token": token,
                },
            )
        return result.rowcount == 1

    def renew_turn_lock(self, conversation_id: str, ttl_s: int, token: str) -> bool:
        with self.engine.begin() as conn:
            result = conn.execute(
                text(
                    "UPDATE agent_conversations SET turn_lock_until = :until "
                    "WHERE id = :id AND turn_lock_owner = :token"
                ),
                {
                    "until": iso(utcnow() + timedelta(seconds=ttl_s)),
                    "id": conversation_id,
                    "token": token,
                },
            )
        return result.rowcount == 1

    def release_turn_lock(self, conversation_id: str, token: str) -> None:
        with self.engine.begin() as conn:
            conn.execute(
                text(
                    "UPDATE agent_conversations SET turn_lock_until = NULL, turn_lock_owner = NULL "
                    "WHERE id = :id AND turn_lock_owner = :token"
                ),
                {"id": conversation_id, "token": token},
            )

    def conversations_to_purge(self, before: datetime) -> list[str]:
        with self.engine.connect() as conn:
            rows = conn.execute(
                text(
                    "SELECT id FROM agent_conversations WHERE purged_at IS NULL AND updated_at < :b"
                ),
                {"b": iso(before)},
            )
            return [r[0] for r in rows]

    # -- messages -----------------------------------------------------------------
    def add_message(
        self,
        conversation_id: str,
        user_sub: str,
        role: str,
        content: str,
        *,
        request_id: str | None = None,
        model_name: str | None = None,
        prompt_version: str | None = None,
        input_tokens: int | None = None,
        output_tokens: int | None = None,
        rate_limit: tuple[int, datetime] | None = None,
    ) -> dict[str, Any]:
        """Enregistre un message. Avec `rate_limit=(n, depuis)`, l'insertion n'a lieu que si
        l'utilisateur a envoyé moins de n messages depuis cette date : le comptage et
        l'insertion forment une seule instruction, donc des requêtes parallèles ne passent pas."""
        row: dict[str, Any] = {
            "id": new_id("msg"),
            "conversation_id": conversation_id,
            "user_sub": user_sub,
            "role": role,
            "content": content,
            "request_id": request_id,
            "model_name": model_name,
            "prompt_version": prompt_version,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "created_at": iso(utcnow()),
        }
        insert = (
            "INSERT INTO agent_messages (id, conversation_id, user_sub, role, content, request_id, model_name, "
            "prompt_version, input_tokens, output_tokens, created_at) SELECT :id, :conversation_id, :user_sub, "
            ":role, :content, :request_id, :model_name, :prompt_version, :input_tokens, :output_tokens, :created_at"
        )
        params = dict(row)
        if rate_limit is not None:
            insert += (
                " WHERE (SELECT COUNT(*) FROM agent_messages WHERE user_sub = :user_sub AND role = 'user' "
                "AND created_at >= :since) < :limit"
            )
            params.update(limit=rate_limit[0], since=iso(rate_limit[1]))
        try:
            with self.engine.begin() as conn:
                if conn.execute(text(insert), params).rowcount != 1:
                    raise RateLimitExceeded(user_sub)
                conn.execute(
                    text(
                        "UPDATE agent_conversations SET updated_at = :t WHERE id = :id"
                    ),
                    {"t": row["created_at"], "id": conversation_id},
                )
        except IntegrityError as exc:
            raise DuplicateRequest(request_id) from exc
        return row

    def has_message(self, conversation_id: str, role: str, content: str) -> bool:
        with self.engine.connect() as conn:
            return (
                conn.execute(
                    text(
                        "SELECT 1 FROM agent_messages WHERE conversation_id = :c AND role = :r "
                        "AND content = :t LIMIT 1"
                    ),
                    {"c": conversation_id, "r": role, "t": content},
                ).first()
                is not None
            )

    def run_started_here(self, conversation_id: str, run_id: str) -> bool:
        """Le run a-t-il été lancé ou rejoué par une action exécutée de cette conversation ?"""
        needle = f'"run_id":"{run_id}"'
        with self.engine.connect() as conn:
            return (
                conn.execute(
                    text(
                        "SELECT 1 FROM agent_tool_calls WHERE conversation_id = :c AND kind = 'write' "
                        "AND status = 'executed' AND instr(result_summary_json, :needle) > 0 LIMIT 1"
                    ),
                    {"c": conversation_id, "needle": needle},
                ).first()
                is not None
            )

    def find_message_by_request(
        self, conversation_id: str, request_id: str
    ) -> dict[str, Any] | None:
        with self.engine.connect() as conn:
            rows = _rows(
                conn.execute(
                    text(
                        "SELECT * FROM agent_messages WHERE conversation_id = :c AND request_id = :r"
                    ),
                    {"c": conversation_id, "r": request_id},
                )
            )
        return rows[0] if rows else None

    def reply_after(
        self, conversation_id: str, created_at: str
    ) -> dict[str, Any] | None:
        """Réponse de l'assistant à un message : la première avant le message suivant."""
        with self.engine.connect() as conn:
            rows = _rows(
                conn.execute(
                    text(
                        "SELECT * FROM agent_messages WHERE conversation_id = :c AND role = 'assistant' "
                        "AND created_at > :t AND created_at < COALESCE(("
                        "  SELECT MIN(created_at) FROM agent_messages WHERE conversation_id = :c "
                        "  AND role IN ('user', 'event') AND created_at > :t), '9999') "
                        "ORDER BY created_at LIMIT 1"
                    ),
                    {"c": conversation_id, "t": created_at},
                )
            )
        return rows[0] if rows else None

    def turn_in_progress(self, conversation_id: str) -> bool:
        with self.engine.connect() as conn:
            until = conn.execute(
                text("SELECT turn_lock_until FROM agent_conversations WHERE id = :id"),
                {"id": conversation_id},
            ).scalar_one_or_none()
        return bool(until) and until > iso(utcnow())

    def list_messages(
        self, conversation_id: str, limit: int = 200
    ) -> list[dict[str, Any]]:
        with self.engine.connect() as conn:
            rows = _rows(
                conn.execute(
                    text(
                        "SELECT id, role, content, model_name, created_at FROM agent_messages "
                        "WHERE conversation_id = :c ORDER BY created_at DESC, id DESC LIMIT :n"
                    ),
                    {"c": conversation_id, "n": limit},
                )
            )
        return list(reversed(rows))

    def recent_user_texts(self, conversation_id: str, limit: int = 10) -> list[str]:
        with self.engine.connect() as conn:
            rows = conn.execute(
                text(
                    "SELECT content FROM agent_messages WHERE conversation_id = :c AND role = 'user' "
                    "ORDER BY created_at DESC LIMIT :n"
                ),
                {"c": conversation_id, "n": limit},
            )
            return [r[0] for r in rows]

    def count_user_messages(self, user_sub: str, since: datetime) -> int:
        with self.engine.connect() as conn:
            return int(
                conn.execute(
                    text(
                        "SELECT COUNT(*) FROM agent_messages WHERE user_sub = :u AND role = 'user' AND created_at >= :s"
                    ),
                    {"u": user_sub, "s": iso(since)},
                ).scalar_one()
            )

    # -- appels d'outils et actions ---------------------------------------------------
    def insert_tool_call(self, row: dict[str, Any]) -> None:
        columns = ", ".join(row)
        values = ", ".join(f":{k}" for k in row)
        with self.engine.begin() as conn:
            conn.execute(
                text(f"INSERT INTO agent_tool_calls ({columns}) VALUES ({values})"), row
            )

    def get_tool_call(self, call_id: str) -> dict[str, Any] | None:
        with self.engine.connect() as conn:
            rows = _rows(
                conn.execute(
                    text("SELECT * FROM agent_tool_calls WHERE id = :id"),
                    {"id": call_id},
                )
            )
        return rows[0] if rows else None

    def update_tool_call(self, call_id: str, **fields: Any) -> None:
        self._check_columns(fields)
        assignments = ", ".join(f"{k} = :{k}" for k in fields)
        with self.engine.begin() as conn:
            conn.execute(
                text(f"UPDATE agent_tool_calls SET {assignments} WHERE id = :id"),
                {**fields, "id": call_id},
            )

    def transition(
        self, call_id: str, from_status: str, to_status: str, **fields: Any
    ) -> bool:
        """Changement de statut conditionnel : un double clic n'exécute rien deux fois."""
        self._check_columns(fields)
        sets = ", ".join(["status = :to_status", *(f"{k} = :{k}" for k in fields)])
        with self.engine.begin() as conn:
            result = conn.execute(
                text(
                    f"UPDATE agent_tool_calls SET {sets} WHERE id = :id AND status = :from_status"
                ),
                {
                    **fields,
                    "id": call_id,
                    "from_status": from_status,
                    "to_status": to_status,
                },
            )
        return result.rowcount == 1

    def pending_action(self, conversation_id: str) -> dict[str, Any] | None:
        with self.engine.connect() as conn:
            rows = _rows(
                conn.execute(
                    text(
                        "SELECT * FROM agent_tool_calls WHERE conversation_id = :c AND kind = 'write' "
                        "AND status = 'proposed' ORDER BY proposed_at DESC LIMIT 1"
                    ),
                    {"c": conversation_id},
                )
            )
        return rows[0] if rows else None

    def statuses_by_model_call(
        self, conversation_id: str, model_call_ids: Iterable[str]
    ) -> dict[str, dict[str, Any]]:
        ids = list(model_call_ids)
        if not ids:
            return {}
        placeholders = ", ".join(f":id{i}" for i in range(len(ids)))
        params = {f"id{i}": v for i, v in enumerate(ids)}
        with self.engine.connect() as conn:
            rows = _rows(
                conn.execute(
                    text(
                        "SELECT model_call_id, status, result_summary_json, error FROM agent_tool_calls "
                        f"WHERE conversation_id = :c AND model_call_id IN ({placeholders})"
                    ),
                    {"c": conversation_id, **params},
                )
            )
        return {r["model_call_id"]: r for r in rows}

    def fail_expired_leases(self) -> int:
        """Actions restées `executing` au-delà de leur bail (redémarrage, plantage)."""
        now = iso(utcnow())
        with self.engine.begin() as conn:
            result = conn.execute(
                text(
                    "UPDATE agent_tool_calls SET status = 'failed', error = 'interrompue', lease_until = NULL "
                    "WHERE status = 'executing' AND lease_until < :now"
                ),
                {"now": now},
            )
        return result.rowcount

    def fail_stale_confirmed(self, before: datetime) -> int:
        """Actions confirmées dont l'exécution n'a jamais commencé (worker arrêté entre les deux)."""
        with self.engine.begin() as conn:
            result = conn.execute(
                text(
                    "UPDATE agent_tool_calls SET status = 'failed', error = 'non exécutée' "
                    "WHERE status = 'confirmed' AND decided_at < :before"
                ),
                {"before": iso(before)},
            )
        return result.rowcount

    def recent_tool_calls(
        self, conversation_id: str, limit: int = 20
    ) -> list[dict[str, Any]]:
        with self.engine.connect() as conn:
            return _rows(
                conn.execute(
                    text(
                        "SELECT id, tool_name, kind, status, proposed_at, executed_at, result_summary_json, error "
                        "FROM agent_tool_calls WHERE conversation_id = :c ORDER BY proposed_at DESC LIMIT :n"
                    ),
                    {"c": conversation_id, "n": limit},
                )
            )

    @staticmethod
    def _check_columns(fields: dict[str, Any]) -> None:
        unknown = set(fields) - _TOOL_CALL_COLUMNS
        if unknown:
            raise ValueError(f"colonnes inconnues : {sorted(unknown)}")


def _strip_comments(sql: str) -> str:
    return "\n".join(line.split("--", 1)[0] for line in sql.splitlines())


def schema_statements(path: Path = SCHEMA_SQL) -> list[str]:
    """Instructions de schema.sql, sans commentaires, une par élément.

    Utilisé par `ensure_schema` et par la migration v016 de l'application, qui les exécute
    une à une sur sa connexion (`conn.execute(instruction)`). Toutes sont idempotentes.
    """
    sql = _strip_comments(path.read_text(encoding="utf-8"))
    return [s.strip() for s in sql.split(";") if s.strip()]
