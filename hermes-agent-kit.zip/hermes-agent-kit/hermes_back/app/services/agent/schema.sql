-- Tables de l'agent Hermes. Idempotent (IF NOT EXISTS partout).
-- La migration v016 (gabarit modeles/v016_agent.py, procédure étape 5) en contient une copie
-- figée : une migration appliquée ne change plus. Toute évolution du schéma passe par une
-- nouvelle migration ; ce fichier décrit alors le schéma cumulé, utilisé par les tests et
-- par `AgentStore.ensure_schema` en développement.
--
-- Écart assumé avec la spécification (section 10) : l'agent a ses propres tables au lieu
-- d'étendre ChatConversation / ChatMessage, pour ne rien changer au Chat v2.

CREATE TABLE IF NOT EXISTS agent_conversations (
    id TEXT PRIMARY KEY,                    -- conv_<hex>
    user_sub TEXT NOT NULL,
    scope TEXT NOT NULL DEFAULT 'global',   -- global | run
    run_id TEXT,
    title TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    archived_at TEXT,
    purged_at TEXT,                         -- points de reprise purgés : lecture seule
    turn_lock_until TEXT,                   -- verrou de tour, tenu en base (plusieurs workers)
    turn_lock_owner TEXT                    -- jeton du tour qui détient le verrou
);
CREATE INDEX IF NOT EXISTS ix_agent_conversations_user ON agent_conversations(user_sub, updated_at);

CREATE TABLE IF NOT EXISTS agent_messages (
    id TEXT PRIMARY KEY,                    -- msg_<hex>
    conversation_id TEXT NOT NULL,
    user_sub TEXT NOT NULL,
    role TEXT NOT NULL,                     -- user | assistant | event
    content TEXT NOT NULL,
    request_id TEXT,                        -- déduplication des renvois du navigateur
    model_name TEXT,
    prompt_version TEXT,
    input_tokens INTEGER,
    output_tokens INTEGER,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_agent_messages_conv ON agent_messages(conversation_id, created_at);
CREATE INDEX IF NOT EXISTS ix_agent_messages_user ON agent_messages(user_sub, role, created_at);
CREATE UNIQUE INDEX IF NOT EXISTS ux_agent_messages_request
    ON agent_messages(conversation_id, request_id) WHERE request_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS agent_tool_calls (
    id TEXT PRIMARY KEY,                    -- act_<hex> (écriture) ou tc_<hex> (lecture)
    conversation_id TEXT NOT NULL,
    message_id TEXT,
    user_sub TEXT NOT NULL,
    tool_name TEXT NOT NULL,
    kind TEXT NOT NULL,                     -- read | write
    level TEXT,                             -- simple | reinforced
    model_call_id TEXT,                     -- identifiant de l'appel d'outil côté modèle
    args_json TEXT NOT NULL,                -- arguments proposés par le modèle
    submitted_json TEXT,                    -- arguments soumis par l'utilisateur
    payload_hash TEXT,                      -- empreinte des paramètres finaux
    card_json TEXT,                         -- carte affichée, produite par le code
    status TEXT NOT NULL,                   -- ok | error | proposed | confirmed | executing | executed | failed | rejected | cancelled | expired
    lease_until TEXT,                       -- bail d'une action executing
    proposed_at TEXT NOT NULL,
    decided_at TEXT,
    executed_at TEXT,
    expires_at TEXT,
    http_status INTEGER,
    result_summary_json TEXT,               -- run_id, disposition_id, lignes réussies ou en échec
    error TEXT,
    model_name TEXT,
    prompt_version TEXT,
    input_tokens INTEGER,                   -- jetons du tour qui a proposé l'action
    output_tokens INTEGER
);
CREATE INDEX IF NOT EXISTS ix_agent_tool_calls_conv ON agent_tool_calls(conversation_id, status);
CREATE INDEX IF NOT EXISTS ix_agent_tool_calls_user ON agent_tool_calls(user_sub, proposed_at);
CREATE INDEX IF NOT EXISTS ix_agent_tool_calls_model_call ON agent_tool_calls(model_call_id);
