"""Agent conversationnel Hermes.

Le paquet reste léger à l'import : `context` est importé par le journal d'activité
de l'application, qui ne doit pas charger LangGraph pour autant. Les points d'entrée
de l'intégration sont dans `wiring.py` (`agent_lifespan`, `include_agent_router`).
"""
