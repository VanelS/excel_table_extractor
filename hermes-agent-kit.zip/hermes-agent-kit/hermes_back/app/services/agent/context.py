"""Marque « via Hermes » des appels faits par l'agent.

Le graphe pose une variable de contexte autour de chaque appel d'outil. Elle traverse la
passerelle (`ASGITransport`) jusqu'aux routes, y compris les routes `def` exécutées dans le
pool de threads. Le journal d'activité la lit avec `activity_annotation()`.

La marque ne vient jamais d'un en-tête HTTP : le navigateur ne peut donc pas la forger.
Ce module n'importe rien de lourd, pour pouvoir être importé par le journal d'activité.
"""

from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass


@dataclass(frozen=True)
class AgentCallContext:
    conversation_id: str
    tool_call_id: str
    tool_name: str
    user_sub: str


_current: ContextVar[AgentCallContext | None] = ContextVar(
    "hermes_agent_call", default=None
)


def current_agent_call() -> AgentCallContext | None:
    """Appel d'outil en cours, ou None si la requête ne vient pas de l'agent."""
    return _current.get()


def activity_annotation() -> dict[str, str]:
    """Champs à fusionner dans la `description` du journal d'activité (vide hors agent)."""
    call = _current.get()
    if call is None:
        return {}
    return {
        "via": "hermes",
        "agent_conversation_id": call.conversation_id,
        "agent_tool_call_id": call.tool_call_id,
        "agent_tool": call.tool_name,
    }


@contextmanager
def agent_call_scope(call: AgentCallContext) -> Iterator[None]:
    token = _current.set(call)
    try:
        yield
    finally:
        _current.reset(token)
