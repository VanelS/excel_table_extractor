"""Service de l'agent : conversations, tours, décisions, flux d'événements SSE.

- Les contrôles qui renvoient un code HTTP (404, 409, 422, 429) sont faits dans
  `prepare_message` et `prepare_decision`, avant l'ouverture du flux.
- Chaque tour tourne ensuite dans une tâche de fond, détachée de la connexion : le flux SSE ne
  fait que relayer ses événements. Une déconnexion du navigateur n'interrompt donc ni le tour ni
  une action confirmée ; le panneau relit l'état par `GET /conversations/{id}`.
- Le verrou de tour appartient à la tâche (jeton) : elle le renouvelle tant qu'elle tourne et le
  libère à la fin, après la fin de toute action en cours d'exécution dans la conversation.
- Une action confirmée dont l'exécution n'a pas commencé quand le tour s'arrête passe en
  `failed` (« non exécutée ») : aucune action ne reste confirmée sans suite.
"""

from __future__ import annotations

import asyncio
import functools
import json
import logging
from collections.abc import AsyncIterator, Callable
from contextlib import aclosing, suppress
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any, Literal

import anyio
from anyio import to_thread
from langchain_core.messages import AIMessage, AIMessageChunk, HumanMessage
from langgraph.types import Command
from pydantic import BaseModel, Field, model_validator

from .actions import (
    CANCELLED,
    CONFIRMED,
    EXPIRED,
    FAILED,
    PROPOSED,
    REJECTED,
    EditRejected,
    apply_edits,
    is_written_confirmation,
    payload_hash,
)
from .config import AgentSettings
from .domain import ID_PATTERN, PageContext, Role, UserContext, page_of
from .gateway import ApiGateway, RequestMeta
from .graph import TurnContext, wait_executions
from .llm import ModelProvider, message_text
from .prompts import PROMPT_VERSION
from .registry import allowed_routes, load_tools, tools_for
from .store import (
    AgentStore,
    DuplicateRequest,
    RateLimitExceeded,
    iso,
    new_id,
    utcnow,
)

log = logging.getLogger("hermes.agent.service")


# -- erreurs renvoyées en code HTTP ---------------------------------------------------------
class AgentError(Exception):
    status = 400

    def __init__(self, detail: str) -> None:
        super().__init__(detail)
        self.detail = detail


class NotFound(AgentError):
    status = 404


class Conflict(AgentError):
    status = 409


class Unprocessable(AgentError):
    status = 422


class RateLimited(AgentError):
    status = 429


# -- corps des requêtes ---------------------------------------------------------------------
class RunEvent(BaseModel):
    type: Literal["run_completed"]
    run_id: str = Field(pattern=ID_PATTERN)


class Attachment(BaseModel):
    """Fichier de données déjà déposé dans data/inputs par le téléversement existant."""

    name: str = Field(pattern=r"^[\w .()-]{1,200}$")


class MessageIn(BaseModel):
    request_id: str = Field(pattern=r"^[A-Za-z0-9_-]{8,64}$")
    content: str | None = Field(default=None, max_length=4000)
    event: RunEvent | None = None
    page_context: PageContext | None = None
    attachments: list[Attachment] = Field(default_factory=list, max_length=10)

    @model_validator(mode="after")
    def _one_of(self) -> MessageIn:
        has_content = bool(self.content and self.content.strip())
        if has_content == (self.event is not None):
            raise ValueError("fournir soit 'content', soit 'event'")
        return self


class DecisionIn(BaseModel):
    decision: Literal["confirm", "reject"]
    payload_hash: str = Field(pattern=r"^sha256:[0-9a-f]{64}$")
    edited_fields: dict[str, str] = Field(default_factory=dict)


class ConversationIn(BaseModel):
    scope: Literal["global", "run"] = "global"
    run_id: str | None = Field(default=None, pattern=ID_PATTERN)

    @model_validator(mode="after")
    def _run_scope(self) -> ConversationIn:
        if self.scope == "run" and not self.run_id:
            raise ValueError("une conversation 'run' exige run_id")
        return self


def sse(event: str, data: dict[str, Any]) -> dict[str, str]:
    return {"event": event, "data": json.dumps(data, ensure_ascii=False, default=str)}


def _expired(action: dict[str, Any], now: datetime) -> bool:
    return bool(action.get("expires_at")) and action["expires_at"] < iso(now)


_SUGGESTIONS = {
    Role.USER: [
        "Quels contrôles ont de nouveaux KO cette semaine ?",
        "Montre-moi les derniers runs de section_setting.",
        "Exporte le rapport Excel du dernier run.",
    ],
    Role.USER_MANAGER: ["Relance le dernier run de section_setting."],
}


@dataclass
class PreparedTurn:
    """Tour prêt : `start()` le lance en tâche de fond, `events()` relaie ses événements."""

    service: AgentService
    conversation_id: str
    user: UserContext
    meta: RequestMeta
    page_context: PageContext | None = None
    graph_input: Any = None
    pre_events: list[dict[str, str]] = field(default_factory=list)
    # Réponse fixe, sans modèle : enregistrée comme nouveau message, sauf si elle rejoue
    # une réponse déjà enregistrée (`replayed_id`, renvoi du navigateur).
    fixed_reply: str | None = None
    replayed_id: str | None = None
    lock_token: str | None = None
    confirmed_action_id: str | None = None  # action confirmée par ce tour, à exécuter
    task: asyncio.Task[None] | None = None
    _queue: asyncio.Queue[dict[str, str] | None] = field(default_factory=asyncio.Queue)

    def emit(self, event: dict[str, str] | None) -> None:
        self._queue.put_nowait(event)

    def start(self) -> None:
        self.task = self.service.launch(self)

    async def events(self) -> AsyncIterator[dict[str, str]]:
        """Relaie les événements du tour. Une déconnexion n'arrête que le relais."""
        while True:
            event = await self._queue.get()
            if event is None:
                return
            yield event


class AgentService:
    def __init__(
        self,
        *,
        app: Any,
        settings: AgentSettings,
        store: AgentStore,
        graph: Any,
        models: ModelProvider,
        checkpointer: Any = None,
    ) -> None:
        self.app = app
        self.settings = settings
        self.store = store
        self.graph = graph
        self.models = models
        self.checkpointer = checkpointer
        self.turns: set[asyncio.Task[None]] = set()
        # Actions en cours d'exécution, par conversation (tâches protégées du graphe).
        self.executions: dict[str, set[asyncio.Task[Any]]] = {}
        self.closing = False

    async def db(self, fn: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
        return await to_thread.run_sync(functools.partial(fn, *args, **kwargs))

    def _config(self, conversation_id: str) -> dict[str, Any]:
        # Plafond d'étapes du graphe au-dessus des budgets du tour (appel modèle + outils).
        limit = 2 * self.settings.max_iterations + 10
        return {
            "configurable": {"thread_id": conversation_id},
            "recursion_limit": limit,
        }

    async def _owned(self, user: UserContext, conversation_id: str) -> dict[str, Any]:
        conv = await self.db(self.store.get_conversation, conversation_id)
        if not conv or conv["user_sub"] != user.sub or conv["archived_at"]:
            raise NotFound("Conversation introuvable.")
        return conv

    # -- lecture -------------------------------------------------------------------------
    async def capabilities(
        self, user: UserContext, page_route: str | None = None
    ) -> dict[str, Any]:
        tools = tools_for(user, self.settings)
        suggestions = list(_SUGGESTIONS[Role.USER])
        if user.can(Role.USER_MANAGER):
            suggestions += _SUGGESTIONS[Role.USER_MANAGER]
        if page_route and page_of(page_route) == "execution":
            suggestions.insert(0, "Résume les nouveaux KO de ce run.")
        return {
            "phase": self.settings.phase,
            "tools": [
                {"name": s.name, "label": s.label, "confirmation": s.confirmation.value}
                for s in tools.values()
            ],
            "suggestions": suggestions,
        }

    async def create_conversation(
        self, user: UserContext, body: ConversationIn
    ) -> dict[str, Any]:
        return await self.db(
            self.store.create_conversation, user.sub, body.scope, body.run_id
        )

    async def list_conversations(self, user: UserContext) -> list[dict[str, Any]]:
        return await self.db(self.store.list_conversations, user.sub)

    async def get_conversation(
        self, user: UserContext, conversation_id: str
    ) -> dict[str, Any]:
        conv = await self._owned(user, conversation_id)
        messages = await self.db(self.store.list_messages, conversation_id)
        pending = await self.db(self.store.pending_action, conversation_id)
        card = None
        if pending and not _expired(pending, utcnow()) and pending.get("card_json"):
            card = json.loads(pending["card_json"])
        actions = await self.db(self.store.recent_tool_calls, conversation_id)
        return {
            "conversation": {
                k: v for k, v in conv.items() if k not in ("turn_lock_owner",)
            },
            "messages": messages,
            "pending_action": card,
            "recent_tool_calls": actions,
        }

    async def archive(self, user: UserContext, conversation_id: str) -> None:
        await self._owned(user, conversation_id)
        await self.db(
            self.store.update_conversation, conversation_id, archived_at=iso(utcnow())
        )

    # -- verrou de tour ----------------------------------------------------------------
    async def _lock(self, conversation_id: str) -> str:
        token = new_id("lock")
        if not await self.db(
            self.store.acquire_turn_lock,
            conversation_id,
            self.settings.turn_lock_s,
            token,
        ):
            raise Conflict("Un tour est déjà en cours dans cette conversation.")
        return token

    async def _keep_lock(self, turn: PreparedTurn) -> None:
        interval = max(1.0, self.settings.turn_lock_s / 3)
        while True:
            await asyncio.sleep(interval)
            renewed = await self.db(
                self.store.renew_turn_lock,
                turn.conversation_id,
                self.settings.turn_lock_s,
                turn.lock_token,
            )
            if not renewed:
                log.warning("verrou de tour perdu : %s", turn.conversation_id)
                return

    # -- tour : message ------------------------------------------------------------------
    async def prepare_message(
        self,
        user: UserContext,
        conversation_id: str,
        body: MessageIn,
        meta: RequestMeta,
    ) -> PreparedTurn:
        conv = await self._owned(user, conversation_id)
        if conv["purged_at"]:
            raise Conflict(
                "Conversation ancienne passée en lecture seule : ouvrez-en une nouvelle."
            )
        turn = PreparedTurn(
            self, conversation_id, user, meta, page_context=body.page_context
        )

        previous = await self.db(
            self.store.find_message_by_request, conversation_id, body.request_id
        )
        if previous:
            # Renvoi du navigateur : on rejoue la réponse, sans rappeler le modèle.
            reply = await self.db(
                self.store.reply_after, conversation_id, previous["created_at"]
            )
            if reply is None and await self.db(
                self.store.turn_in_progress, conversation_id
            ):
                raise Conflict("Ce message est encore en cours de traitement.")
            turn.fixed_reply = reply["content"] if reply else ""
            turn.replayed_id = reply["id"] if reply else None
            turn.start()
            return turn

        turn.lock_token = await self._lock(conversation_id)
        try:
            await self._fill_message_turn(turn, body)
        except BaseException:
            await self.db(
                self.store.release_turn_lock, conversation_id, turn.lock_token
            )
            raise
        turn.start()
        return turn

    async def _fill_message_turn(self, turn: PreparedTurn, body: MessageIn) -> None:
        s, conv_id, user = self.settings, turn.conversation_id, turn.user
        if body.event is not None:
            role, stored = "event", f"run_completed:{body.event.run_id}"
            # Un événement n'est retenu qu'une fois, et pour un run lancé dans cette conversation.
            if not await self.db(
                self.store.run_started_here, conv_id, body.event.run_id
            ) or await self.db(self.store.has_message, conv_id, "event", stored):
                turn.fixed_reply = ""
                return
            model_text = (
                f"[Événement de l'application] Le run {body.event.run_id} est terminé. "
                "Résume son résultat en une ou deux phrases, en citant ses compteurs."
            )
            limit = None
        else:
            role, stored = "user", (body.content or "").strip()
            model_text = stored
            if body.attachments:
                names = ", ".join(a.name for a in body.attachments)
                model_text += f"\n\nFichiers joints, déposés dans data/inputs : {names}"
            limit = (
                s.rate_limit_count,
                utcnow() - timedelta(seconds=s.rate_limit_window_s),
            )
        try:
            message = await self.db(
                self.store.add_message,
                conv_id,
                user.sub,
                role,
                stored,
                request_id=body.request_id,
                rate_limit=limit,
            )
        except DuplicateRequest:
            turn.fixed_reply = ""
            return
        except RateLimitExceeded as exc:
            raise RateLimited(
                "Trop de messages : réessayez dans quelques minutes."
            ) from exc
        if (
            role == "user"
        ):  # titre de la liste des conversations : début du premier message
            title = stored if len(stored) <= 80 else stored[:79] + "…"
            await self.db(self.store.set_title_if_empty, conv_id, title)

        now = utcnow()
        pending = await self.db(self.store.pending_action, conv_id)
        if pending is not None:
            if body.event is not None:
                # Un événement de fin de run n'annule rien : la carte reste en attente.
                turn.fixed_reply = ""
                return
            if _expired(pending, now):
                await self.db(
                    self.store.transition,
                    pending["id"],
                    PROPOSED,
                    EXPIRED,
                    decided_at=iso(now),
                )
                turn.pre_events.append(
                    sse(
                        "action.updated",
                        {"action_id": pending["id"], "status": EXPIRED},
                    )
                )
            elif is_written_confirmation(stored) and await self._interrupt_matches(
                conv_id, pending["id"]
            ):
                if pending["level"] != "simple" or not self._submittable(pending):
                    turn.fixed_reply = (
                        "Pour cette action, confirmez avec le bouton de la carte."
                    )
                    return
                # Confirmation écrite : décision « confirm » sur les paramètres stockés.
                if await self.db(
                    self.store.transition,
                    pending["id"],
                    PROPOSED,
                    CONFIRMED,
                    decided_at=iso(now),
                    submitted_json=pending["args_json"],
                ):
                    turn.confirmed_action_id = pending["id"]
                    turn.pre_events.append(
                        sse(
                            "action.updated",
                            {"action_id": pending["id"], "status": CONFIRMED},
                        )
                    )
                    turn.graph_input = Command(
                        resume={"decision": "confirm", "action_id": pending["id"]}
                    )
                    return
            else:
                await self.db(
                    self.store.transition,
                    pending["id"],
                    PROPOSED,
                    CANCELLED,
                    decided_at=iso(now),
                )
                turn.pre_events.append(
                    sse(
                        "action.updated",
                        {"action_id": pending["id"], "status": CANCELLED},
                    )
                )

        turn.graph_input = {
            "messages": [HumanMessage(content=model_text, id=message["id"])],
            "iterations": 0,
            "tool_calls": 0,
            "pending_tool_call": None,
            "pending_action_id": None,
            "decision": None,
        }

    @staticmethod
    def _submittable(action: dict[str, Any]) -> bool:
        """Les paramètres stockés passent-ils la validation de soumission, sans modification ?"""
        spec = load_tools().get(action["tool_name"])
        if spec is None:
            return False
        try:
            apply_edits(spec, json.loads(action["args_json"]), {})
        except EditRejected:
            return False
        return True

    async def _interrupt_matches(self, conversation_id: str, action_id: str) -> bool:
        snapshot = await self.graph.aget_state(self._config(conversation_id))
        ids = [
            i.value.get("action_id")
            for i in getattr(snapshot, "interrupts", ())
            if isinstance(i.value, dict)
        ]
        return action_id in ids

    # -- tour : décision -----------------------------------------------------------------
    async def prepare_decision(
        self,
        user: UserContext,
        conversation_id: str,
        action_id: str,
        body: DecisionIn,
        meta: RequestMeta,
    ) -> PreparedTurn:
        await self._owned(user, conversation_id)
        action = await self.db(self.store.get_tool_call, action_id)
        if (
            not action
            or action["conversation_id"] != conversation_id
            or action["kind"] != "write"
        ):
            raise NotFound("Action introuvable.")
        turn = PreparedTurn(self, conversation_id, user, meta)
        turn.lock_token = await self._lock(conversation_id)
        try:
            await self._fill_decision_turn(turn, action, body)
        except BaseException:
            await self.db(
                self.store.release_turn_lock, conversation_id, turn.lock_token
            )
            raise
        turn.start()
        return turn

    async def _fill_decision_turn(
        self, turn: PreparedTurn, action: dict[str, Any], body: DecisionIn
    ) -> None:
        action_id, now = action["id"], utcnow()
        if action["status"] != PROPOSED:
            raise Conflict(f"Action déjà traitée (statut {action['status']}).")
        if not await self._interrupt_matches(turn.conversation_id, action_id):
            await self.db(
                self.store.transition,
                action_id,
                PROPOSED,
                CANCELLED,
                decided_at=iso(now),
            )
            raise Conflict("Cette action n'est plus en attente.")
        if _expired(action, now):
            await self.db(
                self.store.transition, action_id, PROPOSED, EXPIRED, decided_at=iso(now)
            )
            decision = "expired"
        elif body.payload_hash != action["payload_hash"]:
            raise Unprocessable(
                "La carte affichée ne correspond plus à l'action : rechargez la conversation."
            )
        elif body.decision == "reject":
            if not await self.db(
                self.store.transition,
                action_id,
                PROPOSED,
                REJECTED,
                decided_at=iso(now),
            ):
                raise Conflict("Action déjà traitée.")
            decision = "reject"
        else:
            spec = load_tools().get(action["tool_name"])
            if spec is None:
                raise Conflict("Outil inconnu.")
            try:
                final_args = apply_edits(
                    spec, json.loads(action["args_json"]), body.edited_fields
                )
            except EditRejected as exc:
                raise Unprocessable(f"Champs refusés : {exc}") from exc
            moved = await self.db(
                self.store.transition,
                action_id,
                PROPOSED,
                CONFIRMED,
                decided_at=iso(now),
                submitted_json=json.dumps(final_args, ensure_ascii=False),
                payload_hash=payload_hash(spec.name, final_args),
            )
            if not moved:
                raise Conflict("Action déjà traitée.")
            turn.confirmed_action_id = action_id
            decision = "confirm"
        status = {"confirm": CONFIRMED, "reject": REJECTED, "expired": EXPIRED}[
            decision
        ]
        turn.pre_events.append(
            sse("action.updated", {"action_id": action_id, "status": status})
        )
        turn.graph_input = Command(
            resume={"decision": decision, "action_id": action_id}
        )

    # -- déroulement d'un tour, détaché de la connexion ------------------------------------
    def launch(self, turn: PreparedTurn) -> asyncio.Task[None]:
        task = asyncio.ensure_future(self._run_turn(turn))
        self.turns.add(task)
        task.add_done_callback(self.turns.discard)
        return task

    async def _run_turn(self, turn: PreparedTurn) -> None:
        heartbeat = (
            asyncio.ensure_future(self._keep_lock(turn)) if turn.lock_token else None
        )
        try:
            for event in turn.pre_events:
                turn.emit(event)
            if turn.fixed_reply is not None:
                await self._emit_fixed_reply(turn)
                return
            with anyio.fail_after(self.settings.turn_timeout_s):
                async with aclosing(self.run_graph(turn)) as stream:
                    async for event in stream:
                        turn.emit(event)
        except TimeoutError:
            log.warning("tour trop long : %s", turn.conversation_id)
            turn.emit(
                sse(
                    "error",
                    {
                        "code": "TurnTimeout",
                        "message": "Le tour a dépassé sa durée maximale.",
                    },
                )
            )
        except Exception as exc:
            log.exception("tour en erreur")
            turn.emit(
                sse(
                    "error",
                    {
                        "code": type(exc).__name__,
                        "message": "Le tour s'est arrêté sur une erreur technique.",
                    },
                )
            )
        finally:
            with anyio.CancelScope(shield=True):
                await self._finish_turn(turn, heartbeat)
                turn.emit(None)

    async def _emit_fixed_reply(self, turn: PreparedTurn) -> None:
        if turn.fixed_reply:
            message_id = turn.replayed_id
            if message_id is None:
                row = await self.db(
                    self.store.add_message,
                    turn.conversation_id,
                    turn.user.sub,
                    "assistant",
                    turn.fixed_reply,
                )
                message_id = row["id"]
            turn.emit(
                sse(
                    "message.completed",
                    {
                        "message_id": message_id,
                        "content": turn.fixed_reply,
                        "model": None,
                        "fallback": False,
                        "usage": None,
                    },
                )
            )
        turn.emit(sse("done", {"interrupted": False}))

    async def _finish_turn(
        self, turn: PreparedTurn, heartbeat: asyncio.Task[None] | None
    ) -> None:
        """Fin de tour : attendre l'action en cours, solder une confirmation sans suite,
        puis seulement libérer le verrou."""
        try:
            await wait_executions(
                self.executions,
                turn.conversation_id,
                timeout=0 if self.closing else self.settings.action_lease_s,
            )
            if turn.confirmed_action_id and await self.db(
                self.store.transition,
                turn.confirmed_action_id,
                CONFIRMED,
                FAILED,
                error="non exécutée : le tour s'est arrêté avant l'exécution",
            ):
                turn.emit(
                    sse(
                        "action.updated",
                        {"action_id": turn.confirmed_action_id, "status": FAILED},
                    )
                )
        except Exception:
            log.exception("fin de tour en erreur")
        finally:
            if heartbeat is not None:
                heartbeat.cancel()
                with suppress(asyncio.CancelledError):
                    await heartbeat
            if turn.lock_token:
                await self.db(
                    self.store.release_turn_lock, turn.conversation_id, turn.lock_token
                )

    async def drain(self, grace_s: float) -> None:
        """Arrêt de l'application : laisse finir tours et actions, dans la limite donnée."""
        self.closing = True
        if self.turns:
            await asyncio.wait(set(self.turns), timeout=grace_s)
        await wait_executions(self.executions, None, timeout=grace_s)
        for task in set(self.turns):
            task.cancel()

    # -- exécution du graphe ---------------------------------------------------------------
    async def run_graph(self, turn: PreparedTurn) -> AsyncIterator[dict[str, str]]:
        tools = tools_for(turn.user, self.settings)
        gateway = ApiGateway(
            self.app,
            allowed=allowed_routes(tools),
            meta=turn.meta,
            base_url=self.settings.internal_base_url,
            timeout_s=self.settings.gateway_timeout_s,
            max_bytes=self.settings.max_response_bytes,
        )
        context = TurnContext(
            conversation_id=turn.conversation_id,
            user=turn.user,
            page_context=turn.page_context,
            gateway=gateway,
            store=self.store,
            settings=self.settings,
            tools=tools,
            models=self.models,
            executions=self.executions,
        )
        final: AIMessage | None = None
        interrupted = False
        proposed_id: str | None = None
        model_name: str | None = None
        fallback_used = (
            False  # au moins un appel du tour servi par le modèle de secours
        )
        # Jetons de tous les appels au modèle du tour : rattachés à la réponse finale, ou à
        # l'action proposée quand le tour s'arrête sur une carte.
        usage = {"input_tokens": 0, "output_tokens": 0}
        async for mode, chunk in self.graph.astream(
            turn.graph_input,
            self._config(turn.conversation_id),
            context=context,
            stream_mode=["messages", "custom", "updates"],
        ):
            if mode == "messages":
                message, metadata = chunk
                if metadata.get("langgraph_node") == "call_model" and isinstance(
                    message, AIMessageChunk
                ):
                    text = message_text(message)
                    if text:
                        # `id` regroupe les fragments d'un même message du modèle.
                        yield sse("message.delta", {"id": message.id, "text": text})
            elif mode == "custom":
                if isinstance(chunk, dict) and "event" in chunk:
                    data = chunk.get("data") or {}
                    if chunk["event"] == "action.proposed":
                        proposed_id = data.get("action_id")
                    yield sse(chunk["event"], data)
            elif mode == "updates":
                if "__interrupt__" in chunk:
                    interrupted = True
                update = chunk.get("call_model")
                if update:
                    last = update["messages"][-1]
                    if isinstance(last, AIMessage):
                        for key in usage:
                            usage[key] += (last.usage_metadata or {}).get(key) or 0
                        model_name = (
                            last.response_metadata.get("model_name") or model_name
                        )
                        if last.response_metadata.get("hermes_model_role") == "secours":
                            fallback_used = True
                        if not last.tool_calls:
                            final = last
        if final is not None:
            row = await self.db(
                self.store.add_message,
                turn.conversation_id,
                turn.user.sub,
                "assistant",
                message_text(final),
                model_name=model_name,
                prompt_version=PROMPT_VERSION,
                input_tokens=usage["input_tokens"],
                output_tokens=usage["output_tokens"],
            )
            yield sse(
                "message.completed",
                {
                    "message_id": row["id"],
                    "content": row["content"],
                    "model": model_name,
                    "fallback": fallback_used,
                    "usage": usage,
                },
            )
        elif proposed_id is not None:
            await self.db(
                self.store.update_tool_call,
                proposed_id,
                model_name=model_name,
                input_tokens=usage["input_tokens"],
                output_tokens=usage["output_tokens"],
            )
        yield sse("done", {"interrupted": interrupted})
