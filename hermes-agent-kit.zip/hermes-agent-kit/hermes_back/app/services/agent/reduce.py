"""Réduction des résultats avant envoi au modèle : lignes plafonnées, textes tronqués,
données personnelles retirées."""

from __future__ import annotations

import json
import re
from collections.abc import Iterable
from typing import Any

_MAX_VALUE_CHARS = 200

# -- données personnelles (section 11 de la spécification) ------------------------------------
# Tant que le RSSI et le DPO n'ont pas tranché (option A ou B), tout ce qui part vers le modèle
# perd les champs d'identité et les adresses électroniques, quel que soit leur nom de colonne.
# Les noms de personnes contenus dans les données métier (managers…) ne sont pas détectables
# ainsi : ils relèvent de la décision A/B. Option B (pseudonymisation) : remplacer `scrub`.
_EMAIL_RE = re.compile(r"[\w.+-]+@[\w-]+(?:\.[\w-]+)+")
_PERSONAL_KEY_RE = re.compile(
    r"(mail|courriel|author|auteur|full_?name|nom_complet|username|user_name|login|"
    r"_by$|^by_|owner|proprietaire|propriétaire)",
    re.IGNORECASE,
)
EMAIL_MASK = "[adresse masquée]"


def mask_text(text: str) -> str:
    return _EMAIL_RE.sub(EMAIL_MASK, text)


def scrub(value: Any) -> Any:
    """Retire les champs d'identité (par nom de clé) et masque les adresses électroniques."""
    if isinstance(value, dict):
        return {
            k: scrub(v) for k, v in value.items() if not _PERSONAL_KEY_RE.search(str(k))
        }
    if isinstance(value, (list, tuple)):
        return [scrub(v) for v in value]
    if isinstance(value, str):
        return mask_text(value)
    return value


def first_value(
    row: dict[str, Any] | None, keys: Iterable[str], default: Any = None
) -> Any:
    """Première clé présente : les noms de champs exacts de l'API sont à confirmer à la découverte."""
    if not isinstance(row, dict):
        return default
    for key in keys:
        if row.get(key) not in (None, ""):
            return row[key]
    return default


def _shorten(value: Any) -> Any:
    if isinstance(value, str) and len(value) > _MAX_VALUE_CHARS:
        return value[:_MAX_VALUE_CHARS] + "…"
    if isinstance(value, dict):
        return {k: _shorten(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_shorten(v) for v in value[:20]]
    return value


def reduce_rows(rows: list[Any], max_rows: int) -> tuple[list[Any], bool]:
    return [_shorten(r) for r in rows[:max_rows]], len(rows) > max_rows


def items_of(data: Any) -> list[Any]:
    """Liste brute, ou liste rangée sous `items` (cas de `RowsPageResponse`)."""
    if isinstance(data, list):
        return data
    if isinstance(data, dict) and isinstance(data.get("items"), list):
        return data["items"]
    return []


def compact(payload: Any, max_chars: int) -> str:
    """JSON compact pour le modèle, tronqué proprement s'il dépasse le budget."""
    text = json.dumps(payload, ensure_ascii=False, default=str, separators=(",", ":"))
    if len(text) <= max_chars:
        return text
    return text[:max_chars] + "…(tronqué)"


def table_card(
    rows: list[dict[str, Any]],
    *,
    title: str,
    max_columns: int = 6,
    link: str | None = None,
) -> dict[str, Any]:
    """Carte « tableau » pour le panneau : 10 lignes au plus, colonnes de la première ligne."""
    shown = [r for r in rows[:10] if isinstance(r, dict)]
    columns = list(shown[0].keys())[:max_columns] if shown else []
    return {
        "kind": "table",
        "title": title,
        "columns": columns,
        "rows": [[_shorten(r.get(c)) for c in columns] for r in shown],
        "total_shown": len(shown),
        "link": link,
    }
