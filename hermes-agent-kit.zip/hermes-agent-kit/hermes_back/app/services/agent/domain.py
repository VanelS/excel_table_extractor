"""Types métier de l'agent : rôles, utilisateur, niveaux de confirmation, contexte de page."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Literal
from urllib.parse import quote

from pydantic import BaseModel, Field, field_validator, model_validator

# Identifiants insérés dans un chemin d'URL : lettres, chiffres, _ et - uniquement.
ID_PATTERN = r"^[A-Za-z0-9_-]{1,128}$"
VERSION_PATTERN = r"^v\d{3}$"
_PARAM_RE = re.compile(r"^[\w.:-]{1,128}$")
_KEY_RE = re.compile(r"^[\w .:/#|-]{1,200}$")


class Role(str, Enum):
    USER = "USER"
    USER_MANAGER = "USER_MANAGER"
    ADMIN = "ADMIN"


_RANK = {Role.USER: 1, Role.USER_MANAGER: 2, Role.ADMIN: 3}


@dataclass(frozen=True)
class UserContext:
    """Utilisateur courant, relu de la session à chaque tour et à chaque décision."""

    sub: str
    email: str | None = None
    roles: frozenset[str] = field(default_factory=frozenset)

    def rank(self) -> int:
        ranks = [_RANK[Role(r)] for r in self.roles if r in Role._value2member_map_]
        return max(ranks, default=0)

    def can(self, min_role: Role) -> bool:
        """ADMIN englobe USER_MANAGER, qui englobe USER (section 7.4 de la doc)."""
        return self.rank() >= _RANK[min_role]

    @property
    def role_names(self) -> list[str]:
        return sorted(self.roles)


def default_user_mapper(user: Any) -> UserContext:
    """Convertit l'utilisateur renvoyé par la dépendance d'authentification de l'application.

    Gère un dict ou un objet portant `sub`, `email` et `roles` (forme de `CurrentUserResponse`).
    À remplacer à l'intégration si la dépendance renvoie une autre forme.
    """

    def get(name: str) -> Any:
        return user.get(name) if isinstance(user, dict) else getattr(user, name, None)

    sub = get("sub")
    if not sub:
        raise ValueError("utilisateur sans identifiant 'sub'")
    return UserContext(
        sub=str(sub), email=get("email"), roles=frozenset(get("roles") or ())
    )


class Confirmation(str, Enum):
    NONE = "none"
    SIMPLE = "simple"
    REINFORCED = "reinforced"


# -- Pages de l'interface (app.routes.ts, section 4.1 de la documentation) ---------------------
# Seul endroit du kit où figurent les chemins de l'interface : liste blanche du contexte de page,
# outil open_page, liens des cartes et tests les lisent ici. À l'intégration (étape 8), aligner
# les valeurs sur app.routes.ts, noms de paramètres compris (`:id` plutôt que `:controlId`, par
# exemple), sans changer les clés. Une page que l'interface n'a pas : retirer son entrée.
PAGES: dict[str, str] = {
    "home": "/",
    "loader": "/charger-donnees",
    "settings": "/parametres",
    "controls": "/controls",
    "control": "/controls/:controlId",
    "executions": "/executions",
    "execution": "/executions/:runId",
    "execution_audit": "/executions/:runId/audit",
    "analytics": "/analytics",
}

# Identifiant porté par l'unique paramètre des pages qui en ont un. Le nom du paramètre dans
# la route n'a pas d'importance pour le code.
PAGE_IDS: dict[str, str] = {
    "control": "control_id",
    "execution": "run_id",
    "execution_audit": "run_id",
}


def route_params(route: str) -> set[str]:
    return {part[1:] for part in route.split("/") if part.startswith(":")}


def _checked_routes() -> tuple[str, ...]:
    """Échoue au chargement si PAGES a été mal modifié."""
    for page, route in PAGES.items():
        expected = 1 if page in PAGE_IDS else 0
        if not route.startswith("/") or len(route_params(route)) != expected:
            raise ValueError(
                f"PAGES[{page!r}] = {route!r} : {expected} paramètre(s) de route attendu(s)"
            )
    if len(set(PAGES.values())) != len(PAGES):
        raise ValueError("PAGES : deux pages ont le même chemin")
    return tuple(PAGES.values())


APP_ROUTES: tuple[str, ...] = _checked_routes()


def page_of(route: str) -> str | None:
    """Clé de PAGES d'un gabarit de route, None s'il est inconnu."""
    return next((page for page, value in PAGES.items() if value == route), None)


def page_params(page: str, value: str) -> dict[str, str]:
    """Paramètres de route d'une page à identifiant, quel que soit le nom du paramètre :
    page_params("execution", "01J…") → {"runId": "01J…"} (ou {"id": "01J…"} après alignement)."""
    return {name: value for name in route_params(PAGES[page])}


def page_url(page: str, value: str | None = None) -> str | None:
    """Chemin concret d'une page, ou None si l'interface ne l'a pas.

    page_url("executions") → "/executions" ; page_url("execution", "01J…") → "/executions/01J…".
    """
    route = PAGES.get(page)
    if route is None:
        return None
    if page not in PAGE_IDS:
        return route
    if not value:
        raise ValueError(f"identifiant requis pour la page {page}")
    return "/".join(
        quote(value, safe="") if part.startswith(":") else part
        for part in route.split("/")
    )


class SelectionItem(BaseModel):
    identity_key: str
    rule_name: str

    @field_validator("identity_key", "rule_name")
    @classmethod
    def _check(cls, value: str) -> str:
        if not _KEY_RE.fullmatch(value):
            raise ValueError("valeur hors du motif autorisé")
        return value


class Selection(BaseModel):
    kind: Literal["anomaly_rows"]
    run_id: str = Field(pattern=ID_PATTERN)
    items: list[SelectionItem] = Field(default_factory=list, max_length=50)


class PageContext(BaseModel):
    """Page affichée et sélection, envoyées par le panneau avec chaque message.

    C'est une donnée, pas une consigne : seul le gabarit de route (issu de la liste blanche)
    entre dans le prompt ; les identifiants et la sélection passent par l'outil `get_page_context`.
    """

    route: str
    params: dict[str, str] = Field(default_factory=dict)
    selection: Selection | None = None

    @model_validator(mode="after")
    def _check(self) -> PageContext:
        if self.route not in APP_ROUTES:
            raise ValueError(f"route inconnue : {self.route}")
        expected = route_params(self.route)
        if set(self.params) != expected:
            raise ValueError(
                f"paramètres attendus pour {self.route} : {sorted(expected)}"
            )
        for value in self.params.values():
            if not _PARAM_RE.fullmatch(value):
                raise ValueError("paramètre de route hors du motif autorisé")
        return self
