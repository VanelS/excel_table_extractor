"""Outil « plateforme » : état de santé (version, suivi MLflow, alertes)."""

from __future__ import annotations

from pydantic import BaseModel

from ..registry import ToolContext, ToolOutcome, hermes_tool
from ._common import http_failure, redact


class NoArgs(BaseModel):
    pass


@hermes_tool(
    name="get_platform_status",
    label="Je vérifie l'état de la plateforme",
    description="État de la plateforme : version, connexion au suivi MLflow, alertes système.",
    args=NoArgs,
    routes=(("GET", "/api/health"),),
)
async def get_platform_status(ctx: ToolContext, args: NoArgs) -> ToolOutcome:
    response = await ctx.gateway.call("GET", "/api/health")
    if not response.ok:
        return http_failure(response, "État de la plateforme indisponible")
    return ToolOutcome(content=redact(response.data), result={"ok": True})
