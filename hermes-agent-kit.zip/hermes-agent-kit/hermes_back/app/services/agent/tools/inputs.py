"""Outil « fichiers d'entrée » : fichiers déposés dans data/inputs, utilisables comme sources.

`GET /api/inputs` n'est pas documenté (section 14 de la spécification, « endpoints à
recenser ») : l'outil reste désactivé tant que la découverte ne l'a pas confirmé.
"""

from __future__ import annotations

from pydantic import BaseModel, Field

from ..domain import page_url
from ..reduce import first_value, items_of, reduce_rows, table_card
from ..registry import ToolContext, ToolOutcome, hermes_tool
from ._common import http_failure

_FILE_FIELDS = {
    "name": ("filename", "name", "file", "path"),
    "size_bytes": ("size_bytes", "size"),
    "uploaded_at": ("uploaded_at", "created_at", "modified_at"),
}


class ListInputsArgs(BaseModel):
    search: str | None = Field(
        default=None, max_length=100, description="Texte à chercher dans le nom."
    )


@hermes_tool(
    name="list_input_files",
    label="Je consulte les fichiers déposés",
    description=(
        "Fichiers déposés dans data/inputs, utilisables comme sources d'un run "
        "(différents des classeurs du chargeur de données)."
    ),
    args=ListInputsArgs,
    routes=(("GET", "/api/inputs"),),
    enabled_by_default=False,
    status_note="GET /api/inputs à confirmer à la découverte.",
)
async def list_input_files(ctx: ToolContext, args: ListInputsArgs) -> ToolOutcome:
    response = await ctx.gateway.call("GET", "/api/inputs")
    if not response.ok:
        return http_failure(response, "Liste des fichiers déposés indisponible")
    files = []
    for raw in items_of(response.data):
        if isinstance(raw, str):
            files.append({"name": raw})
        elif isinstance(raw, dict):
            files.append(
                {
                    k: first_value(raw, names)
                    for k, names in _FILE_FIELDS.items()
                    if first_value(raw, names) is not None
                }
            )
    if args.search:
        needle = args.search.casefold()
        files = [f for f in files if needle in str(f.get("name", "")).casefold()]
    shown, truncated = reduce_rows(files, ctx.settings.max_rows_to_model)
    return ToolOutcome(
        content={"nombre": len(files), "fichiers": shown, "tronque": truncated},
        ui=table_card(shown, title="Fichiers déposés", link=page_url("loader")),
        result={"nombre": len(files)},
    )
