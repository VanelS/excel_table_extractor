"""Catalogue des outils de Hermes : chaque module enregistre ses outils à l'import.

Pour ajouter un outil, voir la procédure d'intégration, annexe A. Un nouveau module s'importe
ici et s'ajoute à `__all__` (qui dit aussi aux linters que l'import est voulu).
"""

from . import (
    controls,
    dispositions,
    executions,
    inputs,
    loader,
    navigation,
    platform,
)

__all__ = [
    "controls",
    "dispositions",
    "executions",
    "inputs",
    "loader",
    "navigation",
    "platform",
]
