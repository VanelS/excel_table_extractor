"""Outils « jugements » : consultation (phase 1), jugement et révocation (phase 2, renforcés).

Règles propres aux jugements (section 7 de la spécification) :
- le jugement et le motif sont des champs modifiables de la carte ;
- le motif n'est pré-rempli que s'il figure dans les messages de l'utilisateur, sinon il reste
  vide et la confirmation est refusée tant qu'il n'est pas saisi ;
- 20 lignes au plus par carte ; la version du contrôle et le run d'origine sont joints d'office ;
- un échec en cours de lot fait passer l'action à `failed`, avec les lignes enregistrées et
  celles en échec dans `result_summary_json`.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field, ValidationInfo, model_validator
from pydantic.json_schema import SkipJsonSchema

from ..actions import appears_in, is_submit
from ..domain import ID_PATTERN, VERSION_PATTERN, Confirmation, Role
from ..reduce import first_value, items_of, reduce_rows, table_card
from ..registry import (
    CardDraft,
    CardField,
    EditableField,
    ToolContext,
    ToolOutcome,
    hermes_tool,
)
from ._common import (
    control_link,
    detail_of,
    http_failure,
    link_card,
    redact,
    run_link,
    run_summary,
)

Judgment = Literal["OK_EXCEPTION", "FALSE_POSITIVE", "ACCEPTED_RISK", "TRANSFERRED"]
JUDGMENTS: list[str] = [
    "OK_EXCEPTION",
    "FALSE_POSITIVE",
    "ACCEPTED_RISK",
    "TRANSFERRED",
]
REASON_MIN, REASON_MAX = 3, 1000

_DISPOSITION_FIELDS: dict[str, tuple[str, ...]] = {
    "disposition_id": ("disposition_id", "id"),
    "identity_key": ("identity_key",),
    "rule_name": ("rule_name", "control_rule"),
    "judgment": ("judgment", "disposition_judgment"),
    "reason": ("reason",),
    "run_id": ("run_id",),
    "control_version": ("control_version", "version"),
    "created_at": ("created_at", "decided_at"),
}


def disposition_summary(raw: Any) -> dict[str, Any]:
    out = {}
    for key, candidates in _DISPOSITION_FIELDS.items():
        value = first_value(raw, candidates)
        if value is not None:
            out[key] = value
    return out


class ListDispositionsArgs(BaseModel):
    control_id: str = Field(pattern=ID_PATTERN, description="Contrôle concerné.")
    rule_name: str | None = Field(default=None, pattern=r"^[\w.:-]{1,128}$")
    identity_key: str | None = Field(default=None, max_length=200)
    judgment: Judgment | None = None


class AnomalyRef(BaseModel):
    identity_key: str = Field(
        pattern=r"^[\w .:/#|-]{1,200}$", description="Clé d'identité de la ligne."
    )
    rule_name: str = Field(
        pattern=r"^[\w.:-]{1,128}$", description="Règle de contrôle en KO."
    )


class CreateDispositionsArgs(BaseModel):
    run_id: str = Field(pattern=ID_PATTERN, description="Run d'où viennent les lignes.")
    items: list[AnomalyRef] = Field(
        min_length=1,
        max_length=50,
        description="Lignes à juger (20 au plus par carte).",
    )
    judgment: Judgment | None = Field(
        default=None,
        description="Jugement demandé par l'utilisateur. Ne jamais le choisir à sa place : null s'il ne l'a pas dit.",
    )
    reason: str = Field(
        default="",
        max_length=REASON_MAX,
        description="Motif, avec les mots exacts de l'utilisateur. Chaîne vide s'il n'en a pas donné.",
    )
    # Renseignés par la carte à partir du run, absents du schéma montré au modèle.
    control_id: SkipJsonSchema[str | None] = Field(default=None, pattern=ID_PATTERN)
    control_version: SkipJsonSchema[str | None] = Field(
        default=None, pattern=VERSION_PATTERN
    )

    @model_validator(mode="after")
    def _complete_on_submit(self, info: ValidationInfo) -> CreateDispositionsArgs:
        if is_submit(info):
            if self.judgment is None:
                raise ValueError("jugement à choisir")
            if len(self.reason.strip()) < REASON_MIN:
                raise ValueError(f"motif à saisir ({REASON_MIN} caractères au moins)")
            if not self.control_id or not self.control_version:
                raise ValueError("contrôle ou version du run manquants")
        return self


class RevokeDispositionArgs(BaseModel):
    control_id: str = Field(pattern=ID_PATTERN, description="Contrôle du jugement.")
    disposition_id: str = Field(
        pattern=ID_PATTERN, description="Identifiant du jugement à révoquer."
    )


# -- lecture --------------------------------------------------------------------------------
@hermes_tool(
    name="list_dispositions",
    label="Je consulte les jugements",
    description=(
        "Jugements actifs d'un contrôle (ligne, règle, jugement, motif, run), "
        "filtrables par règle, clé d'identité ou jugement."
    ),
    args=ListDispositionsArgs,
    routes=(("GET", "/api/controls/{control_id}/dispositions"),),
)
async def list_dispositions(
    ctx: ToolContext, args: ListDispositionsArgs
) -> ToolOutcome:
    response = await ctx.gateway.call(
        "GET",
        "/api/controls/{control_id}/dispositions",
        path_params={"control_id": args.control_id},
    )
    if not response.ok:
        return http_failure(response, f"Jugements de {args.control_id}")
    rows = [disposition_summary(d) for d in items_of(response.data)]
    if args.rule_name:
        rows = [r for r in rows if r.get("rule_name") == args.rule_name]
    if args.identity_key:
        rows = [r for r in rows if r.get("identity_key") == args.identity_key]
    if args.judgment:
        rows = [r for r in rows if r.get("judgment") == args.judgment]
    shown, truncated = reduce_rows(redact(rows), ctx.settings.max_rows_to_model)
    return ToolOutcome(
        content={"nombre": len(rows), "jugements": shown, "tronque": truncated},
        ui=table_card(
            shown,
            title=f"Jugements de {args.control_id}",
            link=control_link(args.control_id),
        ),
        result={"control_id": args.control_id, "nombre": len(rows)},
    )


# -- écriture : jugement -------------------------------------------------------------------
@hermes_tool(
    name="create_dispositions",
    label="Juger des anomalies",
    description=(
        "Enregistre un jugement sur 1 à 20 lignes en KO d'un run. Le jugement et le motif viennent "
        "de l'utilisateur, jamais de vous : laissez-les vides s'il ne les a pas donnés, la carte "
        "les lui fera saisir. Au-delà de 20 lignes, ouvrez la page du run."
    ),
    args=CreateDispositionsArgs,
    min_role=Role.USER_MANAGER,
    phase=2,
    confirmation=Confirmation.REINFORCED,
    routes=(
        ("GET", "/api/executions/{run_id}"),
        ("GET", "/api/executions/{run_id}/rows"),
        ("POST", "/api/controls/{control_id}/dispositions"),
    ),
    editable_fields=("judgment", "reason"),
)
async def create_dispositions(
    ctx: ToolContext, args: CreateDispositionsArgs
) -> ToolOutcome:
    recorded: list[dict[str, Any]] = []
    failed: list[dict[str, Any]] = []
    for item in args.items:
        response = await ctx.gateway.call(
            "POST",
            "/api/controls/{control_id}/dispositions",
            path_params={"control_id": args.control_id},
            json_body={
                "identity_key": item.identity_key,
                "rule_name": item.rule_name,
                "judgment": args.judgment,
                "reason": args.reason,
                "control_version": args.control_version,
                "run_id": args.run_id,
            },
        )
        line: dict[str, Any] = {
            "identity_key": item.identity_key,
            "rule_name": item.rule_name,
        }
        if response.ok:
            line["disposition_id"] = first_value(
                response.data, ("disposition_id", "id")
            )
            recorded.append(line)
        else:
            line.update(http_status=response.status, detail=detail_of(response))
            failed.append(line)
    result = {"recorded": recorded, "failed": failed}
    if failed:
        return ToolOutcome(
            content=(
                f"{len(recorded)} ligne(s) jugée(s), {len(failed)} en échec : {failed}. "
                "Ne reproposez que les lignes en échec, si l'utilisateur le demande."
            ),
            ok=False,
            http_status=failed[0]["http_status"],
            error=f"{len(failed)} ligne(s) en échec",
            result=result,
        )
    return ToolOutcome(
        content=f"{len(recorded)} ligne(s) jugée(s) {args.judgment} sur le run {args.run_id}.",
        ui=link_card("Voir le run", run_link(args.run_id)),
        result=result,
    )


@create_dispositions.card
async def create_dispositions_card(
    ctx: ToolContext, args: CreateDispositionsArgs
) -> CardDraft:
    limit = ctx.settings.max_batch_dispositions
    items = list({(i.identity_key, i.rule_name): i for i in args.items}.values())
    if len(items) > limit:
        raise ValueError(
            f"{len(items)} lignes : {limit} au plus par carte. Ouvrez la page du run pour une sélection plus large"
        )
    response = await ctx.gateway.call(
        "GET", "/api/executions/{run_id}", path_params={"run_id": args.run_id}
    )
    if not response.ok:
        raise ValueError(f"run {args.run_id} illisible (HTTP {response.status})")
    run = run_summary(response.data)
    if not run.get("control_id") or not run.get("version"):
        raise ValueError(f"contrôle ou version du run {args.run_id} inconnus")

    warnings: list[str] = []
    for item in items:
        current = await _find_row(ctx, args.run_id, item)
        if current is None:
            raise ValueError(
                f"ligne {item.identity_key} / {item.rule_name} introuvable dans le run {args.run_id}"
            )
        if current.get("disposition_judgment"):
            warnings.append(
                f"{item.identity_key} est déjà jugée {current['disposition_judgment']}."
            )

    # Motif : pré-rempli seulement s'il vient des mots de l'utilisateur (règle 5 du prompt).
    reason = args.reason.strip()
    if reason and not appears_in(reason, await ctx.recent_user_texts()):
        warnings.append(
            "Motif proposé absent de vos messages : il a été vidé, saisissez-le."
        )
        reason = ""
    if not reason:
        warnings.append("Motif obligatoire : saisissez-le avant de confirmer.")
    if args.judgment is None:
        warnings.append("Jugement à choisir avant de confirmer.")

    lines = "\n".join(f"{i.identity_key} · {i.rule_name}" for i in items)
    return CardDraft(
        title=f"Juger {len(items)} ligne(s) du run {args.run_id}",
        fields=[
            CardField("Contrôle", f"{run['control_id']} ({run['version']})"),
            CardField("Run", args.run_id),
            CardField("Lignes", lines),
        ],
        impact=(
            "Le jugement s'appliquera à ces lignes dans les prochains runs ; "
            "il reste révocable."
        ),
        warnings=warnings,
        editable=[
            EditableField(
                name="judgment",
                label="Jugement",
                kind="enum",
                value=args.judgment,
                options=JUDGMENTS,
            ),
            EditableField(
                name="reason",
                label="Motif",
                kind="text",
                value=reason,
                min_length=REASON_MIN,
                max_length=REASON_MAX,
            ),
        ],
        overrides={
            "items": [i.model_dump() for i in items],
            "reason": reason,
            "control_id": run["control_id"],
            "control_version": run["version"],
        },
    )


async def _find_row(
    ctx: ToolContext, run_id: str, item: AnomalyRef
) -> dict[str, Any] | None:
    response = await ctx.gateway.call(
        "GET",
        "/api/executions/{run_id}/rows",
        path_params={"run_id": run_id},
        query={
            "search": item.identity_key,
            "rule_name": item.rule_name,
            "page_size": 50,
        },
    )
    if not response.ok:
        raise ValueError(f"lignes du run {run_id} illisibles (HTTP {response.status})")
    for row in items_of(response.data):
        if (
            isinstance(row, dict)
            and row.get("identity_key") == item.identity_key
            and first_value(row, ("control_rule", "rule_name")) == item.rule_name
        ):
            return row
    return None


# -- écriture : révocation -----------------------------------------------------------------
@hermes_tool(
    name="revoke_disposition",
    label="Révoquer un jugement",
    description=(
        "Révoque un jugement actif : la ligne redeviendra un nouveau KO au prochain run. "
        "Utiliser l'identifiant renvoyé par list_dispositions."
    ),
    args=RevokeDispositionArgs,
    min_role=Role.USER_MANAGER,
    phase=2,
    confirmation=Confirmation.REINFORCED,
    routes=(
        ("GET", "/api/controls/{control_id}/dispositions"),
        ("DELETE", "/api/dispositions/{disposition_id}"),
    ),
)
async def revoke_disposition(
    ctx: ToolContext, args: RevokeDispositionArgs
) -> ToolOutcome:
    response = await ctx.gateway.call(
        "DELETE",
        "/api/dispositions/{disposition_id}",
        path_params={"disposition_id": args.disposition_id},
    )
    if not response.ok:
        return http_failure(response, f"Révocation du jugement {args.disposition_id}")
    return ToolOutcome(
        content=f"Jugement {args.disposition_id} révoqué.",
        http_status=response.status,
        result={"disposition_id": args.disposition_id, "revoked": True},
    )


@revoke_disposition.card
async def revoke_disposition_card(
    ctx: ToolContext, args: RevokeDispositionArgs
) -> CardDraft:
    response = await ctx.gateway.call(
        "GET",
        "/api/controls/{control_id}/dispositions",
        path_params={"control_id": args.control_id},
    )
    if not response.ok:
        raise ValueError(
            f"jugements de {args.control_id} illisibles (HTTP {response.status})"
        )
    raw = next(
        (
            d
            for d in items_of(response.data)
            if first_value(d, ("disposition_id", "id")) == args.disposition_id
        ),
        None,
    )
    if raw is None:
        raise ValueError(
            f"jugement {args.disposition_id} introuvable ou déjà révoqué pour {args.control_id}"
        )
    found = disposition_summary(raw)
    author = first_value(raw, ("disposition_author", "author", "created_by"), "—")
    return CardDraft(
        title=f"Révoquer le jugement de {found.get('identity_key', '—')}",
        fields=[
            CardField("Contrôle", args.control_id),
            CardField("Ligne", str(found.get("identity_key", "—"))),
            CardField("Règle", str(found.get("rule_name", "—"))),
            CardField("Jugement", str(found.get("judgment", "—"))),
            CardField("Motif", str(found.get("reason", "—"))),
            CardField("Auteur", str(author)),
        ],
        impact="La ligne redeviendra un nouveau KO au prochain run.",
    )
