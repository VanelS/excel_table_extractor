"""Outils « exécutions » : runs, anomalies, tendance, export, lancement et rejeu."""

from __future__ import annotations

from datetime import date, datetime, timedelta, timezone
from typing import Any

from pydantic import BaseModel, Field, field_validator

from ..domain import ID_PATTERN, VERSION_PATTERN, Confirmation, Role, page_url
from ..reduce import first_value, items_of, reduce_rows, table_card
from ..registry import (
    CardDraft,
    CardField,
    ToolContext,
    ToolOutcome,
    hermes_tool,
)
from ._common import (
    RUNNING_STATUSES,
    SourceFile,
    control_summary,
    counters,
    fetch_executions,
    fr_date,
    http_failure,
    parse_moment,
    redact,
    run_card,
    run_link,
    run_summary,
    sort_by_start,
    sources_body,
    sources_text,
    unique_sources,
)

STATUS_PATTERN = r"^[A-Za-z_]{1,32}$"


class RunRef(BaseModel):
    run_id: str = Field(pattern=ID_PATTERN, description="Identifiant du run.")


class ListExecutionsArgs(BaseModel):
    control_id: str | None = Field(
        default=None, pattern=ID_PATTERN, description="Limiter aux runs de ce contrôle."
    )
    status: str | None = Field(
        default=None,
        pattern=STATUS_PATTERN,
        description="Statut du run tel que l'application l'affiche, par exemple pending, running ou failed.",
    )
    since: date | None = Field(
        default=None, description="Runs lancés à partir de cette date (AAAA-MM-JJ)."
    )
    until: date | None = Field(
        default=None, description="Runs lancés jusqu'à cette date incluse (AAAA-MM-JJ)."
    )
    limit: int = Field(
        default=10, ge=1, le=50, description="Nombre de runs à renvoyer."
    )


class QueryAnomaliesArgs(RunRef):
    status: str | None = Field(
        default="KO",
        pattern=STATUS_PATTERN,
        description="Statut de contrôle des lignes : KO par défaut, OK, ou null pour toutes.",
    )
    rule_name: str | None = Field(
        default=None, pattern=r"^[\w.:-]{1,128}$", description="Règle de contrôle."
    )
    search: str | None = Field(
        default=None, max_length=200, description="Texte à chercher dans les lignes."
    )
    only_unjudged: bool = Field(
        default=False,
        description="Ne garder que les lignes sans jugement actif (nouveaux KO).",
    )
    page: int = Field(default=1, ge=1, le=1000)
    page_size: int = Field(default=20, ge=1, le=50)


class TrendArgs(BaseModel):
    control_id: str | None = Field(default=None, pattern=ID_PATTERN)
    days: int = Field(default=30, ge=1, le=366, description="Période, en jours.")


class StartExecutionArgs(BaseModel):
    control_id: str = Field(pattern=ID_PATTERN, description="Contrôle à lancer.")
    sources: list[SourceFile] = Field(
        default_factory=list,
        max_length=20,
        description="Sources du run : nom de la source et fichier déposé dans data/inputs.",
    )
    control_date: date | None = Field(
        default=None,
        description="Date de contrôle (AAAA-MM-JJ). Par défaut, celle que fixe l'application.",
    )
    control_version: str | None = Field(
        default=None,
        pattern=VERSION_PATTERN,
        description="Version vNNN à exécuter. Par défaut : la version championne.",
    )

    _unique_sources = field_validator("sources")(unique_sources)


class AnalyzeArgs(RunRef):
    question: str = Field(
        min_length=3,
        max_length=500,
        description="Question chiffrée sur les données du run, en langage naturel.",
    )


# -- lecture --------------------------------------------------------------------------------
@hermes_tool(
    name="list_executions",
    label="Je consulte les exécutions",
    description=(
        "Runs récents, du plus récent au plus ancien, filtrés par contrôle, statut et période. "
        "Au-delà de 250 runs lus, le nombre renvoyé est un minimum (« au moins N »)."
    ),
    args=ListExecutionsArgs,
    routes=(("GET", "/api/executions"),),
)
async def list_executions(ctx: ToolContext, args: ListExecutionsArgs) -> ToolOutcome:
    raw, truncated, failure = await fetch_executions(ctx, args.control_id)
    if failure is not None:
        return http_failure(failure, "Liste des exécutions indisponible")
    runs = [run_summary(r) for r in raw]
    if args.status:
        wanted = args.status.casefold()
        runs = [r for r in runs if str(r.get("status", "")).casefold() == wanted]
    if args.since or args.until:
        runs = [r for r in runs if _in_period(r, args.since, args.until)]
    runs = sort_by_start(runs)
    shown = runs[: args.limit]
    return ToolOutcome(
        content={
            "nombre": len(runs),
            "au_moins": truncated,
            "runs": shown,
            "note": "liste partielle : plus de 250 runs lus" if truncated else None,
        },
        ui=table_card(shown, title="Exécutions", link=page_url("executions")),
        result={"nombre": len(runs), "au_moins": truncated},
    )


def _in_period(run: dict[str, Any], since: date | None, until: date | None) -> bool:
    started = parse_moment(run.get("started_at"))
    if started is None:
        return False
    day = started.date()
    return (since is None or day >= since) and (until is None or day <= until)


@hermes_tool(
    name="get_execution",
    label="Je consulte le run",
    description=(
        "Statut, nœud courant, compteurs (lignes, OK, KO, en attente, nouveaux KO) et erreur éventuelle d'un run."
    ),
    args=RunRef,
    routes=(("GET", "/api/executions/{run_id}"),),
)
async def get_execution(ctx: ToolContext, args: RunRef) -> ToolOutcome:
    response = await ctx.gateway.call(
        "GET", "/api/executions/{run_id}", path_params={"run_id": args.run_id}
    )
    if not response.ok:
        return http_failure(response, f"Run {args.run_id}")
    raw = response.data if isinstance(response.data, dict) else {}
    run = run_summary(raw)
    for key in ("current_node", "duration_s", "error", "excel_available"):
        if raw.get(key) is not None:
            run[key] = raw[key]
    return ToolOutcome(
        content=redact(run),
        ui=run_card(args.run_id, run),
        result={"run_id": args.run_id, "status": run.get("status")},
    )


def _anomaly(row: dict[str, Any]) -> dict[str, Any]:
    data = row.get("data") if isinstance(row.get("data"), dict) else {}
    out = {
        "identity_key": row.get("identity_key"),
        "rule_name": first_value(row, ("control_rule", "rule_name")),
        "status": first_value(row, ("control_status", "status")),
        "judgment": row.get("disposition_judgment"),
    }
    out["data"] = dict(list(data.items())[:8])
    return redact(out)


@hermes_tool(
    name="query_anomalies",
    label="Je consulte les anomalies",
    description=(
        "Lignes d'un run, filtrées par statut (KO par défaut), règle ou texte, avec leur jugement actif. "
        "only_unjudged=true ne garde que les nouveaux KO de la page."
    ),
    args=QueryAnomaliesArgs,
    routes=(("GET", "/api/executions/{run_id}/rows"),),
)
async def query_anomalies(ctx: ToolContext, args: QueryAnomaliesArgs) -> ToolOutcome:
    response = await ctx.gateway.call(
        "GET",
        "/api/executions/{run_id}/rows",
        path_params={"run_id": args.run_id},
        query={
            "page": args.page,
            "page_size": args.page_size,
            "status": args.status,
            "rule_name": args.rule_name,
            "search": args.search,
        },
    )
    if not response.ok:
        return http_failure(response, f"Lignes du run {args.run_id}")
    data = response.data if isinstance(response.data, dict) else {}
    rows = [_anomaly(r) for r in items_of(response.data) if isinstance(r, dict)]
    if args.only_unjudged:
        rows = [r for r in rows if not r.get("judgment")]
    shown, truncated = reduce_rows(rows, ctx.settings.max_rows_to_model)
    flat = [
        {k: v for k, v in r.items() if k != "data"} | dict(list(r["data"].items())[:2])
        for r in shown
    ]
    return ToolOutcome(
        content={
            "run_id": args.run_id,
            "total_api": data.get("total"),
            "page": data.get("page", args.page),
            "page_size": data.get("page_size", args.page_size),
            "lignes": shown,
            "tronque": truncated,
            "filtre_nouveaux_ko_sur_la_page": args.only_unjudged,
        },
        ui=table_card(
            flat, title=f"Anomalies du run {args.run_id}", link=run_link(args.run_id)
        ),
        result={"run_id": args.run_id, "total": data.get("total")},
    )


@hermes_tool(
    name="get_compliance_trend",
    label="Je calcule la tendance",
    description=(
        "Évolution des OK, KO, en attente et nouveaux KO run après run sur une période, "
        "pour un contrôle ou pour tous."
    ),
    args=TrendArgs,
    routes=(("GET", "/api/executions"),),
)
async def get_compliance_trend(ctx: ToolContext, args: TrendArgs) -> ToolOutcome:
    raw, truncated, failure = await fetch_executions(ctx, args.control_id)
    if failure is not None:
        return http_failure(failure, "Historique des exécutions indisponible")
    start = datetime.now(timezone.utc) - timedelta(days=args.days)
    points = []
    for run in sort_by_start((run_summary(r) for r in raw), newest_first=False):
        started = parse_moment(run.get("started_at"))
        if started is None or started < start or "n_rows" not in run:
            continue
        n_rows = run.get("n_rows") or 0
        ko = run.get("n_ko") or 0
        points.append(
            {
                "date": started.date().isoformat(),
                "run_id": run.get("run_id"),
                "control_id": run.get("control_id"),
                **counters(run),
                "taux_ko": round(ko / n_rows, 4) if n_rows else None,
            }
        )
    summary: dict[str, Any] = {"runs": len(points), "periode_jours": args.days}
    rated = [p for p in points if p["taux_ko"] is not None]
    if rated:
        summary["taux_ko_premier"] = rated[0]["taux_ko"]
        summary["taux_ko_dernier"] = rated[-1]["taux_ko"]
        summary["variation"] = round(rated[-1]["taux_ko"] - rated[0]["taux_ko"], 4)
    shown, cut = reduce_rows(points, ctx.settings.max_rows_to_model)
    return ToolOutcome(
        content={
            "resume": summary,
            "points": shown,
            "points_tronques": cut,
            "historique_partiel": truncated,
        },
        ui=table_card(
            list(reversed(points)), title="Tendance", link=page_url("analytics")
        ),
        result=summary,
    )


@hermes_tool(
    name="export_report",
    label="Je prépare l'export Excel",
    description=(
        "Prépare le téléchargement du classeur Excel des anomalies d'un run : "
        "le panneau affiche un bouton de téléchargement."
    ),
    args=RunRef,
    routes=(("GET", "/api/executions/{run_id}"),),
)
async def export_report(ctx: ToolContext, args: RunRef) -> ToolOutcome:
    # Le classeur n'est jamais téléchargé par l'agent : le navigateur le récupère lui-même.
    response = await ctx.gateway.call(
        "GET", "/api/executions/{run_id}", path_params={"run_id": args.run_id}
    )
    if not response.ok:
        return http_failure(response, f"Run {args.run_id}")
    raw = response.data if isinstance(response.data, dict) else {}
    if raw.get("excel_available") in (False, 0):
        status = raw.get("status", "inconnu")
        return ToolOutcome(
            content=f"Le classeur Excel du run {args.run_id} n'est pas disponible (statut {status}).",
            ok=False,
            error="excel indisponible",
        )
    return ToolOutcome(
        content=f"Bouton de téléchargement du classeur du run {args.run_id} affiché dans le panneau.",
        ui={
            "kind": "download",
            "title": f"Classeur des anomalies — run {args.run_id}",
            "url": f"/api/executions/{args.run_id}/export-excel",
            "filename": f"hermes_{args.run_id}.xlsx",
        },
        result={"run_id": args.run_id},
    )


@hermes_tool(
    name="analyze_run_data",
    label="J'analyse les données du run",
    description=(
        "Répond à une question chiffrée sur les données d'un run (comptages, sommes, répartitions) "
        "par une requête SQL en lecture seule exécutée par l'application."
    ),
    args=AnalyzeArgs,
    routes=(("POST", "/api/executions/{run_id}/query"),),
    enabled_by_default=False,
    status_note="Nouvel endpoint à brancher (app/services/run_query.py) avant activation.",
)
async def analyze_run_data(ctx: ToolContext, args: AnalyzeArgs) -> ToolOutcome:
    response = await ctx.gateway.call(
        "POST",
        "/api/executions/{run_id}/query",
        path_params={"run_id": args.run_id},
        json_body={"question": args.question},
    )
    if not response.ok:
        return http_failure(response, f"Analyse du run {args.run_id}")
    data = response.data if isinstance(response.data, dict) else {}
    rows = data.get("rows") if isinstance(data.get("rows"), list) else []
    shown, truncated = reduce_rows(redact(rows), ctx.settings.max_rows_to_model)
    return ToolOutcome(
        content={
            "sql": data.get("sql"),
            "colonnes": data.get("columns"),
            "lignes": shown,
            "nombre_de_lignes": data.get("row_count", len(rows)),
            "tronque": truncated or bool(data.get("truncated")),
        },
        result={"run_id": args.run_id, "row_count": data.get("row_count")},
    )


# -- écriture : lancement et rejeu ---------------------------------------------------------
@hermes_tool(
    name="start_execution",
    label="Lancer une exécution",
    description=(
        "Lance un run d'un contrôle, sur la version championne par défaut. "
        "L'application affiche une carte de confirmation : ne présentez pas le run comme lancé avant le résultat."
    ),
    args=StartExecutionArgs,
    min_role=Role.USER_MANAGER,
    confirmation=Confirmation.SIMPLE,
    routes=(
        ("GET", "/api/controls/{control_id}"),
        ("POST", "/api/controls/{control_id}/executions"),
    ),
)
async def start_execution(ctx: ToolContext, args: StartExecutionArgs) -> ToolOutcome:
    body = {
        "sources": sources_body(args.sources),
        "control_date": args.control_date.isoformat() if args.control_date else None,
        "control_version": args.control_version,
    }
    response = await ctx.gateway.call(
        "POST",
        "/api/controls/{control_id}/executions",
        path_params={"control_id": args.control_id},
        json_body=body,
    )
    if not response.ok:
        return http_failure(response, f"Lancement de {args.control_id}")
    data = response.data if isinstance(response.data, dict) else {}
    run_id = first_value(data, ("run_id", "id"))
    status = data.get("status", "pending")
    run = {"control_id": args.control_id, "status": status}
    return ToolOutcome(
        content=(
            f"Run {run_id} lancé pour {args.control_id} ({args.control_version}), statut {status}. "
            "Le panneau suit son avancement ; un événement signalera sa fin."
        ),
        ui=run_card(str(run_id), run) if run_id else None,
        http_status=response.status,
        result={
            "run_id": run_id,
            "control_id": args.control_id,
            "version": args.control_version,
            "status": status,
        },
    )


@start_execution.card
async def start_execution_card(ctx: ToolContext, args: StartExecutionArgs) -> CardDraft:
    response = await ctx.gateway.call(
        "GET", "/api/controls/{control_id}", path_params={"control_id": args.control_id}
    )
    if response.status == 404:
        raise ValueError(f"contrôle {args.control_id} introuvable")
    if not response.ok:
        raise ValueError(
            f"contrôle {args.control_id} illisible (HTTP {response.status})"
        )
    champion = control_summary(response.data).get("champion")
    version = args.control_version or champion
    if not version:
        raise ValueError(
            f"version championne de {args.control_id} inconnue : précisez la version"
        )
    warnings = []
    if champion and version != champion:
        warnings.append(f"Version non championne : la version active est {champion}.")
    if not args.sources:
        warnings.append(
            "Aucune source précisée : l'application refusera le lancement si le contrôle en exige."
        )
    label = f"{version} (championne)" if version == champion else version
    return CardDraft(
        title=f"Lancer {args.control_id}",
        fields=[
            CardField("Contrôle", args.control_id),
            CardField("Version", label),
            CardField(
                "Date de contrôle",
                fr_date(args.control_date)
                if args.control_date
                else "Date par défaut de l'application",
            ),
            CardField("Sources", sources_text(args.sources)),
        ],
        impact="Un nouveau run apparaîtra dans l'historique du contrôle.",
        warnings=warnings,
        # La version affichée est celle qui sera exécutée, même si la championne change d'ici là.
        overrides={"control_version": version},
    )


@hermes_tool(
    name="rerun_execution",
    label="Rejouer un run",
    description=(
        "Rejoue un run à l'identique, avec la version du contrôle utilisée à l'origine. "
        "L'application affiche une carte de confirmation."
    ),
    args=RunRef,
    min_role=Role.USER_MANAGER,
    confirmation=Confirmation.SIMPLE,
    routes=(
        ("GET", "/api/executions/{run_id}"),
        ("POST", "/api/executions/{run_id}/rerun"),
    ),
)
async def rerun_execution(ctx: ToolContext, args: RunRef) -> ToolOutcome:
    response = await ctx.gateway.call(
        "POST",
        "/api/executions/{run_id}/rerun",
        path_params={"run_id": args.run_id},
        json_body={},
    )
    if not response.ok:
        return http_failure(response, f"Rejeu du run {args.run_id}")
    data = response.data if isinstance(response.data, dict) else {}
    run_id = first_value(data, ("run_id", "id"))
    status = data.get("status", "pending")
    return ToolOutcome(
        content=(
            f"Run {run_id} lancé en rejeu du run {args.run_id}, statut {status}. "
            "Le panneau suit son avancement."
        ),
        ui=run_card(str(run_id), {"status": status}) if run_id else None,
        http_status=response.status,
        result={"run_id": run_id, "parent_run_id": args.run_id, "status": status},
    )


@rerun_execution.card
async def rerun_execution_card(ctx: ToolContext, args: RunRef) -> CardDraft:
    response = await ctx.gateway.call(
        "GET", "/api/executions/{run_id}", path_params={"run_id": args.run_id}
    )
    if response.status == 404:
        raise ValueError(f"run {args.run_id} introuvable")
    if not response.ok:
        raise ValueError(f"run {args.run_id} illisible (HTTP {response.status})")
    run = run_summary(response.data)
    status = str(run.get("status", "inconnu"))
    warnings = []
    if status.casefold() in RUNNING_STATUSES:
        warnings.append("Le run d'origine n'est pas terminé.")
    return CardDraft(
        title=f"Rejouer le run {args.run_id}",
        fields=[
            CardField("Contrôle", str(run.get("control_id", "—"))),
            CardField("Version d'origine", str(run.get("version", "—"))),
            CardField("Date de contrôle", fr_date(run.get("control_date"))),
            CardField("Statut du run d'origine", status),
        ],
        impact="Un nouveau run rejouera celui-ci à l'identique, avec sa version d'origine.",
        warnings=warnings,
    )
