"""Outils du chargeur de données (classeurs, bases, descripteurs) : lecture seule.

Le chargeur alimente un catalogue que les contrôles ne voient pas (section 12.3 de la doc).
Ses endpoints de liste ne sont pas documentés : outils de phase 3, désactivés par défaut
jusqu'à leur confirmation par la découverte.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel

from ..domain import page_url
from ..reduce import first_value, items_of, reduce_rows, table_card
from ..registry import ToolContext, ToolOutcome, hermes_tool
from ._common import http_failure

_LOADER_NOTE = "Endpoint de liste du chargeur à confirmer à la découverte."


class NoArgs(BaseModel):
    pass


def _summaries(data: Any, fields: dict[str, tuple[str, ...]]) -> list[dict[str, Any]]:
    out = []
    for raw in items_of(data):
        if isinstance(raw, dict):  # le contenu binaire (BLOB) n'est jamais repris
            out.append(
                {
                    k: first_value(raw, names)
                    for k, names in fields.items()
                    if first_value(raw, names) is not None
                }
            )
    return out


async def _listing(
    ctx: ToolContext, route: str, title: str, fields: dict[str, tuple[str, ...]]
) -> ToolOutcome:
    response = await ctx.gateway.call("GET", route)
    if not response.ok:
        return http_failure(response, f"{title} indisponibles")
    rows = _summaries(response.data, fields)
    shown, truncated = reduce_rows(rows, ctx.settings.max_rows_to_model)
    return ToolOutcome(
        content={"nombre": len(rows), "elements": shown, "tronque": truncated},
        ui=table_card(shown, title=title, link=page_url("loader")),
        result={"nombre": len(rows)},
    )


@hermes_tool(
    name="list_workbooks",
    label="Je consulte les classeurs du chargeur",
    description="Classeurs Excel du chargeur de données : nom, taille, feuilles, date de dépôt.",
    args=NoArgs,
    phase=3,
    routes=(("GET", "/api/workbooks"),),
    enabled_by_default=False,
    status_note=_LOADER_NOTE,
)
async def list_workbooks(ctx: ToolContext, args: NoArgs) -> ToolOutcome:
    return await _listing(
        ctx,
        "/api/workbooks",
        "Classeurs du chargeur",
        {
            "id": ("id",),
            "filename": ("filename", "name"),
            "size_bytes": ("size_bytes",),
            "sheet_names": ("sheet_names",),
            "uploaded_at": ("uploaded_at",),
        },
    )


@hermes_tool(
    name="list_databases",
    label="Je consulte les bases du chargeur",
    description="Bases SQLite du chargeur de données : nom, taille, tables, date de dépôt.",
    args=NoArgs,
    phase=3,
    routes=(("GET", "/api/databases"),),
    enabled_by_default=False,
    status_note=_LOADER_NOTE,
)
async def list_databases(ctx: ToolContext, args: NoArgs) -> ToolOutcome:
    return await _listing(
        ctx,
        "/api/databases",
        "Bases du chargeur",
        {
            "id": ("id",),
            "filename": ("filename", "name"),
            "size_bytes": ("size_bytes",),
            "table_names": ("table_names",),
            "uploaded_at": ("uploaded_at",),
        },
    )


@hermes_tool(
    name="list_dataset_descriptors",
    label="Je consulte les descripteurs de données",
    description="Descripteurs d'extraction du chargeur : nom, source, feuille, plage, colonnes.",
    args=NoArgs,
    phase=3,
    routes=(("GET", "/api/datasets"),),
    enabled_by_default=False,
    status_note=_LOADER_NOTE,
)
async def list_dataset_descriptors(ctx: ToolContext, args: NoArgs) -> ToolOutcome:
    return await _listing(
        ctx,
        "/api/datasets",
        "Descripteurs de données",
        {
            "id": ("id",),
            "name": ("name",),
            "source": ("source",),
            "filename_pattern": ("filename_pattern",),
            "sheet_name": ("sheet_name",),
            "cell_range": ("cell_range",),
            "cols": ("cols",),
        },
    )
