"""Aides communes aux outils : erreurs HTTP lisibles, liens internes, champs des runs.

Les noms de champs des réponses de l'API viennent de la documentation technique. Quand la doc
ne les donne pas, les outils essaient plusieurs noms (`first_value`) ; l'étape de découverte
de la procédure d'intégration les confirme et permet de retirer les noms inutiles.
"""

from __future__ import annotations

from collections.abc import Iterable
from datetime import date, datetime, timezone
from typing import Any

from pydantic import BaseModel, Field

from ..domain import page_url
from ..gateway import ApiResponse
from ..reduce import first_value, items_of, scrub
from ..registry import ToolContext, ToolOutcome

# Nom d'un fichier déposé dans data/inputs (même motif que les pièces jointes du panneau).
FILE_NAME_PATTERN = r"^[\w .()-]{1,200}$"


class SourceFile(BaseModel):
    """Une source d'un contrôle et le fichier déposé qui la fournit."""

    name: str = Field(
        pattern=r"^[\w.-]{1,64}$",
        description="Nom de la source attendu par le contrôle.",
    )
    file: str = Field(
        pattern=FILE_NAME_PATTERN, description="Nom du fichier déposé dans data/inputs."
    )


def unique_sources(sources: list[SourceFile]) -> list[SourceFile]:
    """Refuse deux fichiers pour une même source : la carte montrerait ce qui ne part pas."""
    names = [s.name for s in sources]
    duplicates = sorted({n for n in names if names.count(n) > 1})
    if duplicates:
        raise ValueError(f"source indiquée plusieurs fois : {', '.join(duplicates)}")
    return sources


def sources_body(sources: list[SourceFile]) -> dict[str, str]:
    """Forme attendue par `ExecutionCreateRequest.sources` : {source: fichier}."""
    return {s.name: s.file for s in sources}


def sources_text(sources: list[SourceFile]) -> str:
    if not sources:
        return "Aucune source précisée"
    return "\n".join(f"{s.name} : {s.file}" for s in sources)


# -- données personnelles -------------------------------------------------------------------
# Les résultats d'outils sont nettoyés deux fois : ici, avant d'être mis en forme, et au départ
# vers le modèle (graph._content). Voir reduce.scrub pour la règle et l'option B.
redact = scrub


# -- erreurs HTTP ------------------------------------------------------------------------------
_HTTP_TEXT = {
    400: "requête refusée par l'application",
    401: "session expirée, reconnectez-vous",
    403: "droits insuffisants pour cette opération",
    404: "introuvable",
    409: "conflit avec l'état actuel",
    422: "paramètres refusés par l'application",
    429: "trop de requêtes, réessayez plus tard",
}


def detail_of(response: ApiResponse) -> str:
    """Message d'erreur renvoyé par la route (`detail` de FastAPI), tronqué."""
    data = response.data
    if isinstance(data, dict):
        detail = data.get("detail") or data.get("message") or data.get("error")
        if isinstance(detail, list):  # erreurs de validation de FastAPI
            return "; ".join(
                str(d.get("msg", d)) if isinstance(d, dict) else str(d)
                for d in detail[:3]
            )[:300]
        if detail:
            return str(detail)[:300]
    if isinstance(data, str):
        return data[:300]
    return ""


def http_failure(response: ApiResponse, what: str) -> ToolOutcome:
    if response.status in _HTTP_TEXT:
        reason = _HTTP_TEXT[response.status]
    elif response.status >= 500:
        reason = "erreur technique de l'application"
    else:
        reason = "réponse inattendue"
    detail = detail_of(response)
    text = f"{what} : {reason} (HTTP {response.status})"
    if detail:
        text += f" — {detail}"
    return ToolOutcome(
        content=text + ".",
        ok=False,
        http_status=response.status,
        error=f"HTTP {response.status} {detail}".strip(),
    )


# -- liens internes (pages de domain.PAGES ; None si l'interface n'a pas la page) -------------
def run_link(run_id: str) -> str | None:
    return page_url("execution", run_id)


def control_link(control_id: str) -> str | None:
    return page_url("control", control_id)


def link_card(title: str, link: str | None) -> dict[str, Any] | None:
    """Carte « lien » vers une page de l'interface ; pas de carte si l'interface n'a pas la page."""
    return {"kind": "link", "title": title, "link": link} if link else None


# -- dates -------------------------------------------------------------------------------------
def parse_moment(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value:
        return None
    try:
        moment = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    return moment if moment.tzinfo else moment.replace(tzinfo=timezone.utc)


def fr_date(value: Any) -> str:
    """Date au format JJ/MM/AAAA pour les cartes ; la valeur brute si elle ne se lit pas."""
    if isinstance(value, date) and not isinstance(value, datetime):
        return value.strftime("%d/%m/%Y")
    moment = parse_moment(value) if isinstance(value, str) else value
    if isinstance(moment, datetime):
        return moment.strftime("%d/%m/%Y")
    if isinstance(value, str):
        try:
            return date.fromisoformat(value).strftime("%d/%m/%Y")
        except ValueError:
            return value
    return "—" if value is None else str(value)


# -- contrôles et runs -------------------------------------------------------------------------
_CONTROL_FIELDS: dict[str, tuple[str, ...]] = {
    "control_id": ("control_id", "id", "name"),
    "champion": ("champion", "champion_version", "active_version", "current_version"),
    "description": ("description", "label", "title"),
    "updated_at": ("updated_at", "last_modified", "modified_at"),
}

_RUN_FIELDS: dict[str, tuple[str, ...]] = {
    "run_id": ("run_id", "id"),
    "control_id": ("control_id",),
    "version": ("control_version", "version"),
    "status": ("status",),
    "control_date": ("control_date",),
    "started_at": ("started_at", "created_at"),
    "ended_at": ("ended_at", "finished_at"),
    "n_rows": ("n_rows",),
    "n_ok": ("n_ok",),
    "n_ko": ("n_ko",),
    "n_pending": ("n_pending",),
    "n_new_ko": ("n_new_ko",),
    "parent_run_id": ("parent_run_id",),
}

# Statuts d'un run encore en cours (valeurs à confirmer à la découverte).
RUNNING_STATUSES = frozenset({"pending", "running", "queued", "submitted", "started"})


def pick(raw: Any, fields: dict[str, tuple[str, ...]]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for key, candidates in fields.items():
        value = first_value(raw, candidates)
        if value is not None:
            out[key] = value
    return out


def control_summary(raw: Any) -> dict[str, Any]:
    return pick(raw, _CONTROL_FIELDS)


def run_summary(raw: Any) -> dict[str, Any]:
    return pick(raw, _RUN_FIELDS)


def counters(run: dict[str, Any]) -> dict[str, Any]:
    return {
        k: run[k]
        for k in ("n_rows", "n_ok", "n_ko", "n_pending", "n_new_ko")
        if k in run
    }


def run_card(run_id: str, run: dict[str, Any] | None = None) -> dict[str, Any]:
    """Carte de run : le panneau relit l'état toutes les 2 secondes tant qu'il n'est pas terminé."""
    run = run or {}
    return {
        "kind": "run",
        "run_id": run_id,
        "control_id": run.get("control_id"),
        "status": run.get("status"),
        "current_node": run.get("current_node"),
        "counters": counters(run),
        "link": run_link(run_id),
    }


# -- pagination de GET /api/executions ----------------------------------------------------------
EXECUTIONS_PAGE_SIZE = 50
EXECUTIONS_MAX_PAGES = 5


async def fetch_executions(
    ctx: ToolContext, control_id: str | None
) -> tuple[list[dict[str, Any]], bool, ApiResponse | None]:
    """Jusqu'à 5 pages de 50 runs : l'API ne renvoie ni total ni filtre de statut.

    Renvoie (runs, liste tronquée, réponse en échec éventuelle).
    """
    runs: list[dict[str, Any]] = []
    for page in range(EXECUTIONS_MAX_PAGES):
        response = await ctx.gateway.call(
            "GET",
            "/api/executions",
            query={
                "control_id": control_id,
                "limit": EXECUTIONS_PAGE_SIZE,
                "offset": page * EXECUTIONS_PAGE_SIZE,
            },
        )
        if not response.ok:
            return runs, False, response
        batch = items_of(response.data)
        runs.extend(r for r in batch if isinstance(r, dict))
        if len(batch) < EXECUTIONS_PAGE_SIZE:
            return runs, False, None
    return runs, True, None


def sort_by_start(runs: Iterable[dict[str, Any]], newest_first: bool = True) -> list:
    epoch = datetime.min.replace(tzinfo=timezone.utc)
    return sorted(
        runs,
        key=lambda r: parse_moment(r.get("started_at")) or epoch,
        reverse=newest_first,
    )


def find_key(value: Any, names: tuple[str, ...], depth: int = 3) -> Any:
    """Première valeur portée par une des clés `names`, cherchée sur quelques niveaux."""
    if depth < 0:
        return None
    if isinstance(value, dict):
        for name in names:
            if name in value:
                return value[name]
        for child in value.values():
            found = find_key(child, names, depth - 1)
            if found is not None:
                return found
    return None
