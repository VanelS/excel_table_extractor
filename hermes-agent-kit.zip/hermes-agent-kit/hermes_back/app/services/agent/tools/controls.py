"""Outils « contrôles » : liste, synthèse, définition d'une version, vérification et simulation."""

from __future__ import annotations

import json
from typing import Any

from pydantic import BaseModel, Field, field_validator

from ..domain import ID_PATTERN, VERSION_PATTERN, Role, page_url
from ..reduce import first_value, items_of, reduce_rows, table_card
from ..registry import ToolContext, ToolOutcome, hermes_tool
from ._common import (
    SourceFile,
    control_link,
    control_summary,
    find_key,
    http_failure,
    link_card,
    redact,
    sources_body,
    unique_sources,
)


class ListControlsArgs(BaseModel):
    search: str | None = Field(
        default=None,
        max_length=100,
        description="Texte à chercher dans l'identifiant ou la description du contrôle.",
    )


class ControlRef(BaseModel):
    control_id: str = Field(
        pattern=ID_PATTERN,
        description="Identifiant technique du contrôle, par exemple section_setting.",
    )


class DefinitionArgs(ControlRef):
    version: str | None = Field(
        default=None,
        pattern=VERSION_PATTERN,
        description="Version au format vNNN (ex. v009). Par défaut : la version championne.",
    )


class SourcesArgs(ControlRef):
    sources: list[SourceFile] = Field(
        default_factory=list,
        max_length=20,
        description="Sources du contrôle : nom de la source et fichier déposé dans data/inputs.",
    )

    _unique_sources = field_validator("sources")(unique_sources)


async def _champion(ctx: ToolContext, control_id: str) -> tuple[str | None, Any]:
    response = await ctx.gateway.call(
        "GET", "/api/controls/{control_id}", path_params={"control_id": control_id}
    )
    if not response.ok:
        return None, response
    return control_summary(response.data).get("champion"), response


@hermes_tool(
    name="list_controls",
    label="Je consulte les contrôles",
    description=(
        "Liste les contrôles de la plateforme avec leur version championne (version active) "
        "et leur description. Utiliser pour retrouver l'identifiant exact d'un contrôle."
    ),
    args=ListControlsArgs,
    routes=(("GET", "/api/controls"),),
)
async def list_controls(ctx: ToolContext, args: ListControlsArgs) -> ToolOutcome:
    response = await ctx.gateway.call("GET", "/api/controls")
    if not response.ok:
        return http_failure(response, "Liste des contrôles indisponible")
    controls = [control_summary(c) for c in items_of(response.data)]
    if args.search:
        needle = args.search.casefold()
        controls = [
            c
            for c in controls
            if needle in json.dumps(c, ensure_ascii=False).casefold()
        ]
    shown, truncated = reduce_rows(controls, ctx.settings.max_rows_to_model)
    return ToolOutcome(
        content={"total": len(controls), "controles": shown, "tronque": truncated},
        ui=table_card(shown, title="Contrôles", link=page_url("controls")),
        result={"total": len(controls)},
    )


@hermes_tool(
    name="get_control",
    label="Je consulte le contrôle",
    description=(
        "Synthèse d'un contrôle : description, version championne et historique de ses versions."
    ),
    args=ControlRef,
    routes=(("GET", "/api/controls/{control_id}"),),
)
async def get_control(ctx: ToolContext, args: ControlRef) -> ToolOutcome:
    response = await ctx.gateway.call(
        "GET",
        "/api/controls/{control_id}",
        path_params={"control_id": args.control_id},
    )
    if not response.ok:
        return http_failure(response, f"Contrôle {args.control_id}")
    raw = response.data if isinstance(response.data, dict) else {}
    summary = control_summary(raw) or {"control_id": args.control_id}
    versions = first_value(raw, ("versions", "history", "version_history"), [])
    if isinstance(versions, list):
        summary["versions"] = redact(versions[-30:])
        summary["nombre_de_versions"] = len(versions)
    return ToolOutcome(
        content=summary,
        ui=link_card(f"Contrôle {args.control_id}", control_link(args.control_id)),
        result={"control_id": args.control_id, "champion": summary.get("champion")},
    )


@hermes_tool(
    name="get_control_definition",
    label="Je lis la définition du contrôle",
    description=(
        "Définition complète d'une version d'un contrôle (sources, transformation, règles). "
        "Sans version précisée, lit la version championne."
    ),
    args=DefinitionArgs,
    routes=(
        ("GET", "/api/controls/{control_id}"),
        ("GET", "/api/controls/{control_id}/versions/{version}"),
    ),
)
async def get_control_definition(ctx: ToolContext, args: DefinitionArgs) -> ToolOutcome:
    champion, champion_response = await _champion(ctx, args.control_id)
    if champion_response is not None and not champion_response.ok:
        return http_failure(champion_response, f"Contrôle {args.control_id}")
    version = args.version or champion
    if not version:
        return ToolOutcome(
            content=f"Version championne de {args.control_id} introuvable : précisez la version.",
            ok=False,
            error="champion inconnu",
        )
    response = await ctx.gateway.call(
        "GET",
        "/api/controls/{control_id}/versions/{version}",
        path_params={"control_id": args.control_id, "version": version},
    )
    if not response.ok:
        return http_failure(response, f"Version {version} de {args.control_id}")
    definition = response.data
    rules = find_key(definition, ("rules", "control_rules", "regles"))
    content: dict[str, Any] = {
        "control_id": args.control_id,
        "version": version,
        "championne": version == champion,
    }
    if isinstance(rules, list):
        content["regles"] = [
            {
                k: r.get(k)
                for k in ("name", "rule_name", "description", "condition", "expression")
                if isinstance(r, dict) and r.get(k) is not None
            }
            or r
            for r in rules[:40]
        ]
    content["definition"] = redact(definition)
    return ToolOutcome(
        content=content,
        result={"control_id": args.control_id, "version": version},
    )


@hermes_tool(
    name="check_sources",
    label="Je vérifie les sources",
    description=(
        "Vérifie que les fichiers sources d'un contrôle sont présents et lisibles, sans rien lancer."
    ),
    args=SourcesArgs,
    min_role=Role.USER_MANAGER,
    routes=(("POST", "/api/controls/{control_id}/validate-source"),),
    enabled_by_default=False,
    status_note="Corps de requête de validate-source à confirmer à la découverte.",
)
async def check_sources(ctx: ToolContext, args: SourcesArgs) -> ToolOutcome:
    response = await ctx.gateway.call(
        "POST",
        "/api/controls/{control_id}/validate-source",
        path_params={"control_id": args.control_id},
        json_body={"sources": sources_body(args.sources)},
    )
    if not response.ok:
        return http_failure(response, f"Vérification des sources de {args.control_id}")
    return ToolOutcome(
        content=redact(response.data), result={"control_id": args.control_id}
    )


@hermes_tool(
    name="dry_run_control",
    label="Je simule le contrôle",
    description=(
        "Simule un contrôle sur un échantillon en mémoire : aucun run créé, aucun fichier écrit. "
        "Renvoie un aperçu des lignes qualifiées et des métriques simulées."
    ),
    args=SourcesArgs,
    min_role=Role.USER_MANAGER,
    routes=(("POST", "/api/controls/{control_id}/dry-run"),),
    enabled_by_default=False,
    status_note="Corps de requête du dry-run à confirmer à la découverte.",
)
async def dry_run_control(ctx: ToolContext, args: SourcesArgs) -> ToolOutcome:
    response = await ctx.gateway.call(
        "POST",
        "/api/controls/{control_id}/dry-run",
        path_params={"control_id": args.control_id},
        json_body={"sources": sources_body(args.sources)},
    )
    if not response.ok:
        return http_failure(response, f"Simulation de {args.control_id}")
    data = (
        response.data
        if isinstance(response.data, dict)
        else {"resultat": response.data}
    )
    rows = items_of(first_value(data, ("rows", "preview", "items"), []))
    shown, truncated = reduce_rows(redact(rows), ctx.settings.max_rows_to_model)
    content = {
        k: v for k, v in redact(data).items() if k not in ("rows", "preview", "items")
    }
    content.update({"apercu": shown, "apercu_tronque": truncated})
    return ToolOutcome(content=content, result={"control_id": args.control_id})
