"""Branchement de l'agent dans l'application : cycle de vie et routeur.

Dans `create_app` (app/api/app.py), deux ajouts suffisent (étape 6 de la procédure) :

    from app.services.agent.wiring import agent_lifespan, include_agent_router

    # dans le cycle de vie existant, autour du `yield` :
    async with agent_lifespan(app, engine=<moteur de hermes.db>, data_dir=<DATA_DIR>):
        yield

    # après les autres include_router :
    include_agent_router(app, current_user=<dépendance utilisateur>, csrf_dependency=<dépendance CSRF>)

Avec `HERMES_AGENT_ENABLED=False` (valeur par défaut), rien ne démarre et le routeur répond 404.
"""

from __future__ import annotations

import asyncio
import functools
import logging
from collections.abc import AsyncIterator, Callable
from contextlib import AsyncExitStack, asynccontextmanager, suppress
from datetime import timedelta
from pathlib import Path
from typing import Any

from anyio import to_thread

from .config import AgentSettings
from .domain import UserContext, default_user_mapper
from .graph import build_graph
from .llm import ModelProvider, load_integration
from .registry import load_tools
from .service import AgentService
from .store import AgentStore, iso, utcnow

log = logging.getLogger("hermes.agent")

SHUTDOWN_GRACE_S = 30.0


def checkpoint_path(
    settings: AgentSettings, data_dir: str | Path | None = None
) -> Path:
    """`HERMES_AGENT_CHECKPOINT_DB`, sinon `<DATA_DIR>/db/agent_checkpoints.db` (à côté de hermes.db)."""
    if settings.checkpoint_db:
        return Path(settings.checkpoint_db)
    return Path(data_dir or "data") / "db" / "agent_checkpoints.db"


@asynccontextmanager
async def open_checkpointer(path: Path) -> AsyncIterator[Any]:
    """Points de reprise dans une base SQLite séparée de hermes.db (WAL, délai d'attente)."""
    from langgraph.checkpoint.sqlite.aio import AsyncSqliteSaver

    path.parent.mkdir(parents=True, exist_ok=True)
    async with AsyncSqliteSaver.from_conn_string(str(path)) as saver:
        await saver.conn.execute("PRAGMA journal_mode=WAL")
        await saver.conn.execute("PRAGMA busy_timeout=5000")
        yield saver


async def housekeeping_once(service: AgentService) -> None:
    """Actions bloquées (bail expiré, confirmation sans exécution), puis purge des reprises."""
    store, settings = service.store, service.settings
    failed = await to_thread.run_sync(store.fail_expired_leases)
    stale = await to_thread.run_sync(
        store.fail_stale_confirmed,
        utcnow() - timedelta(seconds=settings.action_lease_s),
    )
    if failed or stale:
        log.warning(
            "actions passées en échec : %d interrompue(s), %d non exécutée(s)",
            failed,
            stale,
        )
    cutoff = utcnow() - timedelta(days=settings.checkpoint_ttl_days)
    for conversation_id in await to_thread.run_sync(
        store.conversations_to_purge, cutoff
    ):
        if service.checkpointer is not None and hasattr(
            service.checkpointer, "adelete_thread"
        ):
            await service.checkpointer.adelete_thread(conversation_id)
        await to_thread.run_sync(
            functools.partial(
                store.update_conversation, conversation_id, purged_at=iso(utcnow())
            )
        )


async def _housekeeping(service: AgentService, interval_s: int = 3600) -> None:
    """Toutes les heures. Chaque worker la lance : les opérations sont idempotentes."""
    while True:
        try:
            await housekeeping_once(service)
        except Exception:
            log.exception("entretien de l'agent en erreur")
        await asyncio.sleep(interval_s)


@asynccontextmanager
async def agent_lifespan(
    app: Any,
    *,
    engine: Any,
    data_dir: str | Path | None = None,
    settings: AgentSettings | None = None,
    checkpointer: Any = None,
    models: ModelProvider | None = None,
    create_schema: bool = False,
) -> AsyncIterator[None]:
    """Démarre l'agent si `HERMES_AGENT_ENABLED` est vrai ; sinon ne fait rien.

    - `engine` : le moteur SQLAlchemy existant de hermes.db (jamais un second moteur) ;
    - `data_dir` : le DATA_DIR de l'application, pour placer la base de reprise à côté de hermes.db ;
    - `create_schema` : tests et développement seulement ; en production, la migration v016.
    """
    settings = settings or AgentSettings()
    app.state.hermes_agent = None
    if not settings.enabled:
        yield
        return
    load_tools()  # échoue tôt si un outil est mal déclaré
    load_integration()  # fournisseurs de modèles propres à la banque, s'il y en a
    store = AgentStore(engine)
    if create_schema:
        await to_thread.run_sync(store.ensure_schema)
    async with AsyncExitStack() as stack:
        saver = (
            checkpointer
            if checkpointer is not None
            else await stack.enter_async_context(
                open_checkpointer(checkpoint_path(settings, data_dir))
            )
        )
        service = AgentService(
            app=app,
            settings=settings,
            store=store,
            graph=build_graph(saver),
            models=models or ModelProvider(settings),
            checkpointer=saver,
        )
        app.state.hermes_agent = service
        task = asyncio.create_task(_housekeeping(service))
        try:
            yield
        finally:
            task.cancel()
            with suppress(asyncio.CancelledError):
                await task
            await service.drain(SHUTDOWN_GRACE_S)
            app.state.hermes_agent = None


def include_agent_router(
    app: Any,
    *,
    current_user: Callable[..., Any],
    to_user_context: Callable[[Any], UserContext] = default_user_mapper,
    csrf_dependency: Callable[..., Any] | None = None,
    prefix: str = "/api/agent",
) -> None:
    from app.api.agent import build_agent_router

    app.include_router(
        build_agent_router(
            current_user=current_user,
            to_user_context=to_user_context,
            csrf_dependency=csrf_dependency,
            prefix=prefix,
        )
    )
