"""Modèles de langage : fabrique par fournisseur, modèle principal puis secours.

`HERMES_AGENT_MODEL` vaut "<fournisseur>:<identifiant>". Fournisseurs fournis : `openai`
(toute passerelle compatible OpenAI, via `HERMES_AGENT_OPENAI_BASE_URL`), `anthropic`,
`google_genai`. Pour réutiliser les clients de `app/services/ai/`, enregistrer un
fournisseur maison avec `register_provider("banque", fabrique)`.

Règles d'appel (section 8 de la spécification) : 30 s d'attente au plus par fragment,
`HERMES_AGENT_MODEL_TOTAL_TIMEOUT_S` pour l'appel entier, une seconde tentative, puis le
modèle de secours ; la bascule n'a lieu qu'avant le premier fragment reçu.
"""

from __future__ import annotations

import asyncio
import importlib
import logging
from collections.abc import Callable
from typing import Any

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import (
    AIMessage,
    AIMessageChunk,
    BaseMessage,
    message_chunk_to_message,
)

from .config import AgentSettings

log = logging.getLogger("hermes.agent.llm")

ModelFactory = Callable[[str, AgentSettings], BaseChatModel]
_PROVIDERS: dict[str, ModelFactory] = {}


class ModelConfigError(RuntimeError):
    pass


class ModelUnavailable(RuntimeError):
    pass


def register_provider(name: str, factory: ModelFactory) -> None:
    _PROVIDERS[name] = factory


def _secret(value: Any) -> str | None:
    return value.get_secret_value() if value is not None else None


def _openai(model_id: str, s: AgentSettings) -> BaseChatModel:
    from langchain_openai import ChatOpenAI

    return ChatOpenAI(
        model=model_id,
        base_url=s.openai_base_url,
        api_key=_secret(s.openai_api_key),
        timeout=s.model_timeout_s,
        max_retries=0,
        stream_usage=s.stream_usage,
        use_responses_api=s.use_responses_api,
    )


def _anthropic(model_id: str, s: AgentSettings) -> BaseChatModel:
    from langchain_anthropic import ChatAnthropic

    return ChatAnthropic(
        model=model_id,
        base_url=s.anthropic_base_url,
        api_key=_secret(s.anthropic_api_key),
        timeout=s.model_timeout_s,
        max_retries=0,
    )


def _google(model_id: str, s: AgentSettings) -> BaseChatModel:
    from langchain_google_genai import ChatGoogleGenerativeAI

    return ChatGoogleGenerativeAI(
        model=model_id,
        google_api_key=_secret(s.google_api_key),
        timeout=s.model_timeout_s,
        max_retries=0,
    )


register_provider("openai", _openai)
register_provider("anthropic", _anthropic)
register_provider("google_genai", _google)


def load_integration() -> bool:
    """Enregistre les fournisseurs propres à la banque, s'il y en a.

    Appelle `register_bank_models()` de `app/services/agent/integration.py` quand ce module et
    cette fonction existent (gabarit `modeles/integration.py`). Appelé par `agent_lifespan` et
    par les scripts d'outillage, pour que tous construisent les modèles de la même façon.
    L'enregistrement ne construit aucun client : ils le sont au premier tour.
    """
    name = f"{__package__}.integration"
    try:
        module = importlib.import_module(name)
    except ModuleNotFoundError as exc:
        if exc.name == name:
            return False
        raise
    register = getattr(module, "register_bank_models", None)
    if not callable(register):
        return False
    register()
    return True


def build_chat_model(spec: str, settings: AgentSettings) -> BaseChatModel:
    provider, sep, model_id = spec.partition(":")
    if not sep or not model_id:
        raise ModelConfigError(
            f"modèle mal défini : {spec!r} (attendu '<fournisseur>:<identifiant>')"
        )
    factory = _PROVIDERS.get(provider)
    if factory is None:
        raise ModelConfigError(
            f"fournisseur inconnu : {provider!r} (connus : {sorted(_PROVIDERS)})"
        )
    return factory(model_id, settings)


class ModelProvider:
    """Construit les modèles à la demande et applique la politique principal puis secours."""

    def __init__(self, settings: AgentSettings) -> None:
        self.settings = settings
        self._cache: dict[str, BaseChatModel] = {}

    def _get(self, spec: str) -> BaseChatModel | None:
        if not spec:
            return None
        if spec not in self._cache:
            self._cache[spec] = build_chat_model(spec, self.settings)
        return self._cache[spec]

    def fast(self) -> BaseChatModel | None:
        return self._get(self.settings.fast_model) or self._get(self.settings.model)

    async def invoke(
        self, messages: list[BaseMessage], *, tools: list[dict[str, Any]] | None
    ) -> AIMessage:
        primary = self._get(self.settings.model)
        if primary is None:
            raise ModelConfigError("HERMES_AGENT_MODEL n'est pas défini")
        plan = [(self.settings.model, primary, 2)]
        fallback = self._get(self.settings.fallback_model)
        if fallback is not None:
            plan.append((self.settings.fallback_model, fallback, 1))
        last_error: Exception | None = None
        for spec, model, attempts in plan:
            runnable = model.bind_tools(tools) if tools else model
            for attempt in range(1, attempts + 1):
                seen = False
                merged: AIMessageChunk | None = None
                try:
                    # Le délai d'httpx vaut par lecture : la durée totale est bornée ici.
                    async with asyncio.timeout(self.settings.model_total_timeout_s):
                        async for chunk in runnable.astream(messages):
                            seen = True
                            merged = chunk if merged is None else merged + chunk
                    if merged is None:
                        raise ModelUnavailable("réponse vide")
                    message = message_chunk_to_message(merged)
                    if not isinstance(message, AIMessage):
                        raise ModelUnavailable(
                            f"réponse inattendue : {type(message).__name__}"
                        )
                    message.response_metadata.setdefault("model_name", spec)
                    # Rôle du modèle qui a répondu : une bascule ne doit jamais passer inaperçue.
                    message.response_metadata["hermes_model_role"] = (
                        "principal" if spec == self.settings.model else "secours"
                    )
                    return message
                except asyncio.CancelledError:
                    raise
                except (
                    Exception
                ) as exc:  # erreurs réseau, délai, quota, réponse invalide
                    if seen:
                        raise  # des fragments sont déjà partis vers le panneau : pas de bascule
                    last_error = exc
                    log.warning(
                        "appel au modèle %s en échec (tentative %d) : %s",
                        spec,
                        attempt,
                        exc,
                    )
        raise ModelUnavailable(str(last_error)) from last_error


def message_text(message: BaseMessage) -> str:
    """Texte d'un message, que `content` soit une chaîne ou une liste de blocs."""
    value = getattr(message, "text", "")
    if isinstance(value, str):  # propriété (langchain-core 1.x)
        return str(value)
    if callable(value):  # méthode (langchain-core 0.3)
        value = value()
    return value or ""
