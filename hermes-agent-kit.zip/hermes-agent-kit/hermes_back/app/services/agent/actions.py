"""Cycle de vie des actions d'écriture : empreinte, carte, champs modifiables, confirmation écrite."""

from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field, ValidationError

from .registry import CardDraft, ToolSpec

# Statuts possibles d'une action (colonne agent_tool_calls.status).
PROPOSED, CONFIRMED, EXECUTING, EXECUTED, FAILED = (
    "proposed",
    "confirmed",
    "executing",
    "executed",
    "failed",
)
REJECTED, CANCELLED, EXPIRED = "rejected", "cancelled", "expired"

# Réponses écrites reconnues sans le modèle, pour les actions simples uniquement.
CONFIRM_WORDS = frozenset(
    {
        "oui",
        "ok",
        "okay",
        "confirme",
        "je confirme",
        "vas-y",
        "vas y",
        "go",
        "d'accord",
        "c'est bon",
        "valide",
        "yes",
    }
)

# Texte rendu au modèle pour chaque issue (section 7 de la spécification).
OUTCOME_TEXT = {
    REJECTED: "Action refusée par l'utilisateur. Ne la reproposez pas sans nouvelle demande.",
    CANCELLED: "Action annulée par une nouvelle demande de l'utilisateur.",
    EXPIRED: "Action expirée sans décision (15 minutes).",
    CONFIRMED: "Action confirmée, exécution pas encore commencée : attendez son résultat.",
    EXECUTING: "Action en cours d'exécution : attendez son résultat avant de la reproposer.",
    PROPOSED: "Action toujours en attente de décision.",
}


class CardFieldOut(BaseModel):
    label: str
    value: str


class EditableFieldOut(BaseModel):
    name: str
    label: str
    kind: str
    value: str | None = None
    options: list[str] = Field(default_factory=list)
    required: bool = True
    min_length: int = 0
    max_length: int = 1000


class ActionCard(BaseModel):
    action_id: str
    tool: str
    label: str
    level: str
    title: str
    fields: list[CardFieldOut]
    impact: str
    warnings: list[str] = Field(default_factory=list)
    editable: list[EditableFieldOut] = Field(default_factory=list)
    payload_hash: str
    expires_at: str


def canonical(args: dict[str, Any]) -> str:
    return json.dumps(
        args, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str
    )


def payload_hash(tool: str, args: dict[str, Any]) -> str:
    digest = hashlib.sha256(f"{tool}\n{canonical(args)}".encode()).hexdigest()
    return f"sha256:{digest}"


def build_card(
    spec: ToolSpec,
    draft: CardDraft,
    *,
    action_id: str,
    args: dict[str, Any],
    expires_at: datetime,
) -> ActionCard:
    return ActionCard(
        action_id=action_id,
        tool=spec.name,
        label=spec.label,
        level=spec.confirmation.value,
        title=draft.title,
        fields=[CardFieldOut(label=f.label, value=f.value) for f in draft.fields],
        impact=draft.impact,
        warnings=list(draft.warnings),
        editable=[
            EditableFieldOut(
                name=e.name,
                label=e.label,
                kind=e.kind,
                value=e.value,
                options=e.options,
                required=e.required,
                min_length=e.min_length,
                max_length=e.max_length,
            )
            for e in draft.editable
        ],
        payload_hash=payload_hash(spec.name, args),
        expires_at=expires_at.isoformat(),
    )


class EditRejected(ValueError):
    pass


# Contexte de validation des paramètres soumis par l'utilisateur. Un modèle d'arguments
# peut y exiger ce qui reste facultatif à la proposition (ex. le motif d'un jugement).
SUBMIT_CONTEXT = {"submit": True}


def is_submit(info: Any) -> bool:
    """À utiliser dans un `model_validator(mode="after")` recevant `ValidationInfo`."""
    return bool(getattr(info, "context", None) and info.context.get("submit"))


def validate_submitted(spec: ToolSpec, args: dict[str, Any]) -> Any:
    return spec.args_model.model_validate(args, context=SUBMIT_CONTEXT)


def apply_edits(
    spec: ToolSpec, stored_args: dict[str, Any], edited: dict[str, Any]
) -> dict[str, Any]:
    """Applique les champs modifiés par l'utilisateur, puis revalide avec le modèle de l'outil."""
    forbidden = set(edited) - set(spec.editable_fields)
    if forbidden:
        raise EditRejected(f"champs non modifiables : {sorted(forbidden)}")
    merged = {**stored_args, **edited}
    try:
        return validate_submitted(spec, merged).model_dump(mode="json")
    except ValidationError as exc:
        raise EditRejected(
            "; ".join(str(e.get("msg", e)) for e in exc.errors()[:5])
        ) from exc


def _normalize(text: str) -> str:
    text = unicodedata.normalize("NFKC", text).casefold()
    text = re.sub(r"[\s ]+", " ", text)
    return text.strip(" .!?;:,«»\"'")


def is_written_confirmation(text: str) -> bool:
    return _normalize(text) in CONFIRM_WORDS


def appears_in(fragment: str, texts: list[str]) -> bool:
    """Vrai si le motif proposé figure, à la ponctuation près, dans un message de l'utilisateur."""
    needle = _normalize(fragment)
    if len(needle) < 3:
        return False
    return any(needle in _normalize(t) for t in texts)
