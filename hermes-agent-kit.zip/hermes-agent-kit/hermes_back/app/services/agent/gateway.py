"""Passerelle API interne : les outils appellent l'API existante, dans le même processus.

- Seuls les couples (méthode, gabarit de route) déclarés par les outils autorisés passent.
- Chaque identifiant inséré dans un chemin est validé par un motif strict, puis encodé.
- Les cookies de session, l'en-tête CSRF et l'Origin de la requête entrante sont retransmis :
  middlewares, dépendances d'authentification et contrôles de rôle s'appliquent comme pour l'UI.
- `raise_app_exceptions=False` : une erreur de route revient en 500 au lieu de lever ici.
- `ASGITransport` garde toute la réponse en mémoire : aucun téléchargement ne passe par ici.

Règle d'usage : toute écriture en base de la requête Hermes doit être validée (commit) avant
un appel, sinon SQLite bloque l'écriture de la route appelée (« database is locked »).
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any
from urllib.parse import quote

import anyio
import httpx

_ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,128}$")
_PLACEHOLDER_RE = re.compile(r"\{([a-zA-Z_][a-zA-Z0-9_]*)\}")


class GatewayError(Exception):
    pass


class RouteNotAllowed(GatewayError):
    pass


class InvalidIdentifier(GatewayError):
    pass


class ResponseTooLarge(GatewayError):
    pass


class GatewayTimeout(GatewayError):
    """Délai dépassé. Pour une écriture, l'état réel est inconnu : la route a pu aboutir."""


@dataclass
class ApiResponse:
    status: int
    data: Any
    headers: dict[str, str] = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return 200 <= self.status < 300


@dataclass
class RequestMeta:
    """Ce qu'il faut retransmettre de la requête entrante."""

    cookies: dict[str, str]
    headers: dict[str, str]

    @classmethod
    def from_request(cls, request: Any, forward_headers: list[str]) -> RequestMeta:
        wanted = {h.lower() for h in forward_headers}
        headers = {k: v for k, v in request.headers.items() if k.lower() in wanted}
        return cls(cookies=dict(request.cookies), headers=headers)


def render_path(template: str, params: dict[str, Any] | None) -> str:
    """Construit le chemin : chaque paramètre est validé puis encodé ; aucun ne doit manquer."""
    params = dict(params or {})
    names = _PLACEHOLDER_RE.findall(template)
    missing = [n for n in names if n not in params]
    extra = [n for n in params if n not in names]
    if missing or extra:
        raise InvalidIdentifier(
            f"paramètres de chemin incorrects (manquants {missing}, en trop {extra})"
        )

    def substitute(match: re.Match[str]) -> str:
        value = str(params[match.group(1)])
        if not _ID_RE.fullmatch(
            value
        ):  # fullmatch : « $ » accepterait un saut de ligne final
            raise InvalidIdentifier(f"identifiant refusé pour {match.group(1)!r}")
        return quote(value, safe="")

    return _PLACEHOLDER_RE.sub(substitute, template)


class ApiGateway:
    def __init__(
        self,
        app: Any,
        *,
        allowed: set[tuple[str, str]],
        meta: RequestMeta,
        base_url: str = "http://hermes.internal",
        timeout_s: float = 60.0,
        max_bytes: int = 5_000_000,
    ) -> None:
        self._app = app
        self._allowed = {(m.upper(), t) for m, t in allowed}
        self._meta = meta
        self._base_url = base_url
        self._timeout = timeout_s
        self._max_bytes = max_bytes

    async def call(
        self,
        method: str,
        template: str,
        *,
        path_params: dict[str, Any] | None = None,
        query: dict[str, Any] | None = None,
        json_body: Any = None,
    ) -> ApiResponse:
        method = method.upper()
        if (method, template) not in self._allowed:
            raise RouteNotAllowed(
                f"route non déclarée par un outil autorisé : {method} {template}"
            )
        path = render_path(template, path_params)
        query = {k: v for k, v in (query or {}).items() if v is not None}
        transport = httpx.ASGITransport(app=self._app, raise_app_exceptions=False)
        try:
            # ASGITransport ignore le délai d'httpx : il est imposé ici.
            with anyio.fail_after(self._timeout):
                async with httpx.AsyncClient(
                    transport=transport,
                    base_url=self._base_url,
                    cookies=self._meta.cookies,
                    headers=self._meta.headers,
                ) as client:
                    response = await client.request(
                        method, path, params=query, json=json_body
                    )
        except TimeoutError as exc:
            raise GatewayTimeout(
                f"délai de {self._timeout:g} s dépassé pour {method} {template}"
            ) from exc
        if len(response.content) > self._max_bytes:
            raise ResponseTooLarge(
                f"réponse de {len(response.content)} octets pour {method} {template}"
            )
        return ApiResponse(
            status=response.status_code,
            data=_decode(response),
            headers={k.lower(): v for k, v in response.headers.items()},
        )


def _decode(response: httpx.Response) -> Any:
    if not response.content:
        return None
    if "json" in response.headers.get("content-type", ""):
        try:
            return response.json()
        except json.JSONDecodeError:
            return response.text
    return response.text
