"""Persistance : reprise SQLite après redémarrage, entretien périodique, baux d'exécution."""

from __future__ import annotations

import importlib.util
import sqlite3
from pathlib import Path

import pytest
from sqlalchemy import create_engine

from app.services.agent.store import schema_statements
from app.services.agent.wiring import housekeeping_once

from .scripted_model import call, say

START = {
    "control_id": "section_setting",
    "sources": [{"name": "sections", "file": "s.xlsx"}],
}


def test_migration_statements_are_idempotent(tmp_path):
    """Ce que fera la migration v016 : chaque instruction sur une connexion sqlite3, deux fois."""
    conn = sqlite3.connect(tmp_path / "hermes.db")
    for _ in range(2):
        for statement in schema_statements():
            conn.execute(statement)
        conn.commit()
    tables = {
        r[0]
        for r in conn.execute("SELECT name FROM sqlite_master WHERE type = 'table'")
    }
    assert {"agent_conversations", "agent_messages", "agent_tool_calls"} <= tables
    columns = {r[1] for r in conn.execute("PRAGMA table_info(agent_tool_calls)")}
    assert {"payload_hash", "submitted_json", "lease_until", "input_tokens"} <= columns
    conn.close()


def test_v016_template_freezes_the_current_schema(tmp_path):
    """Le gabarit de migration du kit fige le même schéma, et s'applique en sqlite3 comme en
    SQLAlchemy. Ignoré après intégration : la migration réelle a alors sa propre forme."""
    root = Path(__file__).resolve().parents[3]  # le kit, ou l'espace de travail intégré
    candidates = [
        root / "modeles" / "v016_agent.py",
        root / "hermes-agent-kit" / "modeles" / "v016_agent.py",
    ]
    template = next((p for p in candidates if p.exists()), None)
    if template is None:
        pytest.skip("gabarit absent (kit retiré après intégration)")
    spec = importlib.util.spec_from_file_location("v016_agent", template)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    def normalized(statements):
        return [" ".join(s.split()) for s in statements]

    assert normalized(module.statements()) == normalized(schema_statements())
    raw = sqlite3.connect(tmp_path / "a.db")
    module.upgrade(raw)
    module.upgrade(raw)
    raw.commit()
    engine = create_engine(f"sqlite:///{tmp_path / 'b.db'}")
    with engine.begin() as conn:
        module.upgrade(conn)
        module.upgrade(conn)
    for db in ("a.db", "b.db"):
        names = {
            r[0]
            for r in sqlite3.connect(tmp_path / db).execute(
                "SELECT name FROM sqlite_master"
            )
        }
        assert {"agent_conversations", "agent_messages", "agent_tool_calls"} <= names


def _load_script(name: str):
    """Script d'outillage : outils/ dans le kit, scripts/agent/ après intégration."""
    here = Path(__file__).resolve()
    candidates = [
        here.parents[2] / "scripts" / "agent" / name,
        here.parents[3] / "outils" / name,
    ]
    path = next((p for p in candidates if p.exists()), None)
    if path is None:
        pytest.skip(f"{name} introuvable")
    spec = importlib.util.spec_from_file_location(name.removesuffix(".py"), path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_migration_checker_compares_with_schema_sql(tmp_path):
    """verifier_migration.py (étape 5) : conforme malgré la casse et les blancs, écarts nommés."""
    checker = _load_script("verifier_migration.py")
    good = tmp_path / "good.db"
    conn = sqlite3.connect(good)
    for statement in schema_statements():
        conn.execute(" ".join(statement.lower().split()))
    conn.commit()
    conn.close()
    assert checker.compare(good) == []

    bad = tmp_path / "bad.db"
    conn = sqlite3.connect(bad)
    for statement in schema_statements():
        if "ix_agent_tool_calls_model_call" not in statement:
            conn.execute(statement.replace("prompt_version TEXT,", ""))
    conn.execute("ALTER TABLE agent_conversations ADD COLUMN note TEXT")
    conn.commit()
    conn.close()
    problems = checker.compare(bad)
    assert "colonne absente : agent_messages.prompt_version" in problems
    assert "colonne absente : agent_tool_calls.prompt_version" in problems
    assert "index absent : ix_agent_tool_calls_model_call" in problems
    assert "colonne en trop : agent_conversations.note" in problems
    assert checker.compare(tmp_path / "absente.db") == [
        f"base introuvable : {tmp_path / 'absente.db'}"
    ]


def test_pending_action_survives_a_restart(harness):
    """Proposée par un worker, confirmée après redémarrage : l'interruption est en base."""
    harness.model.script(
        call("start_execution", START), say("Run lancé après redémarrage.")
    )
    saved: dict = {}

    async def propose(env):
        client = env.client("tok-manager")
        saved["conv"] = await client.conversation()
        saved["card"] = (await client.send(saved["conv"], "Lance section_setting")).card

    async def confirm(env):
        client = env.client("tok-manager")
        result = await client.decide(saved["conv"], saved["card"])
        assert result.statuses(saved["card"]["action_id"]) == [
            "confirmed",
            "executing",
            "executed",
        ]
        assert result.text == "Run lancé après redémarrage."

    harness.run(propose, sqlite_checkpoints=True)
    harness.run(confirm, sqlite_checkpoints=True)
    assert harness.checkpoint_db.exists()
    assert len([b for b in harness.fake.bodies if b[0] == "start_execution"]) == 1


def test_housekeeping_purges_old_threads_and_fails_stale_leases(harness):
    harness.model.script(say("Bonjour."), call("start_execution", START))

    async def scenario(env):
        client = env.client("tok-manager")
        old = await client.conversation()
        await client.send(old, "Bonjour")
        conv = await client.conversation()
        card = (await client.send(conv, "Lance section_setting")).card
        env.sql(
            "UPDATE agent_conversations SET updated_at = '2000-01-01T00:00:00.000000+00:00' WHERE id = :id",
            id=old,
        )
        env.sql(
            "UPDATE agent_tool_calls SET status = 'executing', lease_until = '2000-01-01T00:00:00.000000+00:00' WHERE id = :id",
            id=card["action_id"],
        )
        await housekeeping_once(env.service)
        purged = env.service.store.get_conversation(old)
        assert purged["purged_at"] is not None
        assert env.service.store.get_conversation(conv)["purged_at"] is None
        assert (await client.send(old, "Encore là ?")).status == 409
        stale = env.action(card["action_id"])
        assert stale["status"] == "failed" and stale["error"] == "interrompue"
        # Le panneau relit la conversation : plus d'action en attente.
        detail = (await client.get(f"/api/agent/conversations/{conv}")).json()
        assert detail["pending_action"] is None

    harness.run(scenario, sqlite_checkpoints=True)
