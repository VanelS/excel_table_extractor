from __future__ import annotations

import os

import pytest

from .harness import Harness, reset_sse_loop_state


@pytest.fixture(autouse=True)
def _no_ambient_agent_settings(monkeypatch):
    """Les tests ne dépendent pas des variables HERMES_AGENT_* du poste. Les fichiers .env et
    agent.env ne sont pas lus non plus : les tests construisent AgentSettings(_env_file=None)."""
    for name in list(os.environ):
        if name.startswith("HERMES_AGENT_"):
            monkeypatch.delenv(name)


@pytest.fixture(autouse=True)
def _sse_exit_event_per_loop():
    """Tests hors banc (TestClient…) : même remise à zéro que `Harness.run`, voir
    `reset_sse_loop_state`."""
    reset_sse_loop_state()


@pytest.fixture
def harness(tmp_path) -> Harness:
    return Harness(tmp_path)
