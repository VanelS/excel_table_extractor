"""Phase 2 : jugements et révocations, cartes renforcées, motif venu de l'utilisateur."""

from __future__ import annotations

import json

from langchain_core.messages import ToolMessage

from .scripted_model import call, say

RUN = "01JRUN0011"
LINES = [
    {"identity_key": "SEC_4091_MADONNE", "rule_name": "ctrl_service_ok"},
    {"identity_key": "SEC_4092_DURAND", "rule_name": "ctrl_service_ok"},
]
REASON = "dérogation validée par la direction des risques le 12/09"


def _judge(**overrides):
    args = {"run_id": RUN, "items": LINES, "judgment": "OK_EXCEPTION", "reason": REASON}
    args.update(overrides)
    return call("create_dispositions", args)


def _created(env):
    return [b[1] for b in env.fake.bodies if b[0] == "create_disposition"]


def test_dispositions_card_and_confirmation(harness):
    harness.model.script(_judge(), say("Les deux lignes sont jugées."))

    async def scenario(env):
        client = env.client("tok-manager")
        conv = await client.conversation()
        turn = await client.send(
            conv,
            f"Passe SEC_4091 et SEC_4092 en OK_EXCEPTION, motif : {REASON}",
        )
        card = turn.card
        assert card["level"] == "reinforced"
        editable = {e["name"]: e for e in card["editable"]}
        assert editable["judgment"]["value"] == "OK_EXCEPTION"
        assert editable["reason"]["value"] == REASON
        assert card["warnings"] == []
        fields = {f["label"]: f["value"] for f in card["fields"]}
        assert fields["Contrôle"] == "section_setting (v009)"

        # Confirmation écrite refusée pour une action renforcée.
        typed = await client.send(conv, "oui")
        assert typed.text == "Pour cette action, confirmez avec le bouton de la carte."
        assert env.action(card["action_id"])["status"] == "proposed"
        assert not _created(env)

        result = await client.decide(conv, card)
        assert result.statuses(card["action_id"]) == [
            "confirmed",
            "executing",
            "executed",
        ]
        bodies = _created(env)
        assert [b["identity_key"] for b in bodies] == [
            "SEC_4091_MADONNE",
            "SEC_4092_DURAND",
        ]
        assert all(
            b["control_version"] == "v009" and b["run_id"] == RUN for b in bodies
        )
        assert all(b["reason"] == REASON for b in bodies)
        summary = json.loads(env.action(card["action_id"])["result_summary_json"])
        assert len(summary["recorded"]) == 2 and summary["failed"] == []

    harness.run(scenario, phase=2)


def test_invented_reason_is_cleared_and_required(harness):
    harness.model.script(
        _judge(reason="Faux positif confirmé par le métier"),
        say("Jugement enregistré."),
    )

    async def scenario(env):
        client = env.client("tok-manager")
        conv = await client.conversation()
        card = (await client.send(conv, "Passe ces deux lignes en OK_EXCEPTION")).card
        editable = {e["name"]: e for e in card["editable"]}
        assert editable["reason"]["value"] == ""
        assert any("vidé" in w for w in card["warnings"])

        # Sans motif saisi, la confirmation est refusée.
        missing = await client.decide(conv, card)
        assert missing.status == 422
        assert "motif" in missing.body["detail"]

        # Avec le motif saisi dans la carte : enregistré tel que soumis.
        result = await client.decide(
            conv, card, edited={"reason": "Validé par M. Dupont"}
        )
        assert result.statuses(card["action_id"])[-1] == "executed"
        assert {b["reason"] for b in _created(env)} == {"Validé par M. Dupont"}
        action = env.action(card["action_id"])
        assert json.loads(action["args_json"])["reason"] == ""
        assert json.loads(action["submitted_json"])["reason"] == "Validé par M. Dupont"
        assert action["payload_hash"] != card["payload_hash"]

    harness.run(scenario, phase=2)


def test_judgment_left_to_the_user(harness):
    harness.model.script(_judge(judgment=None, reason=""), say("Fait."))

    async def scenario(env):
        client = env.client("tok-manager")
        conv = await client.conversation()
        card = (await client.send(conv, "Juge ces deux lignes")).card
        editable = {e["name"]: e for e in card["editable"]}
        assert editable["judgment"]["value"] is None
        assert editable["judgment"]["options"] == [
            "OK_EXCEPTION",
            "FALSE_POSITIVE",
            "ACCEPTED_RISK",
            "TRANSFERRED",
        ]
        bad = await client.decide(
            conv, card, edited={"judgment": "TOUT_OK", "reason": "abc"}
        )
        assert bad.status == 422
        ok = await client.decide(
            conv, card, edited={"judgment": "FALSE_POSITIVE", "reason": "Doublon"}
        )
        assert ok.statuses(card["action_id"])[-1] == "executed"
        assert {b["judgment"] for b in _created(env)} == {"FALSE_POSITIVE"}

    harness.run(scenario, phase=2)


def test_partial_failure_lists_recorded_and_failed(harness):
    harness.model.script(
        _judge(
            items=LINES[:1]
            + [{"identity_key": "SEC_FAIL", "rule_name": "ctrl_service_ok"}]
        ),
        say("Une ligne a échoué."),
    )

    async def scenario(env):
        client = env.client("tok-manager")
        conv = await client.conversation()
        card = (
            await client.send(
                conv, f"Passe SEC_4091 et SEC_FAIL en OK_EXCEPTION, motif : {REASON}"
            )
        ).card
        result = await client.decide(conv, card)
        assert result.statuses(card["action_id"])[-1] == "failed"
        summary = json.loads(env.action(card["action_id"])["result_summary_json"])
        assert [r["identity_key"] for r in summary["recorded"]] == ["SEC_4091_MADONNE"]
        assert [r["identity_key"] for r in summary["failed"]] == ["SEC_FAIL"]
        outcome = [m for m in env.model.received[-1] if isinstance(m, ToolMessage)][-1]
        assert "Ne reproposez que les lignes en échec" in outcome.content

    harness.run(scenario, phase=2)


def test_batch_limit_and_unknown_lines(harness):
    many = [
        {"identity_key": f"K{i}", "rule_name": "ctrl_service_ok"} for i in range(21)
    ]
    harness.model.script(
        _judge(items=many),
        say("Trop de lignes : j'ouvre la page."),
        _judge(items=[{"identity_key": "INCONNUE", "rule_name": "ctrl_service_ok"}]),
        say("Ligne introuvable."),
    )

    async def scenario(env):
        client = env.client("tok-manager")
        conv = await client.conversation()
        first = await client.send(conv, f"Juge tout en OK_EXCEPTION, motif : {REASON}")
        assert "action.proposed" not in first.names
        refusal = [m for m in env.model.received[-1] if isinstance(m, ToolMessage)][-1]
        assert "20 au plus" in refusal.content
        second = await client.send(
            conv, f"Juge INCONNUE en OK_EXCEPTION, motif : {REASON}"
        )
        assert "action.proposed" not in second.names
        refusal = [m for m in env.model.received[-1] if isinstance(m, ToolMessage)][-1]
        assert "introuvable" in refusal.content

    harness.run(scenario, phase=2)


def test_revoke_disposition(harness):
    harness.model.script(
        call(
            "revoke_disposition",
            {"control_id": "section_setting", "disposition_id": "disp_0001"},
        ),
        say("Jugement révoqué."),
    )

    async def scenario(env):
        client = env.client("tok-manager")
        conv = await client.conversation()
        card = (await client.send(conv, "Révoque le jugement de SEC_4093")).card
        fields = {f["label"]: f["value"] for f in card["fields"]}
        assert fields["Ligne"] == "SEC_4093_MARTIN"
        assert (
            fields["Auteur"] == "analyste@banque.test"
        )  # visible sur la carte, pas par le modèle
        assert card["impact"] == "La ligne redeviendra un nouveau KO au prochain run."
        result = await client.decide(conv, card)
        assert result.statuses(card["action_id"])[-1] == "executed"
        assert ("revoke", "disp_0001") in env.fake.bodies

    harness.run(scenario, phase=2)


def test_disposition_tools_closed_in_phase_one(harness):
    harness.model.script(_judge(), say("Les jugements arrivent en phase 2."))

    async def scenario(env):
        client = env.client("tok-manager")
        turn = await client.send(
            await client.conversation(), "Passe SEC_4091 en OK_EXCEPTION"
        )
        assert "action.proposed" not in turn.names
        assert not _created(env)

    harness.run(scenario)
