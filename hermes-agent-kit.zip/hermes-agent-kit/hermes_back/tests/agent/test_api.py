"""Endpoints /api/agent : session, CSRF, Origin, propriété, débit, verrou, déduplication."""

from __future__ import annotations

import httpx

from .fake_hermes import CSRF, ORIGIN
from .scripted_model import say


def test_session_csrf_and_origin_are_enforced(harness):
    async def scenario(env):
        anonymous = env.client(None)
        assert (await anonymous.get("/api/agent/conversations")).status_code == 401

        client = env.client("tok-user")
        conv = await client.conversation()
        no_csrf = await client.http.post(
            f"/api/agent/conversations/{conv}/messages",
            json={"request_id": "req-00000001", "content": "Bonjour"},
            headers={"x-csrf-token": "faux"},
        )
        assert no_csrf.status_code == 403
        foreign = httpx.AsyncClient(
            transport=httpx.ASGITransport(app=env.app),
            base_url="http://testserver",
            cookies={"hermes_session": "tok-user", "hermes_csrf": CSRF},
            headers={"x-csrf-token": CSRF, "origin": "https://evil.example"},
        )
        async with foreign:
            response = await foreign.post("/api/agent/conversations", json={})
        assert response.status_code == 403

    harness.run(scenario)


def test_conversations_are_private(harness):
    harness.model.script(say("Bonjour."))

    async def scenario(env):
        alice, bob = env.client("tok-user"), env.client("tok-user2")
        conv = await alice.conversation()
        await alice.send(conv, "Bonjour")
        assert (await bob.get(f"/api/agent/conversations/{conv}")).status_code == 404
        assert (await bob.send(conv, "Je lis ?")).status == 404
        assert (
            await bob.http.post(f"/api/agent/conversations/{conv}/archive")
        ).status_code == 404
        assert (await bob.get("/api/agent/conversations")).json() == []
        listed = (await alice.get("/api/agent/conversations")).json()
        assert [c["id"] for c in listed] == [conv]
        unknown = await alice.get("/api/agent/conversations/conv_" + "0" * 32)
        assert unknown.status_code == 404
        malformed = await alice.get("/api/agent/conversations/../../api/health")
        assert malformed.status_code == 404

    harness.run(scenario)


def test_archive_hides_conversation(harness):
    async def scenario(env):
        client = env.client("tok-user")
        conv = await client.conversation()
        archived = await client.http.post(f"/api/agent/conversations/{conv}/archive")
        assert archived.status_code == 204
        assert (await client.get(f"/api/agent/conversations/{conv}")).status_code == 404
        assert (await client.get("/api/agent/conversations")).json() == []

    harness.run(scenario)


def test_rate_limit(harness):
    harness.model.script(say("1"), say("2"))

    async def scenario(env):
        client = env.client("tok-user")
        conv = await client.conversation()
        assert (await client.send(conv, "un")).status == 200
        assert (await client.send(conv, "deux")).status == 200
        limited = await client.send(conv, "trois")
        assert limited.status == 429
        # Un événement de fin de run n'entre pas dans la limite.
        event = await client.send(
            conv, event={"type": "run_completed", "run_id": "01JRUN0011"}
        )
        assert event.status == 200

    harness.model.script(say("Le run 01JRUN0011 est terminé."))
    harness.run(scenario, rate_limit="2/5min")


def test_turn_lock_returns_409(harness):
    async def scenario(env):
        client = env.client("tok-user")
        conv = await client.conversation()
        assert env.service.store.acquire_turn_lock(conv, 600, "lock_test")
        busy = await client.send(conv, "Bonjour")
        assert busy.status == 409
        env.service.store.release_turn_lock(conv, "lock_test")
        env.model.script(say("Bonjour."))
        assert (await client.send(conv, "Bonjour")).status == 200

    harness.run(scenario)


def test_browser_retry_replays_the_reply(harness):
    harness.model.script(say("Réponse unique."))

    async def scenario(env):
        client = env.client("tok-user")
        conv = await client.conversation()
        first = await client.send(conv, "Bonjour", request_id="req-retry-0001")
        again = await client.send(conv, "Bonjour", request_id="req-retry-0001")
        assert first.text == again.text == "Réponse unique."
        assert len(env.model.received) == 1  # le modèle n'est pas rappelé
        messages = (await client.get(f"/api/agent/conversations/{conv}")).json()[
            "messages"
        ]
        assert [m["role"] for m in messages] == ["user", "assistant"]

    harness.run(scenario)


def test_message_validation(harness):
    async def scenario(env):
        client = env.client("tok-user")
        conv = await client.conversation()
        empty = await client.http.post(
            f"/api/agent/conversations/{conv}/messages",
            json={"request_id": "req-00000002", "content": "   "},
        )
        assert empty.status_code == 422
        both = await client.http.post(
            f"/api/agent/conversations/{conv}/messages",
            json={
                "request_id": "req-00000003",
                "content": "x",
                "event": {"type": "run_completed", "run_id": "01JRUN0011"},
            },
        )
        assert both.status_code == 422
        too_long = await client.send(conv, "x" * 4001)
        assert too_long.status == 422
        bad_scope = await client.http.post(
            "/api/agent/conversations", json={"scope": "run"}
        )
        assert bad_scope.status_code == 422

    harness.run(scenario)


def test_capabilities_suggestions_follow_role_and_page(harness):
    async def scenario(env):
        user = (await env.client("tok-user").get("/api/agent/capabilities")).json()
        manager = (
            await env.client("tok-manager").get(
                "/api/agent/capabilities", params={"route": "/executions/:runId"}
            )
        ).json()
        assert not any("Relance" in s for s in user["suggestions"])
        assert manager["suggestions"][0] == "Résume les nouveaux KO de ce run."
        assert any(t["confirmation"] == "simple" for t in manager["tools"])

    harness.run(scenario)


def test_agent_disabled_answers_404(harness):
    async def scenario(env):
        response = await env.client("tok-user").get("/api/agent/capabilities")
        assert response.status_code == 404

    harness.run(scenario, enabled=False)


def test_purged_conversation_is_read_only(harness):
    async def scenario(env):
        client = env.client("tok-user")
        conv = await client.conversation()
        env.sql(
            "UPDATE agent_conversations SET purged_at = '2026-01-01T00:00:00.000000+00:00' WHERE id = :id",
            id=conv,
        )
        assert (await client.send(conv, "Bonjour")).status == 409
        assert (await client.get(f"/api/agent/conversations/{conv}")).status_code == 200

    harness.run(scenario)


def test_attachment_names_reach_the_model(harness):
    harness.model.script(say("Fichier reçu."))

    async def scenario(env):
        client = env.client("tok-manager")
        conv = await client.conversation()
        await client.send(
            conv,
            "Lance avec ce fichier",
            attachments=[{"name": "sections_2026-09.xlsx"}],
        )
        human = env.model.received[0][-1]
        assert "sections_2026-09.xlsx" in human.content
        rejected = await client.send(
            conv, "Et celui-ci", attachments=[{"name": "../../etc/passwd"}]
        )
        assert rejected.status == 422

    harness.run(scenario)


def test_origin_is_required_for_agent_posts(harness):
    async def scenario(env):
        client = env.client("tok-user")
        response = await client.http.post(
            "/api/agent/conversations", json={}, headers={"origin": ORIGIN}
        )
        assert response.status_code == 201

    harness.run(scenario)
