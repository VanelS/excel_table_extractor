"""Bac à sable SQL : SELECT unique, aucun accès fichier, limites de temps et de lignes."""

from __future__ import annotations

import asyncio

import duckdb
import httpx
import pytest
from fastapi import FastAPI, HTTPException

from app.services.run_query import (
    QueryRejected,
    QueryTimeout,
    RunData,
    SandboxLimits,
    build_run_query_router,
    check_select,
    describe_run,
    run_select,
)

DISPOSITIONS = [
    {
        "identity_key": "K0",
        "rule_name": "ctrl_a",
        "judgment": "OK_EXCEPTION",
        "reason": "x",
    }
]


@pytest.fixture
def parquet(tmp_path):
    path = tmp_path / "20261010_processed.parquet"
    duckdb.connect().execute(
        "COPY (SELECT 'K' || range AS identity_key, 'ctrl_a' AS control_rule, "
        "CASE WHEN range % 3 = 0 THEN 'KO' ELSE 'OK' END AS control_status, "
        f"range * 1.5 AS montant FROM range(30)) TO '{path}' (FORMAT parquet)"
    )
    return path


@pytest.mark.parametrize(
    "sql",
    [
        "DELETE FROM run_rows",
        "SELECT 1; SELECT 2",
        "COPY run_rows TO 'x.csv'",
        "ATTACH 'x.db'",
        "INSTALL httpfs",
        "SET threads = 64",
        "CREATE TABLE t AS SELECT 1",
        "PIVOT run_rows ON control_status",
        "EXPLAIN SELECT 1",
        "pas du sql",
    ],
)
def test_only_a_single_select_is_accepted(sql):
    with pytest.raises(QueryRejected):
        check_select(sql)


def test_select_with_active_judgments(parquet):
    result = run_select(
        "SELECT control_status, count(*) AS n FROM anomalies GROUP BY 1 ORDER BY 1",
        parquet_path=parquet,
        dispositions=DISPOSITIONS,
    )
    assert result.rows == [
        {"control_status": "KO", "n": 10},
        {"control_status": "OK", "n": 20},
    ]
    judged = run_select(
        "SELECT identity_key FROM anomalies WHERE active_judgment = 'OK_EXCEPTION'",
        parquet_path=parquet,
        dispositions=DISPOSITIONS,
    )
    assert judged.rows == [{"identity_key": "K0"}]
    assert "anomalies" in describe_run(parquet)


@pytest.mark.parametrize(
    "sql",
    [
        "SELECT * FROM read_csv('/etc/passwd')",
        "SELECT * FROM read_parquet('{parquet}')",
        "SELECT * FROM glob('/*')",
    ],
)
def test_no_file_access_from_the_query(parquet, sql):
    with pytest.raises(duckdb.Error):
        run_select(sql.format(parquet=parquet), parquet_path=parquet)


def test_configuration_is_locked(parquet):
    with pytest.raises(QueryRejected):
        run_select("SET enable_external_access = true", parquet_path=parquet)
    with pytest.raises(duckdb.Error):
        run_select(
            "SELECT set_config('enable_external_access', 'true')", parquet_path=parquet
        )


def test_timeout_and_row_limit(parquet):
    with pytest.raises(QueryTimeout):
        run_select(
            "SELECT count(*) FROM range(100000000000) a",
            parquet_path=parquet,
            limits=SandboxLimits(timeout_s=0.3),
        )
    capped = run_select("SELECT * FROM range(5000)", parquet_path=parquet)
    assert capped.row_count == 1000 and capped.truncated


def test_endpoint_wiring(parquet):
    seen: dict = {}

    def resolve_run(run_id, user):
        if run_id != "01JRUN0011":
            raise HTTPException(status_code=404, detail="Run introuvable")
        return RunData(parquet_path=parquet, dispositions=DISPOSITIONS)

    async def generate_sql(question, tables):
        seen["tables"] = tables
        return "SELECT count(*) AS ko FROM anomalies WHERE control_status = 'KO'"

    def record_query(**kwargs):
        seen["recorded"] = kwargs

    app = FastAPI()
    app.include_router(
        build_run_query_router(
            current_user=lambda: {"sub": "u"},
            resolve_run=resolve_run,
            generate_sql=generate_sql,
            record_query=record_query,
            is_open=lambda request: True,
        )
    )

    async def scenario():
        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=app), base_url="http://t"
        ) as client:
            ok = await client.post(
                "/api/executions/01JRUN0011/query", json={"question": "Combien de KO ?"}
            )
            missing = await client.post(
                "/api/executions/01JAUTRE/query", json={"question": "Combien ?"}
            )
            return ok, missing

    ok, missing = asyncio.run(scenario())
    assert ok.status_code == 200 and ok.json()["rows"] == [{"ko": 10}]
    assert missing.status_code == 404
    assert "run_rows" in seen["tables"] and seen["recorded"]["row_count"] == 1
