"""Banc de test : application factice, agent branché comme en production, modèle simulé.

Les tests sont synchrones et lancent chacun leur scénario avec `asyncio.run` : ils ne
dépendent d'aucun greffon pytest asynchrone (pytest-asyncio, anyio), quel que soit celui
que la suite de tests de l'application utilise déjà.
"""

from __future__ import annotations

import asyncio
import json
import uuid
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import httpx
from langgraph.checkpoint.memory import InMemorySaver
from sqlalchemy import create_engine, text

from app.services.agent.config import AgentSettings
from app.services.agent.llm import register_provider
from app.services.agent.service import AgentService
from app.services.agent.wiring import agent_lifespan, include_agent_router

from .fake_hermes import (
    CSRF,
    ORIGIN,
    FakeState,
    create_fake_app,
    csrf_protect,
    current_user,
)
from .scripted_model import ScriptedChatModel

# Fournisseur « scripted » : HERMES_AGENT_MODEL=scripted:main désigne le modèle simulé.
MODELS: dict[str, ScriptedChatModel] = {}
register_provider("scripted", lambda model_id, settings: MODELS[model_id])


@dataclass
class Turn:
    """Réponse d'un POST de message ou de décision : code HTTP et événements SSE."""

    status: int
    events: list[tuple[str, dict[str, Any]]] = field(default_factory=list)
    body: Any = None

    @classmethod
    def parse(cls, response: httpx.Response) -> Turn:
        if response.status_code != 200:
            try:
                body = response.json()
            except ValueError:
                body = response.text
            return cls(status=response.status_code, body=body)
        events: list[tuple[str, dict[str, Any]]] = []
        for block in response.text.replace("\r\n", "\n").split("\n\n"):
            name, data = None, []
            for line in block.split("\n"):
                if line.startswith("event:"):
                    name = line[6:].strip()
                elif line.startswith("data:"):
                    data.append(line[5:].lstrip())
            if name:
                events.append((name, json.loads("\n".join(data)) if data else {}))
        return cls(status=200, events=events)

    @property
    def names(self) -> list[str]:
        return [name for name, _ in self.events]

    def of(self, name: str) -> list[dict[str, Any]]:
        return [data for event, data in self.events if event == name]

    def first(self, name: str) -> dict[str, Any]:
        found = self.of(name)
        assert found, f"aucun événement {name} dans {self.names}"
        return found[0]

    @property
    def text(self) -> str | None:
        completed = self.of("message.completed")
        return completed[-1]["content"] if completed else None

    @property
    def card(self) -> dict[str, Any]:
        return self.first("action.proposed")

    def statuses(self, action_id: str) -> list[str]:
        return [
            d["status"]
            for d in self.of("action.updated")
            if d.get("action_id") == action_id
        ]


class Client:
    """Navigateur simulé : cookies de session et CSRF, Origin du front, comme le panneau."""

    def __init__(self, app: Any, token: str | None) -> None:
        cookies = {"hermes_csrf": CSRF}
        if token:
            cookies["hermes_session"] = token
        self.http = httpx.AsyncClient(
            transport=httpx.ASGITransport(app=app),
            base_url="http://testserver",
            cookies=cookies,
            headers={"x-csrf-token": CSRF, "origin": ORIGIN},
        )

    async def conversation(self, **body: Any) -> str:
        response = await self.http.post("/api/agent/conversations", json=body)
        assert response.status_code == 201, response.text
        return response.json()["id"]

    async def send(
        self,
        conversation_id: str,
        content: str | None = None,
        *,
        event: dict[str, Any] | None = None,
        page_context: dict[str, Any] | None = None,
        request_id: str | None = None,
        attachments: list[dict[str, str]] | None = None,
    ) -> Turn:
        body: dict[str, Any] = {"request_id": request_id or uuid.uuid4().hex}
        if content is not None:
            body["content"] = content
        if event is not None:
            body["event"] = event
        if page_context is not None:
            body["page_context"] = page_context
        if attachments:
            body["attachments"] = attachments
        response = await self.http.post(
            f"/api/agent/conversations/{conversation_id}/messages", json=body
        )
        return Turn.parse(response)

    async def decide(
        self,
        conversation_id: str,
        card: dict[str, Any],
        decision: str = "confirm",
        *,
        edited: dict[str, str] | None = None,
        payload_hash: str | None = None,
    ) -> Turn:
        response = await self.http.post(
            f"/api/agent/conversations/{conversation_id}/actions/{card['action_id']}/decision",
            json={
                "decision": decision,
                "payload_hash": payload_hash or card["payload_hash"],
                "edited_fields": edited or {},
            },
        )
        return Turn.parse(response)

    async def get(self, path: str, **kwargs: Any) -> httpx.Response:
        return await self.http.get(path, **kwargs)

    async def aclose(self) -> None:
        await self.http.aclose()


@dataclass
class Env:
    app: Any
    fake: FakeState
    model: ScriptedChatModel
    fallback: ScriptedChatModel
    engine: Any
    clients: list[Client] = field(default_factory=list)

    @property
    def service(self) -> AgentService:
        return self.app.state.hermes_agent

    def client(self, token: str | None = "tok-manager") -> Client:
        client = Client(self.app, token)
        self.clients.append(client)
        return client

    def action(self, action_id: str) -> dict[str, Any]:
        row = self.service.store.get_tool_call(action_id)
        assert row is not None
        return row

    def tool_calls(self) -> list[dict[str, Any]]:
        with self.engine.connect() as conn:
            return [
                dict(r._mapping)
                for r in conn.execute(
                    text("SELECT * FROM agent_tool_calls ORDER BY proposed_at")
                )
            ]

    def sql(self, statement: str, **params: Any) -> None:
        with self.engine.begin() as conn:
            conn.execute(text(statement), params)

    async def close(self) -> None:
        for client in self.clients:
            await client.aclose()


class Harness:
    def __init__(self, tmp_path: Path) -> None:
        self.fake = FakeState.seed()
        self.model = ScriptedChatModel()
        self.fallback = ScriptedChatModel()
        self.engine = create_engine(f"sqlite:///{tmp_path / 'hermes.db'}")
        self.checkpoint_db = tmp_path / "db" / "agent_checkpoints.db"

    def settings(self, **overrides: Any) -> AgentSettings:
        values: dict[str, Any] = {"enabled": True, "model": "scripted:main"}
        values.update(overrides)
        return AgentSettings(_env_file=None, **values)

    def run(
        self,
        scenario: Callable[[Env], Awaitable[Any]],
        *,
        sqlite_checkpoints: bool = False,
        **overrides: Any,
    ) -> Any:
        """Démarre l'agent comme `create_app` le fera, puis joue `scenario(env)`.

        `sqlite_checkpoints=True` utilise la base de reprise SQLite de production
        (`HERMES_AGENT_CHECKPOINT_DB`) au lieu de la mémoire : elle survit à un redémarrage.
        """

        async def main() -> Any:
            MODELS["main"] = self.model
            MODELS["fallback"] = self.fallback
            app = create_fake_app(self.fake)
            include_agent_router(
                app, current_user=current_user, csrf_dependency=csrf_protect
            )
            if sqlite_checkpoints:
                overrides.setdefault("checkpoint_db", str(self.checkpoint_db))
            async with agent_lifespan(
                app,
                engine=self.engine,
                settings=self.settings(**overrides),
                checkpointer=None if sqlite_checkpoints else InMemorySaver(),
                create_schema=True,
            ):
                env = Env(app, self.fake, self.model, self.fallback, self.engine)
                try:
                    return await scenario(env)
                finally:
                    await env.close()

        reset_sse_loop_state()
        return asyncio.run(main())


def reset_sse_loop_state() -> None:
    """sse-starlette 2.x garde un `anyio.Event` global, lié à la première boucle d'événements
    qui l'utilise. Chaque `asyncio.run` ouvrant une boucle neuve (plusieurs par test pour simuler
    un redémarrage), il est remis à zéro avant chacune. Sans objet à partir de sse-starlette 3
    (l'attribut n'existe plus), ni en production (une seule boucle par processus)."""
    from sse_starlette.sse import AppStatus

    if hasattr(AppStatus, "should_exit_event"):
        AppStatus.should_exit_event = None
