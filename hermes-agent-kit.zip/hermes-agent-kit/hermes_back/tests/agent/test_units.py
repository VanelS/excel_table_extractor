"""Briques sans HTTP : registre, schémas d'outils, empreinte, confirmation écrite, historique."""

from __future__ import annotations

import asyncio

import pytest
from langchain_core.messages import AIMessage, HumanMessage, ToolMessage
from pydantic import BaseModel

from app.services.agent import domain
from app.services.agent.actions import (
    EditRejected,
    appears_in,
    apply_edits,
    is_written_confirmation,
    payload_hash,
)
from app.services.agent.config import AgentSettings
from app.services.agent.domain import (
    APP_ROUTES,
    PAGES,
    PageContext,
    Role,
    UserContext,
    default_user_mapper,
    page_of,
    page_params,
    page_url,
)
from app.services.agent.graph import _shielded, prepare_history
from app.services.agent.llm import ModelConfigError, ModelProvider, build_chat_model
from app.services.agent.registry import _inline_schema, load_tools, tools_for


def _settings(**values):
    return AgentSettings(_env_file=None, **values)


def test_every_tool_is_consistent():
    registry = load_tools()
    for spec in registry.values():
        schema = spec.model_schema()["function"]["parameters"]
        assert "$ref" not in str(schema) and "$defs" not in schema
        assert spec.description and spec.label
        for route in spec.routes:
            assert route.template.startswith("/api/")
            assert route.method in {"GET", "POST", "PUT", "DELETE", "PATCH"}
        if spec.is_write:
            assert spec.card_builder is not None
            assert spec.min_role is not Role.USER
    # Aucun outil n'appelle les routes que la spécification tient hors de portée de l'agent.
    forbidden = {
        ("DELETE", "/api/controls/{control_id}/versions/{version}"),
        ("DELETE", "/api/evidence/{filename}"),
        ("GET", "/api/logs"),
        ("DELETE", "/api/logs"),
    }
    declared = {(r.method, r.template) for s in registry.values() for r in s.routes}
    assert not declared & forbidden


def test_tools_for_filters_role_phase_and_catalog():
    user = UserContext(sub="u", roles=frozenset({"USER"}))
    admin = UserContext(sub="a", roles=frozenset({"ADMIN"}))
    assert "start_execution" not in tools_for(user, _settings())
    assert "start_execution" in tools_for(
        admin, _settings()
    )  # ADMIN englobe USER_MANAGER
    assert "create_dispositions" not in tools_for(admin, _settings(phase=1))
    assert "create_dispositions" in tools_for(admin, _settings(phase=2))
    assert "list_workbooks" not in tools_for(
        admin, _settings(phase=3)
    )  # désactivé par défaut
    assert "list_workbooks" in tools_for(
        admin, _settings(phase=3, enabled_tools="list_workbooks")
    )
    assert "get_execution" not in tools_for(
        admin, _settings(disabled_tools="get_execution,open_page")
    )
    nobody = UserContext(sub="x", roles=frozenset({"INCONNU"}))
    assert tools_for(nobody, _settings()) == {}


def test_inline_schema_keeps_fields_named_title():
    class Inner(BaseModel):
        title: str

    class Outer(BaseModel):
        """Doc"""

        title: str
        inner: Inner

    schema = _inline_schema(Outer.model_json_schema())
    assert set(schema["properties"]) == {"title", "inner"}
    assert set(schema["properties"]["inner"]["properties"]) == {"title"}
    assert "title" not in schema


def test_payload_hash_is_canonical():
    a = payload_hash("start_execution", {"b": 1, "a": [1, 2]})
    b = payload_hash("start_execution", {"a": [1, 2], "b": 1})
    assert a == b and a.startswith("sha256:")
    assert a != payload_hash("rerun_execution", {"b": 1, "a": [1, 2]})


def test_apply_edits_only_on_editable_fields():
    spec = load_tools()["create_dispositions"]
    stored = {
        "run_id": "01JRUN0011",
        "items": [{"identity_key": "K1", "rule_name": "r"}],
        "judgment": None,
        "reason": "",
        "control_id": "section_setting",
        "control_version": "v009",
    }
    with pytest.raises(EditRejected):
        apply_edits(spec, stored, {"run_id": "autre"})
    with pytest.raises(EditRejected):
        apply_edits(spec, stored, {"reason": "ok ok"})  # jugement encore vide
    final = apply_edits(
        spec, stored, {"judgment": "OK_EXCEPTION", "reason": "Motif saisi"}
    )
    assert final["reason"] == "Motif saisi" and final["control_version"] == "v009"


@pytest.mark.parametrize(
    "text", ["oui", "Oui !", "  OK.", "je confirme", "Vas-y", "c'est bon", "yes"]
)
def test_written_confirmations(text):
    assert is_written_confirmation(text)


@pytest.mark.parametrize(
    "text", ["oui mais lance plutôt v008", "non", "ok pour v001", "confirme le run 12"]
)
def test_not_written_confirmations(text):
    assert not is_written_confirmation(text)


def test_reason_must_come_from_user_text():
    texts = ["Passe-les en OK_EXCEPTION, motif : dérogation validée le 12/09."]
    assert appears_in("Dérogation validée le 12/09", texts)
    assert not appears_in("Validé par le comité", texts)
    assert not appears_in("ok", texts)


def test_history_repair_and_window():
    ai = AIMessage(
        content="",
        tool_calls=[
            {"name": "start_execution", "args": {}, "id": "c1", "type": "tool_call"}
        ],
    )
    messages = [
        HumanMessage(content="m1", id="h1"),
        ai,
        HumanMessage(content="m2", id="h2"),
        AIMessage(content="r2"),
        ToolMessage(content="orpheline", tool_call_id="zzz"),
    ]
    statuses = {
        "c1": {"status": "cancelled", "result_summary_json": None, "error": None}
    }
    repaired = prepare_history(messages, 20, statuses)
    assert isinstance(repaired[2], ToolMessage) and repaired[2].tool_call_id == "c1"
    assert "annulée" in repaired[2].content
    assert all(getattr(m, "tool_call_id", None) != "zzz" for m in repaired)
    window = prepare_history(messages, 2, statuses)
    assert isinstance(window[0], HumanMessage) and window[0].content == "m2"


def test_execution_survives_cancellation_of_the_stream():
    done: list[str] = []

    async def action():
        await asyncio.sleep(0.05)
        done.append("enregistré")
        return "ok"

    async def scenario():
        registry: dict = {}

        async def execute_node():
            return await _shielded(action(), registry, "conv")

        streaming = asyncio.create_task(execute_node())
        await asyncio.sleep(0.01)
        streaming.cancel()  # le navigateur se déconnecte
        with pytest.raises(asyncio.CancelledError):
            await streaming
        await asyncio.sleep(0.1)

    asyncio.run(scenario())
    assert done == ["enregistré"]


def test_page_context_whitelist():
    """Écrit à partir de PAGES : reste valable une fois PAGES aligné sur app.routes.ts."""
    assert PAGES["execution"] in APP_ROUTES
    PageContext(
        route=PAGES["control"], params=page_params("control", "section_setting")
    )
    for bad in (
        {"route": "/page-inconnue-du-kit", "params": {}},
        {"route": PAGES["control"], "params": {}},
        {"route": PAGES["controls"], "params": page_params("control", "x")},
        {"route": PAGES["control"], "params": page_params("control", "a/b")},
    ):
        with pytest.raises(ValueError):
            PageContext(**bad)


def test_pages_table_drives_links_and_is_checked(monkeypatch):
    assert page_of(PAGES["execution"]) == "execution" and page_of("/inconnue") is None
    url = page_url("execution", "01J RUN/1")
    assert url is not None and url.endswith("01J%20RUN%2F1") and ":" not in url
    assert page_url("executions") == PAGES["executions"]
    assert page_url("page_absente") is None  # page retirée de PAGES : pas de lien
    with pytest.raises(ValueError):
        page_url("execution")  # identifiant requis
    for broken in (
        {**PAGES, "execution": "/executions"},  # paramètre de route perdu
        {**PAGES, "controls": "/controls/:x"},  # paramètre en trop
        {**PAGES, "analytics": PAGES["executions"]},  # deux pages, un chemin
        {**PAGES, "home": "accueil"},  # chemin relatif
    ):
        monkeypatch.setattr(domain, "PAGES", broken)
        with pytest.raises(ValueError):
            domain._checked_routes()


def test_user_mapper_and_roles():
    user = default_user_mapper(
        {"sub": "s", "email": "e", "roles": ["USER_MANAGER", "AUTRE"]}
    )
    assert (
        user.can(Role.USER) and user.can(Role.USER_MANAGER) and not user.can(Role.ADMIN)
    )
    with pytest.raises(ValueError):
        default_user_mapper({"email": "sans-sub"})


def test_model_configuration_errors():
    with pytest.raises(ModelConfigError):
        build_chat_model("sans-fournisseur", _settings())
    with pytest.raises(ModelConfigError):
        build_chat_model("inconnu:modele", _settings())

    async def scenario():
        with pytest.raises(ModelConfigError):
            await ModelProvider(_settings()).invoke(
                [HumanMessage(content="x")], tools=None
            )

    asyncio.run(scenario())


def test_openai_provider_counts_streamed_tokens_behind_a_gateway():
    """LangChain coupe le comptage des jetons en diffusion dès qu'une URL de passerelle est
    donnée : sans `stream_usage`, chaque tour enregistrerait 0 jeton."""
    gateway = {"openai_base_url": "http://passerelle.test/v1", "openai_api_key": "x"}
    model = build_chat_model("openai:modele-test", _settings(**gateway))
    assert model.stream_usage is True
    off = build_chat_model(
        "openai:modele-test", _settings(stream_usage=False, **gateway)
    )
    assert off.stream_usage is False


@pytest.mark.parametrize(
    ("choice", "expected"), [("chat", False), ("responses", True), ("auto", None)]
)
def test_openai_api_is_explicit_when_configured(choice, expected):
    """HERMES_AGENT_OPENAI_API fixe l'API appelée ; « auto » laisse langchain-openai choisir
    (il envoie certains modèles, GPT 5.6 Sol compris selon sa version, vers /responses)."""
    settings = _settings(
        openai_api=choice,
        openai_base_url="http://passerelle.test/v1",
        openai_api_key="x",
    )
    assert settings.use_responses_api is expected
    model = build_chat_model("openai:gpt-5.6-sol", settings)
    if expected is not None:
        assert model.use_responses_api is expected
    with pytest.raises(ValueError):
        _settings(openai_api="graphql")


def test_settings_parsing():
    s = _settings(
        rate_limit="10/1h", enabled_tools="a, b", forward_headers="x-csrf-token,origin"
    )
    assert (s.rate_limit_count, s.rate_limit_window_s) == (10, 3600)
    assert s.enabled_tools == ["a", "b"]
    with pytest.raises(ValueError):
        _settings(rate_limit="beaucoup")
    with pytest.raises(ValueError):
        _settings(phase=4)
