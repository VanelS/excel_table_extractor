"""Robustesse : déconnexions, verrou de tour, délais, appels illisibles, données personnelles.

Chaque test reproduit un défaut trouvé en revue indépendante, avant correction.
"""

from __future__ import annotations

import asyncio
import json
import sys
import threading
import types
from datetime import timedelta

import duckdb
import pytest
from langchain_core.messages import AIMessage, ToolMessage

from app.services.agent.domain import PAGES, PageContext, UserContext, page_params
from app.services.agent.gateway import InvalidIdentifier, RequestMeta, render_path
from app.services.agent.llm import load_integration
from app.services.agent.service import DecisionIn
from app.services.agent.store import RateLimitExceeded, iso, utcnow
from app.services.agent.wiring import housekeeping_once
from app.services.run_query import RunData, build_run_query_router

from .fake_hermes import CSRF, ORIGIN, _row, current_user
from .scripted_model import Pause, call, say

START = {
    "control_id": "section_setting",
    "sources": [{"name": "sections", "file": "s.xlsx"}],
}
MANAGER = UserContext(
    sub="u-manager", email="manager@banque.test", roles=frozenset({"USER_MANAGER"})
)
META = RequestMeta(
    cookies={"hermes_session": "tok-manager", "hermes_csrf": CSRF},
    headers={"x-csrf-token": CSRF, "origin": ORIGIN},
)


def _started(env) -> list:
    return [b for b in env.fake.bodies if b[0] == "start_execution"]


def _tool_messages(messages) -> list[ToolMessage]:
    return [m for m in messages if isinstance(m, ToolMessage)]


async def _propose(env):
    client = env.client("tok-manager")
    conv = await client.conversation()
    card = (await client.send(conv, "Lance section_setting")).card
    return client, conv, card


# -- action confirmée et connexion -----------------------------------------------------------
def test_confirmed_action_runs_even_if_the_stream_is_never_read(harness):
    harness.model.script(call("start_execution", START), say("Run lancé."))

    async def scenario(env):
        _, conv, card = await _propose(env)
        decision = DecisionIn(decision="confirm", payload_hash=card["payload_hash"])
        turn = await env.service.prepare_decision(
            MANAGER, conv, card["action_id"], decision, META
        )
        await turn.task  # personne ne lit le flux : le tour va quand même au bout
        assert env.action(card["action_id"])["status"] == "executed"
        assert len(_started(env)) == 1
        assert not env.service.store.turn_in_progress(conv)

    harness.run(scenario)


def test_disconnect_after_first_event_does_not_stop_the_action(harness):
    harness.model.script(call("start_execution", START), say("Run lancé."))

    async def scenario(env):
        _, conv, card = await _propose(env)
        decision = DecisionIn(decision="confirm", payload_hash=card["payload_hash"])
        turn = await env.service.prepare_decision(
            MANAGER, conv, card["action_id"], decision, META
        )
        stream = turn.events()
        first = await stream.__anext__()
        assert json.loads(first["data"])["status"] == "confirmed"
        await stream.aclose()  # le navigateur se déconnecte
        await turn.task
        assert env.action(card["action_id"])["status"] == "executed"
        assert not env.service.store.turn_in_progress(conv)

    harness.run(scenario)


def test_confirmed_action_fails_cleanly_if_the_turn_stops_before_execution(harness):
    harness.model.script(call("start_execution", START))

    async def scenario(env):
        client, conv, card = await _propose(env)

        async def broken(turn):
            raise RuntimeError("database is locked")
            yield  # pragma: no cover

        env.service.run_graph = broken
        result = await client.decide(conv, card)
        assert result.statuses(card["action_id"]) == ["confirmed", "failed"]
        action = env.action(card["action_id"])
        assert action["status"] == "failed" and action["error"].startswith(
            "non exécutée"
        )
        assert not _started(env)
        assert not env.service.store.turn_in_progress(conv)

    harness.run(scenario)


def test_housekeeping_fails_confirmations_that_never_started(harness):
    harness.model.script(call("start_execution", START))

    async def scenario(env):
        _, _, card = await _propose(env)
        old = iso(utcnow() - timedelta(hours=1))
        env.sql(
            "UPDATE agent_tool_calls SET status = 'confirmed', decided_at = :d WHERE id = :id",
            d=old,
            id=card["action_id"],
        )
        await housekeeping_once(env.service)
        action = env.action(card["action_id"])
        assert action["status"] == "failed" and action["error"] == "non exécutée"

    harness.run(scenario)


# -- verrou de tour -----------------------------------------------------------------------
def test_lock_belongs_to_the_turn_that_took_it(harness):
    async def scenario(env):
        conv = await env.client("tok-user").conversation()
        store = env.service.store
        assert store.acquire_turn_lock(conv, 60, "lock_a")
        assert not store.acquire_turn_lock(conv, 60, "lock_b")
        assert not store.renew_turn_lock(conv, 60, "lock_b")
        store.release_turn_lock(conv, "lock_b")  # sans effet : pas son verrou
        assert store.turn_in_progress(conv)
        store.release_turn_lock(conv, "lock_a")
        assert not store.turn_in_progress(conv)
        detail = (
            await env.client("tok-user").get(f"/api/agent/conversations/{conv}")
        ).json()
        assert "turn_lock_owner" not in detail["conversation"]

    harness.run(scenario)


def test_lock_is_renewed_while_a_slow_turn_runs(harness):
    harness.model.script(Pause(3.5, say("Enfin.")), say("Suivant."))

    async def scenario(env):
        client = env.client("tok-user")
        conv = await client.conversation()
        first = asyncio.create_task(client.send(conv, "Question longue"))
        await asyncio.sleep(2.6)  # au-delà de la durée initiale du verrou (2 s)
        assert (await client.send(conv, "Je m'impatiente")).status == 409
        assert (await first).text == "Enfin."
        assert (await client.send(conv, "Et maintenant ?")).text == "Suivant."

    harness.run(scenario, turn_lock_s=2)


def test_turn_timeout_ends_the_turn_and_frees_the_conversation(harness):
    harness.model.script(Pause(2.0, say("Trop tard.")), say("Rebonjour."))

    async def scenario(env):
        client = env.client("tok-user")
        conv = await client.conversation()
        turn = await client.send(conv, "Bonjour")
        assert turn.first("error")["code"] == "TurnTimeout"
        assert (await client.send(conv, "Bonjour ?")).text == "Rebonjour."

    harness.run(scenario, turn_timeout_s=0.5)


# -- délais ------------------------------------------------------------------------------------
def test_slow_model_call_falls_back(harness):
    harness.model.script(Pause(1.0, say("lent")), Pause(1.0, say("lent")))
    harness.fallback.script(say("Réponse de secours."))

    async def scenario(env):
        client = env.client("tok-user")
        turn = await client.send(await client.conversation(), "Bonjour")
        assert turn.text == "Réponse de secours."

    harness.run(scenario, fallback_model="scripted:fallback", model_total_timeout_s=0.3)


def test_gateway_timeout_on_a_write_reports_an_unknown_state(harness):
    harness.model.script(call("start_execution", START), say("État à vérifier."))
    harness.fake.delays["start_execution"] = 2.0

    async def scenario(env):
        client, conv, card = await _propose(env)
        result = await client.decide(conv, card)
        assert result.statuses(card["action_id"])[-1] == "failed"
        action = env.action(card["action_id"])
        assert action["error"].startswith("état inconnu")
        assert (
            "état réel de l'action est inconnu"
            in _tool_messages(env.model.received[-1])[-1].content
        )

    harness.run(scenario, gateway_timeout_s=0.3)


def test_gateway_timeout_on_a_read_is_a_tool_error(harness):
    harness.model.script(
        call("get_execution", {"run_id": "01JRUN0011"}), say("Indisponible.")
    )
    harness.fake.delays["get_execution"] = 2.0

    async def scenario(env):
        client = env.client("tok-user")
        await client.send(await client.conversation(), "Où en est le run ?")
        result = _tool_messages(env.model.received[1])[0]
        assert result.status == "error" and "délai" in result.content

    harness.run(scenario, gateway_timeout_s=0.3)


# -- appels d'outils illisibles -------------------------------------------------------------
def test_malformed_tool_call_gets_an_error_reply_and_history_stays_valid(harness):
    bad = AIMessage(
        content="",
        invalid_tool_calls=[
            {
                "name": "get_execution",
                "args": '{"run_id": 01JRUN0011}',
                "id": "call_bad1",
                "error": "JSON invalide",
                "type": "invalid_tool_call",
            }
        ],
    )
    harness.model.script(bad, say("Je reformule."), say("Deuxième tour."))

    async def scenario(env):
        client = env.client("tok-user")
        conv = await client.conversation()
        await client.send(conv, "Où en est le run 01JRUN0011 ?")
        reply = _tool_messages(env.model.received[1])
        assert [m.tool_call_id for m in reply] == ["call_bad1"]
        assert "Arguments illisibles" in reply[0].content
        assert (await client.send(conv, "Et ensuite ?")).text == "Deuxième tour."
        history = env.model.received[2]
        answered = {m.tool_call_id for m in history if isinstance(m, ToolMessage)}
        for message in history:
            if isinstance(message, AIMessage):
                assert not message.invalid_tool_calls
                assert {c["id"] for c in message.tool_calls} <= answered

    harness.run(scenario)


# -- données personnelles ---------------------------------------------------------------------
def test_personal_data_never_reaches_the_model(harness):
    harness.fake.rows["01JRUN0011"].append(
        _row(
            "SEC_5000_TEST",
            "ctrl_service_ok",
            "KO",
            {
                "Email": "jean.dupont@bpce.fr",
                "mail_manager": "chef@banque.fr",
                "commentaire": "voir avec paul.martin@banque.fr",
            },
        )
    )
    harness.fake.dispositions[0]["reason"] = "Validé par jean.dupont@bpce.fr en comité"
    harness.model.script(
        call("query_anomalies", {"run_id": "01JRUN0011", "search": "SEC_5000"}),
        call("list_dispositions", {"control_id": "section_setting"}),
        say("Fait."),
    )

    async def scenario(env):
        client = env.client("tok-user")
        await client.send(await client.conversation(), "Montre la ligne SEC_5000")
        sent = " ".join(m.content for m in _tool_messages(env.model.received[-1]))
        assert "@" not in sent
        assert "mail_manager" not in sent and '"Email"' not in sent
        assert (
            "[adresse masquée]" in sent
        )  # le texte libre reste, l'adresse est masquée

    harness.run(scenario)


# -- validations ---------------------------------------------------------------------------
def test_duplicate_source_names_are_refused(harness):
    harness.model.script(
        call(
            "start_execution",
            {
                "control_id": "section_setting",
                "sources": [
                    {"name": "sections", "file": "nouveau.xlsx"},
                    {"name": "sections", "file": "ancien.xlsx"},
                ],
            },
        ),
        say("Précisez la source."),
    )

    async def scenario(env):
        client = env.client("tok-manager")
        turn = await client.send(
            await client.conversation(), "Lance avec les deux fichiers"
        )
        assert "action.proposed" not in turn.names
        refusal = _tool_messages(env.model.received[-1])[-1]
        assert "plusieurs fois" in refusal.content

    harness.run(scenario)


def test_identifiers_with_a_trailing_newline_are_refused():
    with pytest.raises(InvalidIdentifier):
        render_path("/api/executions/{run_id}", {"run_id": "01JRUN0011\n"})
    with pytest.raises(ValueError):
        PageContext(
            route=PAGES["execution"], params=page_params("execution", "01JRUN0011\n")
        )


# -- événements de fin de run et débit ----------------------------------------------------------
def test_run_events_only_for_runs_started_in_the_conversation(harness):
    harness.model.script(
        call("start_execution", START),
        say("Lancé."),
        say("Le run est terminé : 0 KO."),
    )

    async def scenario(env):
        client, conv, card = await _propose(env)
        run_id = (await client.decide(conv, card)).of("action.updated")[-1]["result"][
            "run_id"
        ]
        unknown = await client.send(
            conv, event={"type": "run_completed", "run_id": "01JRUN0011"}
        )
        assert unknown.names == [
            "done"
        ]  # run d'une autre origine : ignoré, sans appel au modèle
        summary = await client.send(
            conv, event={"type": "run_completed", "run_id": run_id}
        )
        assert summary.text == "Le run est terminé : 0 KO."
        again = await client.send(
            conv, event={"type": "run_completed", "run_id": run_id}
        )
        assert again.names == ["done"]  # déjà résumé
        assert len(env.model.received) == 3

    harness.run(scenario)


def test_rate_limit_holds_under_parallel_requests(harness):
    async def scenario(env):
        store = env.service.store
        conversations = [await env.client("tok-user").conversation() for _ in range(5)]
        since = utcnow() - timedelta(minutes=5)
        accepted, refused = [], []

        def send(conv: str) -> None:
            try:
                store.add_message(conv, "u-user", "user", "x", rate_limit=(3, since))
                accepted.append(conv)
            except RateLimitExceeded:
                refused.append(conv)

        threads = [threading.Thread(target=send, args=(c,)) for c in conversations * 2]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        assert len(accepted) == 3 and len(refused) == 7

    harness.run(scenario)


# -- endpoint SQL ------------------------------------------------------------------------------
def _parquet(path) -> str:
    duckdb.connect().execute(
        f"COPY (SELECT 'K' || range AS identity_key, 'r' AS control_rule FROM range(5)) TO '{path}' (FORMAT parquet)"
    )
    return str(path)


@pytest.mark.parametrize(
    "enabled_tools, expected", [([], 404), (["analyze_run_data"], 200)]
)
def test_sql_endpoint_follows_the_agent_settings(
    harness, tmp_path, enabled_tools, expected
):
    parquet = _parquet(tmp_path / "run.parquet")

    async def scenario(env):
        env.app.include_router(
            build_run_query_router(
                current_user=current_user,
                resolve_run=lambda run_id, user: RunData(parquet_path=parquet),
                generate_sql=lambda question, tables: (
                    "SELECT count(*) AS n FROM run_rows"
                ),
            )
        )
        response = await env.client("tok-user").http.post(
            "/api/executions/01JRUN0011/query", json={"question": "Combien de lignes ?"}
        )
        assert response.status_code == expected
        if expected == 200:
            assert response.json()["rows"] == [{"n": 5}]

    harness.run(scenario, enabled_tools=enabled_tools)


def test_integration_module_is_optional(monkeypatch):
    """Sans integration.py, rien n'est enregistré ; avec `register_bank_models`, elle est
    appelée. Indépendant du module réel : valable avant comme après l'étape 9."""
    name = "app.services.agent.integration"
    monkeypatch.setitem(sys.modules, name, None)  # import impossible : module absent
    assert load_integration() is False
    calls: list[str] = []
    with_models = types.ModuleType(name)
    with_models.register_bank_models = lambda: calls.append("banque")
    monkeypatch.setitem(sys.modules, name, with_models)
    assert load_integration() is True and calls == ["banque"]
    monkeypatch.setitem(sys.modules, name, types.ModuleType(name))  # sans la fonction
    assert load_integration() is False
