"""Modèle simulé : rejoue des réponses écrites d'avance, sans appel réseau.

Chaque étape du script est :
- un `AIMessage` (texte et/ou appels d'outils, y compris `invalid_tool_calls`, diffusés tels
  quels : un JSON d'arguments illisible arrive comme d'un vrai fournisseur) ;
- une fonction `messages -> AIMessage`, pour vérifier ce que le modèle reçoit ;
- une exception, pour simuler une panne du fournisseur ;
- `Pause(secondes, étape)`, pour simuler un modèle lent.

Les réponses sont diffusées en fragments, comme un vrai modèle : le panneau reçoit des
`message.delta` et `ModelProvider` reconstitue le message complet.
"""

from __future__ import annotations

import asyncio
import json
import uuid
from collections.abc import AsyncIterator, Callable, Iterator
from dataclasses import dataclass
from typing import Any

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage, AIMessageChunk, BaseMessage
from langchain_core.outputs import ChatGeneration, ChatGenerationChunk, ChatResult
from pydantic import Field

from app.services.agent.llm import message_text


@dataclass
class Pause:
    seconds: float
    then: Any


Step = AIMessage | Callable[[list[BaseMessage]], AIMessage] | Exception | Pause


def say(text: str) -> AIMessage:
    return AIMessage(content=text)


def say_blocks(text: str) -> AIMessage:
    """Réponse en liste de blocs, comme l'API Responses d'OpenAI la rend dans LangChain."""
    return AIMessage(
        content=[{"type": "text", "text": text, "index": 0, "id": "msg_test"}]
    )


def call(
    name: str,
    args: dict[str, Any] | None = None,
    *,
    text: str = "",
    call_id: str | None = None,
) -> AIMessage:
    return calls([(name, args or {})], text=text, ids=[call_id] if call_id else None)


def calls(
    items: list[tuple[str, dict[str, Any]]],
    *,
    text: str = "",
    ids: list[str] | None = None,
) -> AIMessage:
    ids = ids or [f"call_{uuid.uuid4().hex[:12]}" for _ in items]
    return AIMessage(
        content=text,
        tool_calls=[
            {"name": name, "args": args, "id": cid, "type": "tool_call"}
            for (name, args), cid in zip(items, ids, strict=True)
        ],
    )


class ScriptedChatModel(BaseChatModel):
    steps: list[Any] = Field(default_factory=list)
    received: list[list[BaseMessage]] = Field(default_factory=list)
    bound_tools: list[Any] = Field(default_factory=list)

    @property
    def _llm_type(self) -> str:
        return "scripted"

    def script(self, *steps: Step) -> ScriptedChatModel:
        self.steps.extend(steps)
        return self

    def bind_tools(self, tools: Any, **kwargs: Any) -> ScriptedChatModel:  # type: ignore[override]
        self.bound_tools.append(tools)
        return self

    def tool_names(self, index: int = -1) -> set[str]:
        return {t["function"]["name"] for t in self.bound_tools[index]}

    def _take(self, messages: list[BaseMessage]) -> Any:
        self.received.append(list(messages))
        if not self.steps:
            raise AssertionError("script du modèle épuisé : appel inattendu")
        return self.steps.pop(0)

    @staticmethod
    def _resolve(step: Any, messages: list[BaseMessage]) -> AIMessage:
        if isinstance(step, Exception):
            raise step
        if callable(step):
            step = step(messages)
        return step

    def _next(self, messages: list[BaseMessage]) -> AIMessage:
        step = self._take(messages)
        if isinstance(step, Pause):
            step = step.then
        return self._resolve(step, messages)

    def _generate(
        self,
        messages: list[BaseMessage],
        stop: Any = None,
        run_manager: Any = None,
        **kwargs: Any,
    ) -> ChatResult:
        return ChatResult(generations=[ChatGeneration(message=self._next(messages))])

    def _chunks(self, message: AIMessage) -> Iterator[ChatGenerationChunk]:
        blocks = isinstance(message.content, list)
        text = message_text(message)
        parts = [text[: len(text) // 2], text[len(text) // 2 :]] if text else [""]
        for i, part in enumerate(parts):
            last = i == len(parts) - 1
            # Blocs : chaque fragment porte son index, que LangChain fusionne (API Responses).
            content: Any = (
                [{"type": "text", "text": part, "index": 0}]
                if blocks and part
                else part
            )
            if blocks and not part:
                content = []
            yield ChatGenerationChunk(
                message=AIMessageChunk(
                    content=content,
                    tool_call_chunks=[
                        {
                            "name": tc["name"],
                            "args": json.dumps(tc["args"]),
                            "id": tc["id"],
                            "index": j,
                            "type": "tool_call_chunk",
                        }
                        for j, tc in enumerate(message.tool_calls)
                    ]
                    + [
                        {
                            "name": bad.get("name"),
                            "args": bad.get("args"),  # texte brut, JSON illisible
                            "id": bad.get("id"),
                            "index": len(message.tool_calls) + j,
                            "type": "tool_call_chunk",
                        }
                        for j, bad in enumerate(message.invalid_tool_calls)
                    ]
                    if last
                    else [],
                    usage_metadata={
                        "input_tokens": 12,
                        "output_tokens": 7,
                        "total_tokens": 19,
                    }
                    if last
                    else None,
                )
            )

    async def _astream(
        self,
        messages: list[BaseMessage],
        stop: Any = None,
        run_manager: Any = None,
        **kwargs: Any,
    ) -> AsyncIterator[ChatGenerationChunk]:
        step = self._take(messages)
        if isinstance(step, Pause):
            await asyncio.sleep(step.seconds)
            step = step.then
        for chunk in self._chunks(self._resolve(step, messages)):
            yield chunk
