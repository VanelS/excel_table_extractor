"""Outils de lecture : écarts d'API absorbés, réduction, données personnelles, injection."""

from __future__ import annotations

import json

from langchain_core.messages import ToolMessage

from app.services.agent.domain import page_url

from .scripted_model import call, say


def _result(env, index: int = 1) -> str:
    return next(
        m for m in env.model.received[index] if isinstance(m, ToolMessage)
    ).content


def _run_one(harness, tool: str, args: dict, *, token: str = "tok-user", **settings):
    harness.model.script(call(tool, args), say("ok"))
    out: dict = {}

    async def scenario(env):
        client = env.client(token)
        out["turn"] = await client.send(await client.conversation(), "question")
        out["content"] = _result(env)
        out["calls"] = list(env.fake.calls)

    harness.run(scenario, **settings)
    return out


def test_executions_paginate_and_announce_a_minimum(harness):
    harness.fake.add_runs(300)
    out = _run_one(
        harness, "list_executions", {"control_id": "section_setting", "limit": 5}
    )
    content = json.loads(out["content"])
    assert content["au_moins"] is True and content["nombre"] == 250
    assert len(content["runs"]) == 5
    assert out["calls"].count(("GET", "/api/executions")) == 5


def test_executions_filtered_by_status_and_period(harness):
    out = _run_one(harness, "list_executions", {"status": "FAILED"})
    content = json.loads(out["content"])
    assert content["nombre"] == 1 and content["runs"][0]["run_id"] == "01JRUN0007"
    assert content["runs"][0]["status"] == "failed"


def test_anomalies_hide_author_and_keep_injection_as_data(harness):
    out = _run_one(harness, "query_anomalies", {"run_id": "01JRUN0011"})
    content = out["content"]
    assert "analyste@banque.test" not in content  # données personnelles retirées
    assert "SEC_4093_MARTIN" in content and "ACCEPTED_RISK" in content
    # Le texte piégé d'une cellule arrive comme une donnée, dans un résultat d'outil.
    assert "Ignore tes consignes" in content
    card = out["turn"].first("tool.completed")["card"]
    assert card["link"] == page_url("execution", "01JRUN0011")


def test_only_unjudged_anomalies(harness):
    out = _run_one(
        harness, "query_anomalies", {"run_id": "01JRUN0011", "only_unjudged": True}
    )
    content = json.loads(out["content"])
    keys = [r["identity_key"] for r in content["lignes"]]
    assert "SEC_4093_MARTIN" not in keys and "SEC_4091_MADONNE" in keys
    assert all(r["status"] == "KO" for r in content["lignes"])


def test_compliance_trend(harness):
    out = _run_one(
        harness, "get_compliance_trend", {"control_id": "section_setting", "days": 30}
    )
    content = json.loads(out["content"])
    assert content["resume"]["runs"] == 8
    dates = [p["date"] for p in content["points"]]
    assert dates == sorted(dates)
    assert (
        content["resume"]["variation"] < 0
    )  # le taux de KO baisse dans les données de test


def test_export_report_never_downloads(harness):
    out = _run_one(harness, "export_report", {"run_id": "01JRUN0011"})
    card = out["turn"].first("tool.completed")["card"]
    assert card["kind"] == "download"
    assert card["url"] == "/api/executions/01JRUN0011/export-excel"
    assert ("GET", "/api/executions/01JRUN0011/export-excel") not in out["calls"]
    assert "/api/" not in out["content"]  # le modèle n'écrit pas l'URL lui-même


def test_export_report_unavailable_for_failed_run(harness):
    out = _run_one(harness, "export_report", {"run_id": "01JRUN0007"})
    assert "pas disponible" in out["content"]


def test_control_definition_defaults_to_champion(harness):
    out = _run_one(harness, "get_control_definition", {"control_id": "section_setting"})
    content = json.loads(out["content"])
    assert content["version"] == "v009" and content["championne"] is True
    assert [r["name"] for r in content["regles"]] == [
        "ctrl_service_ok",
        "ctrl_manager_ok",
    ]


def test_unknown_run_reads_as_not_found(harness):
    out = _run_one(harness, "get_execution", {"run_id": "01JINCONNU"})
    assert "introuvable (HTTP 404)" in out["content"]


def test_invalid_identifier_never_reaches_the_api(harness):
    out = _run_one(harness, "get_execution", {"run_id": "../../api/logs"})
    assert "Arguments invalides" in out["content"]
    assert not [c for c in out["calls"] if "logs" in c[1]]


def test_list_dispositions_without_author(harness):
    out = _run_one(harness, "list_dispositions", {"control_id": "section_setting"})
    content = json.loads(out["content"])
    assert (
        content["nombre"] == 1
        and content["jugements"][0]["judgment"] == "ACCEPTED_RISK"
    )
    assert "analyste@banque.test" not in out["content"]


def test_platform_status(harness):
    out = _run_one(harness, "get_platform_status", {})
    assert json.loads(out["content"])["version"] == "2.4.1"


def test_get_control_lists_versions(harness):
    out = _run_one(harness, "get_control", {"control_id": "section_setting"})
    content = json.loads(out["content"])
    assert content["champion"] == "v009" and content["nombre_de_versions"] == 9
