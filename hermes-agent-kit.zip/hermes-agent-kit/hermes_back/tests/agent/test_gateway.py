"""Passerelle API interne : liste blanche, identifiants, retransmission, marque « via Hermes »."""

from __future__ import annotations

import asyncio
from types import SimpleNamespace

import pytest

from app.services.agent.context import AgentCallContext, agent_call_scope
from app.services.agent.gateway import (
    ApiGateway,
    InvalidIdentifier,
    RequestMeta,
    ResponseTooLarge,
    RouteNotAllowed,
    render_path,
)

from .fake_hermes import CSRF, ORIGIN, FakeState, create_fake_app

META = RequestMeta(
    cookies={"hermes_session": "tok-manager", "hermes_csrf": CSRF},
    headers={"x-csrf-token": CSRF, "origin": ORIGIN},
)


def _gateway(app, allowed, meta=META, **kwargs):
    return ApiGateway(app, allowed=allowed, meta=meta, **kwargs)


def test_render_path_validates_and_encodes():
    assert (
        render_path("/api/executions/{run_id}", {"run_id": "01JA-2_k"})
        == "/api/executions/01JA-2_k"
    )
    for bad in ("../health", "a/b", "a b", "%2e%2e", "", "x" * 129, "é"):
        with pytest.raises(InvalidIdentifier):
            render_path("/api/executions/{run_id}", {"run_id": bad})
    with pytest.raises(InvalidIdentifier):
        render_path("/api/executions/{run_id}", {})
    with pytest.raises(InvalidIdentifier):
        render_path("/api/executions/{run_id}", {"run_id": "a", "other": "b"})


def test_only_declared_routes_pass():
    app = create_fake_app(FakeState.seed())
    gateway = _gateway(app, {("GET", "/api/controls/{control_id}")})

    async def scenario():
        ok = await gateway.call(
            "GET",
            "/api/controls/{control_id}",
            path_params={"control_id": "section_setting"},
        )
        assert ok.ok and ok.data["champion"] == "v009"
        with pytest.raises(RouteNotAllowed):
            await gateway.call(
                "DELETE",
                "/api/controls/{control_id}/versions/{version}",
                path_params={"control_id": "section_setting", "version": "v001"},
            )
        with pytest.raises(RouteNotAllowed):
            await gateway.call("GET", "/api/logs")

    asyncio.run(scenario())
    assert not [b for b in app.state.fake.bodies if b[0] == "delete_version"]


def test_session_and_csrf_are_forwarded():
    app = create_fake_app(FakeState.seed())
    route = ("POST", "/api/executions/{run_id}/rerun")

    async def scenario():
        ok = await _gateway(app, {route}).call(
            *route, path_params={"run_id": "01JRUN0011"}, json_body={}
        )
        assert ok.status == 202
        no_csrf = RequestMeta(cookies=META.cookies, headers={"origin": ORIGIN})
        refused = await _gateway(app, {route}, meta=no_csrf).call(
            *route, path_params={"run_id": "01JRUN0011"}, json_body={}
        )
        assert refused.status == 403
        user = RequestMeta(
            cookies={**META.cookies, "hermes_session": "tok-user"}, headers=META.headers
        )
        forbidden = await _gateway(app, {route}, meta=user).call(
            *route, path_params={"run_id": "01JRUN0011"}, json_body={}
        )
        assert (
            forbidden.status == 403
        )  # la route vérifie le rôle, comme pour l'interface

    asyncio.run(scenario())


def test_activity_mark_crosses_into_sync_routes():
    app = create_fake_app(FakeState.seed())
    gateway = _gateway(app, {("GET", "/api/health")})

    async def scenario():
        await gateway.call("GET", "/api/health")  # hors agent : pas de marque
        with agent_call_scope(
            AgentCallContext("conv_1", "tc_1", "get_platform_status", "u-manager")
        ):
            await gateway.call("GET", "/api/health")

    asyncio.run(scenario())
    outside, inside = app.state.fake.health_annotations
    assert outside == {}
    assert inside["via"] == "hermes" and inside["agent_tool_call_id"] == "tc_1"


def test_large_responses_are_refused():
    app = create_fake_app(FakeState.seed())
    gateway = _gateway(app, {("GET", "/api/controls")}, max_bytes=50)

    async def scenario():
        with pytest.raises(ResponseTooLarge):
            await gateway.call("GET", "/api/controls")

    asyncio.run(scenario())


def test_request_meta_keeps_only_listed_headers():
    request = SimpleNamespace(
        headers={
            "X-CSRF-Token": "t",
            "Origin": ORIGIN,
            "Authorization": "Bearer x",
            "Cookie": "a=b",
        },
        cookies={"hermes_session": "s"},
    )
    meta = RequestMeta.from_request(request, ["x-csrf-token", "origin"])
    assert meta.headers == {"X-CSRF-Token": "t", "Origin": ORIGIN}
    assert meta.cookies == {"hermes_session": "s"}
