"""Actions d'écriture : carte, confirmation, refus, annulation, expiration, idempotence."""

from __future__ import annotations

from langchain_core.messages import AIMessage, ToolMessage

from .scripted_model import call, calls, say

START = {
    "control_id": "section_setting",
    "sources": [{"name": "sections", "file": "sections_2026-09.xlsx"}],
    "control_date": "2026-09-30",
}


def _last_tool_message(messages) -> ToolMessage:
    return [m for m in messages if isinstance(m, ToolMessage)][-1]


def _started(env) -> list:
    return [b for b in env.fake.bodies if b[0] == "start_execution"]


def test_start_execution_card_then_confirm(harness):
    harness.model.script(call("start_execution", START), say("Le run est lancé."))

    async def scenario(env):
        client = env.client("tok-manager")
        conv = await client.conversation()
        turn = await client.send(conv, "Lance section_setting pour septembre")
        card = turn.card
        assert turn.first("done") == {"interrupted": True}
        assert card["tool"] == "start_execution" and card["level"] == "simple"
        assert card["title"] == "Lancer section_setting"
        fields = {f["label"]: f["value"] for f in card["fields"]}
        assert fields["Version"] == "v009 (championne)"
        assert fields["Date de contrôle"] == "30/09/2026"
        assert fields["Sources"] == "sections : sections_2026-09.xlsx"
        assert not _started(env)  # rien n'est lancé avant la décision
        proposed = env.action(card["action_id"])
        assert proposed["status"] == "proposed"
        assert (proposed["input_tokens"], proposed["output_tokens"]) == (12, 7)
        assert proposed["model_name"] == "scripted:main"
        listed = (await client.get("/api/agent/conversations")).json()
        assert listed[0]["title"] == "Lance section_setting pour septembre"

        # La conversation rouverte montre la carte en attente.
        detail = (await client.get(f"/api/agent/conversations/{conv}")).json()
        assert detail["pending_action"]["action_id"] == card["action_id"]

        result = await client.decide(conv, card)
        assert result.statuses(card["action_id"]) == [
            "confirmed",
            "executing",
            "executed",
        ]
        assert result.text == "Le run est lancé."
        executed = result.of("action.updated")[-1]
        assert executed["card"]["kind"] == "run"
        run_id = executed["result"]["run_id"]

        # Exécuté une fois, avec la version affichée sur la carte.
        assert _started(env) == [
            (
                "start_execution",
                {
                    "sources": {"sections": "sections_2026-09.xlsx"},
                    "control_date": "2026-09-30",
                    "control_version": "v009",
                },
            )
        ]
        action = env.action(card["action_id"])
        assert action["status"] == "executed" and action["http_status"] == 202
        assert run_id in action["result_summary_json"]

        # Journal d'activité : marque « via Hermes » posée par le contexte, pas par un en-tête.
        entry = [a for a in env.fake.activity if a["action"] == "START_EXECUTION"][-1]
        assert entry["description"]["via"] == "hermes"
        assert entry["description"]["agent_tool_call_id"] == card["action_id"]
        assert entry["email"] == "manager@banque.test"

        # Le modèle reçoit le résultat de l'action comme résultat d'outil.
        outcome = _last_tool_message(env.model.received[-1])
        assert outcome.content.startswith("Action exécutée")

        # Une seconde confirmation ne relance rien.
        again = await client.decide(conv, card)
        assert again.status == 409
        assert len(_started(env)) == 1

    harness.run(scenario)


def test_reject_is_returned_to_the_model(harness):
    harness.model.script(
        call("start_execution", START), say("D'accord, je ne lance rien.")
    )

    async def scenario(env):
        client = env.client("tok-manager")
        conv = await client.conversation()
        card = (await client.send(conv, "Lance section_setting")).card
        result = await client.decide(conv, card, "reject")
        assert result.statuses(card["action_id"]) == ["rejected"]
        assert (
            "refusée par l'utilisateur"
            in _last_tool_message(env.model.received[-1]).content
        )
        assert env.action(card["action_id"])["status"] == "rejected"
        assert not _started(env)

    harness.run(scenario)


def test_new_message_cancels_pending_action(harness):
    harness.model.script(
        call("start_execution", START),
        say("Voici les runs."),
    )

    async def scenario(env):
        client = env.client("tok-manager")
        conv = await client.conversation()
        card = (await client.send(conv, "Lance section_setting")).card
        turn = await client.send(conv, "Finalement, montre-moi plutôt les runs")
        assert turn.statuses(card["action_id"]) == ["cancelled"]
        assert env.action(card["action_id"])["status"] == "cancelled"
        # L'historique envoyé au modèle est réparé : l'appel annulé a sa réponse.
        history = env.model.received[-1]
        repaired = [m for m in history if isinstance(m, ToolMessage)]
        assert repaired and "annulée par une nouvelle demande" in repaired[-1].content
        ai_calls = [m for m in history if isinstance(m, AIMessage) and m.tool_calls]
        assert repaired[-1].tool_call_id == ai_calls[-1].tool_calls[0]["id"]
        # La carte annulée ne s'exécute plus.
        assert (await client.decide(conv, card)).status == 409
        assert not _started(env)

    harness.run(scenario)


def test_written_confirmation_for_simple_action(harness):
    harness.model.script(call("start_execution", START), say("C'est parti."))

    async def scenario(env):
        client = env.client("tok-manager")
        conv = await client.conversation()
        card = (await client.send(conv, "Lance section_setting")).card
        turn = await client.send(conv, "Oui !")
        assert turn.statuses(card["action_id"]) == [
            "confirmed",
            "executing",
            "executed",
        ]
        assert turn.text == "C'est parti."
        assert len(_started(env)) == 1

    harness.run(scenario)


def test_run_completed_event_keeps_pending_card(harness):
    harness.model.script(call("start_execution", START))

    async def scenario(env):
        client = env.client("tok-manager")
        conv = await client.conversation()
        card = (await client.send(conv, "Lance section_setting")).card
        turn = await client.send(
            conv, event={"type": "run_completed", "run_id": "01JRUN0011"}
        )
        assert turn.names == ["done"]
        assert env.action(card["action_id"])["status"] == "proposed"

    harness.run(scenario)


def test_expired_action_is_not_executed(harness):
    harness.model.script(call("start_execution", START), say("L'action a expiré."))

    async def scenario(env):
        client = env.client("tok-manager")
        conv = await client.conversation()
        card = (await client.send(conv, "Lance section_setting")).card
        env.sql(
            "UPDATE agent_tool_calls SET expires_at = '2000-01-01T00:00:00.000000+00:00' WHERE id = :id",
            id=card["action_id"],
        )
        result = await client.decide(conv, card)
        assert result.statuses(card["action_id"])[0] == "expired"
        assert "expirée" in _last_tool_message(env.model.received[-1]).content
        assert not _started(env)

    harness.run(scenario)


def test_tampered_payload_hash_is_refused(harness):
    harness.model.script(call("start_execution", START))

    async def scenario(env):
        client = env.client("tok-manager")
        conv = await client.conversation()
        card = (await client.send(conv, "Lance section_setting")).card
        forged = await client.decide(conv, card, payload_hash="sha256:" + "0" * 64)
        assert forged.status == 422
        not_editable = await client.decide(
            conv, card, edited={"control_version": "v001"}
        )
        assert not_editable.status == 422
        assert env.action(card["action_id"])["status"] == "proposed"

    harness.run(scenario)


def test_decision_requires_owner(harness):
    harness.model.script(call("start_execution", START))

    async def scenario(env):
        owner = env.client("tok-manager")
        conv = await owner.conversation()
        card = (await owner.send(conv, "Lance section_setting")).card
        intruder = env.client("tok-admin")
        assert (await intruder.decide(conv, card)).status == 404
        assert env.action(card["action_id"])["status"] == "proposed"

    harness.run(scenario)


def test_one_action_at_a_time(harness):
    harness.model.script(
        calls(
            [
                ("start_execution", START),
                ("rerun_execution", {"run_id": "01JRUN0011"}),
            ]
        ),
    )

    async def scenario(env):
        client = env.client("tok-manager")
        conv = await client.conversation()
        turn = await client.send(conv, "Lance section_setting et rejoue le dernier run")
        assert turn.card["tool"] == "start_execution"
        assert len(turn.of("action.proposed")) == 1
        writes = [r for r in env.tool_calls() if r["kind"] == "write"]
        assert len(writes) == 1

    harness.run(scenario)


def test_rerun_card_shows_original_version(harness):
    harness.model.script(
        call("rerun_execution", {"run_id": "01JRUN0007"}), say("Rejeu lancé.")
    )

    async def scenario(env):
        client = env.client("tok-manager")
        conv = await client.conversation()
        card = (await client.send(conv, "Rejoue le run en échec")).card
        fields = {f["label"]: f["value"] for f in card["fields"]}
        assert fields["Version d'origine"] == "v009"
        assert fields["Statut du run d'origine"] == "failed"
        result = await client.decide(conv, card)
        executed = result.of("action.updated")[-1]
        assert executed["result"]["parent_run_id"] == "01JRUN0007"
        assert ("rerun", "01JRUN0007") in env.fake.bodies

    harness.run(scenario)


def test_unknown_control_is_refused_before_the_card(harness):
    harness.model.script(
        call("start_execution", {"control_id": "inconnu"}),
        say("Ce contrôle n'existe pas."),
    )

    async def scenario(env):
        client = env.client("tok-manager")
        turn = await client.send(
            await client.conversation(), "Lance le contrôle inconnu"
        )
        assert "action.proposed" not in turn.names
        refusal = _last_tool_message(env.model.received[-1])
        assert "introuvable" in refusal.content and refusal.status == "error"

    harness.run(scenario)


def test_role_checked_again_at_execution(harness):
    """Le rôle est relu à chaque requête : la route refuse si la session a perdu le droit."""
    harness.model.script(call("start_execution", START), say("Refusé."))

    async def scenario(env):
        client = env.client("tok-manager")
        conv = await client.conversation()
        card = (await client.send(conv, "Lance section_setting")).card
        from .fake_hermes import TOKENS

        TOKENS["tok-manager"]["roles"] = ["USER"]
        try:
            result = await client.decide(conv, card)
        finally:
            TOKENS["tok-manager"]["roles"] = ["USER_MANAGER"]
        assert result.statuses(card["action_id"])[-1] == "failed"
        assert not _started(env)

    harness.run(scenario)
