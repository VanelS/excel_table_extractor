"""Script de découverte : rapport juste sur l'application factice, outils absents signalés."""

from __future__ import annotations

import importlib.util
import re
import sys
from pathlib import Path

import pytest
from fastapi import APIRouter, Depends, FastAPI
from pydantic import BaseModel

from app.services.agent.domain import APP_ROUTES

from .fake_hermes import create_fake_app

# Dans le kit : outils/ ; après intégration : hermes_back/scripts/agent/.
_HERE = Path(__file__).resolve()
_CANDIDATES = [
    _HERE.parents[2] / "scripts" / "agent" / "decouvrir_routes.py",
    _HERE.parents[3] / "outils" / "decouvrir_routes.py",
]


@pytest.fixture(scope="module")
def decouverte():
    path = next((p for p in _CANDIDATES if p.exists()), None)
    if path is None:
        pytest.skip("decouvrir_routes.py introuvable")
    spec = importlib.util.spec_from_file_location("decouvrir_routes", path)
    module = importlib.util.module_from_spec(spec)
    sys.modules["decouvrir_routes"] = module
    spec.loader.exec_module(module)
    return module


def test_report_on_the_fake_application(decouverte, tmp_path):
    # Fichier d'interface écrit à partir de PAGES (valable avant comme après l'alignement de
    # l'étape 8) : deux pages manquent, /login est en plus, un paramètre est renommé.
    omitted = list(APP_ROUTES[1:3])
    declared = [
        re.sub(r":\w+", ":param", route).strip("/")
        for route in APP_ROUTES
        if route not in omitted
    ]
    front = tmp_path / "app.routes.ts"
    front.write_text(
        "{ path: 'login' }, { path: '', children: [ "
        + ", ".join(f"{{ path: '{p}' }}" for p in declared)
        + " ] }, { path: '**' }",
        encoding="utf-8",
    )
    text, data, code = decouverte.build_report(create_fake_app(), front)
    assert code == 0 and data["suggested_disabled"] == []
    assert data["activation_candidates"] == []
    assert "Champs envoyés par l'outil inconnus du modèle : aucun" in text
    assert "champion → champion" in text  # modèle de réponse ControlSummary lu
    assert "POST /api/controls/{control_id}/executions" in text
    assert data["front"]["missing_in_front"] == omitted
    assert data["front"]["unknown_to_agent"] == ["/login"]
    renamed = {r["kit"]: r["front"] for r in data["front"]["renamed_params"]}
    with_params = [r for r in APP_ROUTES if ":" in r and r not in omitted]
    assert with_params and set(renamed) == set(with_params)
    assert all(":param" in front_path for front_path in renamed.values())
    assert "paramètre nommé autrement" in text
    assert (
        "DELETE /api/controls/{control_id}/versions/{version}"
        in data["unused_api_routes"]
    )


def require_csrf() -> None:
    return None


require_csrf.__module__ = "app.services.auth.session_manager"


def test_hint_ignores_module_paths(decouverte):
    """« require_csrf » dans un module « session_manager » n'est pas un contrôle de rôle."""
    app = FastAPI()

    @app.post(
        "/api/controls/{control_id}/executions", dependencies=[Depends(require_csrf)]
    )
    async def start(control_id: str) -> dict:
        return {}

    route = decouverte.api_routes(app)[0]
    assert route["role_check"] is False
    assert route["csrf_check"] is True


def require_admin_role() -> None:
    return None


class StartBody(BaseModel):
    sources: list[str]
    control_date: str | None = None


class StartedRun(BaseModel):
    run_id: str


def test_routes_of_included_routers_are_found(decouverte):
    """Routeurs inclus, imbriqués, avec dépendance au niveau du routeur : chemin complet,
    modèles et dépendances cumulées, que FastAPI aplatisse les routes (versions anciennes) ou
    les inclue paresseusement (versions récentes)."""
    controls = APIRouter(
        prefix="/api/controls", dependencies=[Depends(require_admin_role)]
    )

    @controls.post(
        "/{control_id}/executions", status_code=202, response_model=StartedRun
    )
    async def start(control_id: str, body: StartBody, dry: bool = False) -> StartedRun:
        return StartedRun(run_id="r")

    api = APIRouter()
    api.include_router(controls)
    app = FastAPI()
    app.include_router(api)
    routes = decouverte.api_routes(app)
    found = [r for r in routes if r["path"] == "/api/controls/{control_id}/executions"]
    assert len(found) == 1
    route = found[0]
    assert route["methods"] == ["POST"] and route["status_code"] == 202
    assert route["role_check"] is True
    assert route["query_params"] == ["dry"]
    assert route["body_model"] == "StartBody"
    assert set(route["body_fields"]) == {"sources", "control_date"}
    assert route["body_fields"]["sources"]["required"] is True
    assert route["response_model"] == "StartedRun"
    assert set(route["response_fields"]) == {"run_id"}


def test_missing_routes_are_flagged(decouverte):
    app = FastAPI()

    @app.get("/api/controls")
    async def only_route() -> list:
        return []

    _text, data, code = decouverte.build_report(app, None)
    assert code == 2
    assert "list_executions" in data["suggested_disabled"]
    assert "list_controls" not in data["suggested_disabled"]
    assert "open_page" not in data["suggested_disabled"]  # outil local, sans route
