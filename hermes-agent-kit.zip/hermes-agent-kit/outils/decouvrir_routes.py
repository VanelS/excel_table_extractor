"""Découverte : confronte le catalogue d'outils de l'agent Hermes aux routes réelles de l'API.

À lancer depuis `hermes_back`, venv actif :

    python scripts/agent/decouvrir_routes.py --app app.api.app:create_app --factory \
        --front ../hermes_front/src/app/app.routes.ts \
        --sortie docs/agent-hermes/rapport-decouverte.md --json scripts/agent/decouverte.json

L'application n'est pas démarrée (ni cycle de vie, ni base ouverte) : le script lit seulement la
table des routes FastAPI. Il produit :
- pour chaque outil, la présence de chacune de ses routes ;
- pour chaque route trouvée : la fonction qui la sert, ses paramètres, ses modèles de corps et de
  réponse comparés aux champs que l'outil envoie ou lit, et, pour les routes qui modifient,
  si un contrôle de rôle et de CSRF est visible dans ses dépendances ;
- les dépendances les plus utilisées par les routes /api (utilisateur courant, CSRF…) ;
- les réglages proposés : outils à désactiver (route absente), candidats à l'activation ;
- l'écart entre les routes de l'interface Angular et la table `PAGES` de l'agent (pages
  absentes, en trop, paramètres nommés autrement) ;
- les routes /api qu'aucun outil n'utilise (pour préparer la phase 3).

Code de sortie : 0 si toutes les routes des outils actifs par défaut existent, 2 sinon.
"""

from __future__ import annotations

import argparse
import importlib
import inspect
import json
import os
import re
import sys
from collections import Counter
from pathlib import Path
from typing import Any

sys.path.insert(0, os.getcwd())  # lancé depuis hermes_back : `app` doit être importable

_PARAM_RE = re.compile(r"\{[^}]+\}")
_FRONT_PARAM_RE = re.compile(r":[A-Za-z_]\w*")
# Indices cherchés dans le nom des fonctions de dépendance (jamais dans le chemin du module) :
# un indice ne prouve rien, la procédure exige de lire chaque route qui modifie.
_ROLE_HINTS = ("role", "admin", "permission", "habilit", "authoriz", "privilege")
_CSRF_HINTS = ("csrf",)

# Corps envoyés par les outils (voir app/services/agent/tools/).
EXPECTED_BODY: dict[tuple[str, str], list[str]] = {
    ("POST", "/api/controls/{}/executions"): [
        "sources",
        "control_date",
        "control_version",
    ],
    ("POST", "/api/controls/{}/dispositions"): [
        "identity_key",
        "rule_name",
        "judgment",
        "reason",
        "control_version",
        "run_id",
    ],
    ("POST", "/api/executions/{}/rerun"): [],
    ("POST", "/api/controls/{}/validate-source"): ["sources"],
    ("POST", "/api/controls/{}/dry-run"): ["sources"],
    ("POST", "/api/executions/{}/query"): ["question"],
}


def _expected_reads() -> dict[tuple[str, str], dict[str, tuple[str, ...]]]:
    """Champs lus par les outils dans les réponses, avec leurs noms candidats."""
    from app.services.agent.tools import _common, dispositions

    return {
        ("GET", "/api/controls"): _common._CONTROL_FIELDS,
        ("GET", "/api/controls/{}"): _common._CONTROL_FIELDS,
        ("GET", "/api/executions"): _common._RUN_FIELDS,
        ("GET", "/api/executions/{}"): _common._RUN_FIELDS,
        ("GET", "/api/controls/{}/dispositions"): dispositions._DISPOSITION_FIELDS,
    }


def normalize(path: str) -> str:
    return _PARAM_RE.sub("{}", path.rstrip("/") or "/")


def load_app(target: str, factory: bool) -> Any:
    module_name, _, attribute = target.partition(":")
    if not attribute:
        raise SystemExit(
            "--app attendu au format module:attribut, ex. app.api.app:create_app"
        )
    app = getattr(importlib.import_module(module_name), attribute)
    return app() if factory else app


def _callable_name(call: Any) -> str:
    target = getattr(call, "__wrapped__", call)
    module = getattr(target, "__module__", "?")
    name = getattr(target, "__qualname__", None) or type(target).__name__
    return f"{module}.{name}"


def _calls(dependant: Any, seen: set[int] | None = None) -> list[Any]:
    """Fonctions de dépendance d'une route, récursivement (Depends imbriqués compris)."""
    seen = seen if seen is not None else set()
    calls = []
    for sub in getattr(dependant, "dependencies", None) or []:
        if id(sub) in seen:
            continue
        seen.add(id(sub))
        if sub.call is not None:
            calls.append(sub.call)
        calls.extend(_calls(sub, seen))
    return calls


def dependency_names(dependant: Any) -> list[str]:
    return [_callable_name(call) for call in _calls(dependant)]


def _hint(dependant: Any, hints: tuple[str, ...]) -> bool:
    names = " ".join(
        getattr(getattr(c, "__wrapped__", c), "__qualname__", type(c).__name__)
        for c in _calls(dependant)
    ).lower()
    return any(h in names for h in hints)


def _unwrap(model: Any) -> Any:
    """list[X] → X ; Optional et annotations simples laissés tels quels."""
    args = getattr(model, "__args__", None)
    if args and len(args) == 1:
        return args[0]
    return model


def _fields(model: Any) -> dict[str, dict[str, Any]] | None:
    fields = getattr(_unwrap(model), "model_fields", None)
    if not isinstance(fields, dict):
        return None
    return {
        name: {
            "type": str(getattr(f, "annotation", "?")).replace("typing.", ""),
            "required": bool(getattr(f, "is_required", lambda: False)()),
        }
        for name, f in fields.items()
    }


def _type_name(model: Any) -> str | None:
    if model is None:
        return None
    if getattr(model, "__args__", None):  # list[ControlSummary], X | None…
        return re.sub(r"\b[\w.]+\.(\w+)", r"\1", str(model))
    return getattr(model, "__name__", None) or str(model)


def _source_of(endpoint: Any) -> str:
    try:
        file = inspect.getsourcefile(endpoint) or "?"
        line = inspect.getsourcelines(endpoint)[1]
        try:
            file = str(Path(file).resolve().relative_to(Path.cwd()))
        except ValueError:
            pass
        return f"{file}:{line}"
    except (OSError, TypeError):
        return "?"


def describe_route(route: Any) -> dict[str, Any]:
    body_model = None
    body_field = getattr(route, "body_field", None)
    if body_field is not None:
        body_model = getattr(body_field, "type_", None) or getattr(
            getattr(body_field, "field_info", None), "annotation", None
        )
    dependant = getattr(route, "dependant", None)
    deps = dependency_names(dependant) if dependant is not None else []
    response_model = getattr(route, "response_model", None)
    return {
        "path": route.path,
        "methods": sorted(m for m in route.methods if m not in {"HEAD", "OPTIONS"}),
        "endpoint": _callable_name(route.endpoint),
        "source": _source_of(route.endpoint),
        "async": inspect.iscoroutinefunction(route.endpoint),
        "status_code": getattr(route, "status_code", None),
        "query_params": [p.name for p in getattr(dependant, "query_params", [])]
        if dependant
        else [],
        "body_model": _type_name(body_model),
        "body_fields": _fields(body_model),
        "response_model": _type_name(response_model),
        "response_fields": _fields(response_model),
        "dependencies": deps,
        "role_check": _hint(dependant, _ROLE_HINTS) if dependant is not None else False,
        "csrf_check": _hint(dependant, _CSRF_HINTS) if dependant is not None else False,
    }


def iter_api_routes(routes: Any) -> Any:
    """Routes d'API effectives, quelle que soit la version de FastAPI : `APIRoute` aplaties
    (versions anciennes) ou routeurs inclus paresseusement, dont `effective_route_contexts()`
    donne le chemin complet et les dépendances cumulées (versions récentes)."""
    from fastapi.routing import APIRoute

    for route in routes:
        if isinstance(route, APIRoute):
            yield route
        elif hasattr(route, "effective_route_contexts"):
            for context in route.effective_route_contexts():
                if getattr(context, "dependant", None) is not None and getattr(
                    context, "methods", None
                ):
                    yield context


def api_routes(app: Any) -> list[dict[str, Any]]:
    return [describe_route(r) for r in iter_api_routes(app.routes)]


def front_routes(path: Path) -> list[str]:
    """Chemins déclarés dans app.routes.ts (lecture simple, imbrication ignorée)."""
    text = path.read_text(encoding="utf-8")
    found = re.findall(r"path\s*:\s*['\"]([^'\"]*)['\"]", text)
    return sorted({"/" + p.strip("/") if p else "/" for p in found if p != "**"})


def _body_check(key: tuple[str, str], route: dict[str, Any]) -> list[str]:
    expected = EXPECTED_BODY.get(key)
    if expected is None:
        return []
    actual = route["body_fields"]
    if actual is None:
        return [
            (
                f"Corps envoyé par l'outil : {expected or '{}'} ; pas de modèle de corps "
                "lisible : lire la fonction pour confirmer."
            )
        ]
    lines = []
    unknown = [f for f in expected if f not in actual]
    missing = [
        f for f, info in actual.items() if info["required"] and f not in expected
    ]
    lines.append(
        "Champs envoyés par l'outil inconnus du modèle : "
        + (", ".join(unknown) if unknown else "aucun")
    )
    lines.append(
        "Champs obligatoires du modèle non envoyés : "
        + (", ".join(missing) if missing else "aucun")
    )
    return lines


def _read_check(key: tuple[str, str], route: dict[str, Any]) -> list[str]:
    expected = _expected_reads().get(key)
    if expected is None:
        return []
    actual = route["response_fields"]
    if actual is None:
        return [
            "Champs lus par l'outil : "
            + ", ".join(f"{k} ({'|'.join(c)})" for k, c in expected.items())
            + " ; pas de modèle de réponse lisible : lire la fonction pour confirmer."
        ]
    found = []
    for logical, candidates in expected.items():
        match = next((c for c in candidates if c in actual), None)
        found.append(f"{logical} → {match or '**absent**'}")
    return ["Champs lus par l'outil (logique → champ réel) : " + ", ".join(found)]


def build_report(app: Any, front: Path | None) -> tuple[str, dict[str, Any], int]:
    from app.services.agent.domain import APP_ROUTES
    from app.services.agent.registry import load_tools

    routes = api_routes(app)
    index: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for route in routes:
        for method in route["methods"]:
            index.setdefault((method, normalize(route["path"])), []).append(route)

    lines = [
        "# Rapport de découverte — agent Hermes",
        "",
        f"{len(routes)} routes FastAPI lues, dont {sum(r['path'].startswith('/api/') for r in routes)} sous /api.",
        "",
        "## Outils et routes",
        "",
        "| Outil | Phase | Rôle min. | Actif par défaut | Route attendue | État |",
        "| --- | --- | --- | --- | --- | --- |",
    ]
    tools_data, to_disable, candidates = [], [], []
    used_by: dict[tuple[str, str], list[str]] = {}
    for spec in load_tools().values():
        entries = []
        for ref in spec.routes:
            key = (ref.method, normalize(ref.template))
            found = index.get(key, [])
            status = (
                "présente"
                if len(found) == 1
                else ("absente" if not found else "ambiguë")
            )
            entries.append(
                {"method": ref.method, "template": ref.template, "status": status}
            )
            used_by.setdefault(key, []).append(spec.name)
            lines.append(
                f"| `{spec.name}` | {spec.phase} | {spec.min_role.value} | "
                f"{'oui' if spec.enabled_by_default else 'non'} | `{ref.method} {ref.template}` | {status} |"
            )
        if not spec.routes:
            lines.append(
                f"| `{spec.name}` | {spec.phase} | {spec.min_role.value} | "
                f"{'oui' if spec.enabled_by_default else 'non'} | aucune (outil local) | — |"
            )
        all_present = all(e["status"] == "présente" for e in entries)
        if spec.enabled_by_default and not all_present:
            to_disable.append(spec.name)
        if not spec.enabled_by_default and all_present:
            candidates.append(spec.name)
        tools_data.append(
            {
                "name": spec.name,
                "phase": spec.phase,
                "enabled_by_default": spec.enabled_by_default,
                "routes": entries,
            }
        )

    lines += ["", "## Détail des routes utilisées par les outils", ""]
    for key, tools in sorted(used_by.items(), key=lambda kv: (kv[0][1], kv[0][0])):
        for route in index.get(key, []):
            method = key[0]
            lines.append(f"### `{method} {route['path']}`")
            lines.append("")
            lines.append(
                f"- Outils : {', '.join(f'`{t}`' for t in sorted(set(tools)))}"
            )
            lines.append(
                f"- Fonction : `{route['endpoint']}` ({route['source']}), {'async def' if route['async'] else 'def'}"
            )
            lines.append(
                f"- Code de succès déclaré : {route['status_code'] or 'non déclaré (200 par défaut)'}"
            )
            if route["query_params"]:
                lines.append(
                    f"- Paramètres de requête : {', '.join(route['query_params'])}"
                )
            if route["body_model"]:
                lines.append(
                    f"- Corps : `{route['body_model']}` {json.dumps(route['body_fields'], ensure_ascii=False)}"
                )
            if route["response_model"]:
                lines.append(f"- Réponse : `{route['response_model']}`")
            for check in _body_check(key, route) + _read_check(key, route):
                lines.append(f"- {check}")
            if method != "GET":
                lines.append(
                    "- Indice de contrôle de rôle dans les dépendances : "
                    + ("oui" if route["role_check"] else "**aucun**")
                    + " — à confirmer en lisant la fonction (prérequis de phase 0)"
                )
                lines.append(
                    "- Indice de CSRF dans les dépendances : "
                    + (
                        "oui"
                        if route["csrf_check"]
                        else "aucun (dépendance d'authentification ou middleware ?)"
                    )
                )
            lines.append(
                f"- Dépendances : {', '.join('`' + d + '`' for d in route['dependencies']) or 'aucune'}"
            )
            lines.append("")

    usage = Counter(
        d for r in routes if r["path"].startswith("/api/") for d in r["dependencies"]
    )
    lines += ["## Dépendances les plus utilisées par les routes /api", ""]
    lines += [
        f"- `{name}` : {count} route(s)" for name, count in usage.most_common(12)
    ] or ["- aucune"]

    lines += ["", "## Réglages proposés", ""]
    lines.append(
        f"- `HERMES_AGENT_DISABLED_TOOLS={','.join(to_disable)}` (route absente)"
        if to_disable
        else "- Toutes les routes des outils actifs par défaut existent."
    )
    lines.append(
        "- Candidats à l'activation, une fois leur corps de requête vérifié et un test ajouté : "
        + (", ".join(f"`{c}`" for c in candidates) if candidates else "aucun")
    )

    front_data: dict[str, Any] = {}
    if front is not None:
        declared = front_routes(front)

        def shape(path: str) -> str:
            return _FRONT_PARAM_RE.sub(":p", path)

        whitelist = {shape(r) for r in APP_ROUTES}
        by_shape = {shape(p): p for p in declared}
        missing_in_front = [r for r in APP_ROUTES if shape(r) not in by_shape]
        unknown_to_agent = [p for p in declared if shape(p) not in whitelist]
        # Même page, paramètre nommé autrement : le panneau enverra le gabarit de l'interface,
        # comparé tel quel à la liste blanche. La valeur de PAGES doit donc être corrigée.
        renamed = [
            {"kit": r, "front": by_shape[shape(r)]}
            for r in APP_ROUTES
            if shape(r) in by_shape and by_shape[shape(r)] != r
        ]
        front_data = {
            "declared": declared,
            "missing_in_front": missing_in_front,
            "unknown_to_agent": unknown_to_agent,
            "renamed_params": renamed,
        }
        lines += [
            "",
            "## Pages de l'interface et table `PAGES` (`domain.py`)",
            "",
            (
                f"Lecture simple de `{front}` : l'imbrication des routes n'est pas "
                "reconstituée ; un chemin enfant se lit avec celui de son parent."
            ),
            "",
            "- Même page, paramètre nommé autrement (corriger la valeur dans `PAGES`) : "
            + (
                ", ".join(f"`{r['kit']}` → `{r['front']}`" for r in renamed)
                if renamed
                else "aucune"
            ),
            "- Dans `PAGES` mais introuvables dans le fichier (corriger le chemin, ou retirer "
            "l'entrée si l'interface n'a pas la page) : "
            + (
                ", ".join(f"`{p}`" for p in missing_in_front)
                if missing_in_front
                else "aucune"
            ),
            "- Dans le fichier mais absentes de `PAGES` (normal pour /login, /sso) : "
            + (
                ", ".join(f"`{p}`" for p in unknown_to_agent)
                if unknown_to_agent
                else "aucune"
            ),
        ]

    unused = sorted(
        f"{m} {r['path']}"
        for r in routes
        if r["path"].startswith("/api/") and not r["path"].startswith("/api/agent")
        for m in r["methods"]
        if (m, normalize(r["path"])) not in used_by
    )
    lines += ["", "## Routes /api sans outil (pour préparer la phase 3)", ""]
    lines += [f"- `{u}`" for u in unused] or ["- aucune"]
    lines.append("")

    data = {
        "tools": tools_data,
        "routes": routes,
        "suggested_disabled": to_disable,
        "activation_candidates": candidates,
        "front": front_data,
        "unused_api_routes": unused,
    }
    return "\n".join(lines), data, (2 if to_disable else 0)


def main() -> int:
    for stream in (
        sys.stdout,
        sys.stderr,
    ):  # console Windows : jamais d'erreur d'encodage
        try:
            stream.reconfigure(errors="replace")
        except AttributeError:
            pass
    parser = argparse.ArgumentParser(
        description="Confronte le catalogue d'outils de l'agent Hermes aux routes de l'API.",
        epilog=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--app", required=True, help="module:attribut, ex. app.api.app:create_app"
    )
    parser.add_argument(
        "--factory",
        action="store_true",
        help="l'attribut est une fabrique à appeler sans argument",
    )
    parser.add_argument("--front", type=Path, help="chemin de app.routes.ts")
    parser.add_argument(
        "--sortie", type=Path, help="rapport Markdown (sinon : sortie standard)"
    )
    parser.add_argument("--json", type=Path, help="résultats bruts en JSON")
    args = parser.parse_args()

    text, data, code = build_report(load_app(args.app, args.factory), args.front)
    if args.sortie:
        args.sortie.write_text(text, encoding="utf-8")
        print(f"Rapport écrit : {args.sortie}")
    else:
        print(text)
    if args.json:
        args.json.write_text(
            json.dumps(data, ensure_ascii=False, indent=2, default=str),
            encoding="utf-8",
        )
    if code:
        print(
            "Des outils actifs par défaut n'ont pas leur route : voir « Réglages proposés ».",
            file=sys.stderr,
        )
    return code


if __name__ == "__main__":
    raise SystemExit(main())
