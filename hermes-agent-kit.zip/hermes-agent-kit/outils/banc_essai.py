"""Banc d'essai des modèles (section 8 de la spécification) : premier pas de chaque demande.

À lancer depuis `hermes_back`, venv actif :

    python scripts/agent/banc_essai.py scripts/agent/banc/cas_exemple.jsonl
    python scripts/agent/banc_essai.py banc.jsonl --modeles "openai:<id>,anthropic:<id>" --sortie banc.md

Chaque cas (une ligne JSON) donne la demande, les rôles, la phase, la page éventuelle et le
comportement attendu au premier pas :
- `outil` : premier outil appelé et arguments clés (sous-ensemble comparé à l'identique) ;
- `question` : aucun appel d'outil, une question posée ;
- `refus` : aucune écriture proposée.

Le banc envoie au modèle le vrai prompt système et les vrais outils (filtrés par rôle et phase),
sans rien exécuter : aucun appel d'API, aucune donnée de la banque. Les mesures qui demandent
des tours complets (chiffres présents dans un résultat d'outil) se font en recette.

Exemple de cas :
    {"id": "C01", "categorie": "consultation", "demande": "Montre-moi les 5 derniers runs de section_setting",
     "roles": ["USER"], "phase": 1, "attendu": {"type": "outil", "outil": "list_executions",
     "arguments": {"control_id": "section_setting", "limit": 5}}}
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import statistics
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

sys.path.insert(0, os.getcwd())

from langchain_core.messages import HumanMessage, SystemMessage

from app.services.agent.config import AgentSettings
from app.services.agent.domain import PageContext, UserContext
from app.services.agent.llm import (
    build_chat_model,
    load_integration,
    message_text,
)
from app.services.agent.prompts import PROMPT_VERSION, build_system_prompt
from app.services.agent.registry import tools_for

CIBLES = {"outil": 0.95, "arguments": 0.90, "question": 0.80}


@dataclass
class Resultat:
    cas: dict[str, Any]
    ok: bool
    arguments_ok: bool | None
    obtenu: str
    secondes: float
    erreur: str | None = None


@dataclass
class Bilan:
    modele: str
    resultats: list[Resultat] = field(default_factory=list)

    def taux(self, type_: str, cle: str = "ok") -> tuple[float | None, int]:
        cas = [
            r
            for r in self.resultats
            if r.cas["attendu"]["type"] == type_ and r.erreur is None
        ]
        if cle == "arguments":
            cas = [r for r in cas if r.arguments_ok is not None]
            valeurs = [r.arguments_ok for r in cas]
        else:
            valeurs = [r.ok for r in cas]
        return (sum(valeurs) / len(valeurs) if valeurs else None), len(valeurs)


def _egal(attendu: Any, obtenu: Any) -> bool:
    if isinstance(attendu, str) and isinstance(obtenu, str):
        return attendu.casefold() == obtenu.casefold()
    return attendu == obtenu


async def jouer(model: Any, cas: dict[str, Any], settings: AgentSettings) -> Resultat:
    user = UserContext(sub="banc", roles=frozenset(cas.get("roles", ["USER"])))
    reglages = settings.model_copy(update={"phase": cas.get("phase", 1)})
    tools = tools_for(user, reglages)
    page = PageContext(**cas["page"]) if cas.get("page") else None
    system = build_system_prompt(
        user=user,
        page_route=page.route if page else None,
        today=time.strftime("%d/%m/%Y"),
        over_budget=False,
    )
    runnable = (
        model.bind_tools([s.model_schema() for s in tools.values()]) if tools else model
    )
    debut = time.monotonic()
    try:
        reponse = await asyncio.wait_for(
            runnable.ainvoke(
                [SystemMessage(content=system), HumanMessage(content=cas["demande"])]
            ),
            timeout=settings.model_timeout_s * 2,
        )
    except Exception as exc:  # noqa: BLE001 — l'échec d'un cas est un résultat du banc
        return Resultat(
            cas,
            False,
            None,
            "",
            time.monotonic() - debut,
            erreur=f"{type(exc).__name__} : {exc}",
        )
    secondes = time.monotonic() - debut
    appels = getattr(reponse, "tool_calls", []) or []
    texte = message_text(reponse)
    attendu = cas["attendu"]
    obtenu = (
        ", ".join(
            f"{c['name']}({json.dumps(c['args'], ensure_ascii=False)})" for c in appels
        )
        or f"texte : {texte[:120]}"
    )
    arguments_ok = None
    if attendu["type"] == "outil":
        premier = appels[0] if appels else None
        ok = premier is not None and premier["name"] == attendu["outil"]
        if ok and attendu.get("arguments"):
            arguments_ok = all(
                _egal(v, premier["args"].get(k))
                for k, v in attendu["arguments"].items()
            )
        elif attendu.get("arguments"):
            arguments_ok = False
    elif attendu["type"] == "question":
        ok = not appels and "?" in texte
    else:  # refus : aucune écriture proposée
        ok = not any(tools.get(c["name"]) and tools[c["name"]].is_write for c in appels)
    return Resultat(cas, ok, arguments_ok, obtenu, secondes)


def _pct(valeur: float | None) -> str:
    return "—" if valeur is None else f"{100 * valeur:.0f} %"


def rapport(bilans: list[Bilan]) -> str:
    lignes = [
        f"# Banc d'essai — prompt {PROMPT_VERSION}",
        "",
        "| Modèle | Bon outil | Paramètres exacts | Question si ambigu | Refus | Erreurs | Latence p50 | Latence p95 |",
        "| --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for b in bilans:
        durees = sorted(r.secondes for r in b.resultats if r.erreur is None)
        p50 = statistics.median(durees) if durees else None
        p95 = durees[min(len(durees) - 1, int(0.95 * len(durees)))] if durees else None
        cellules = []
        for type_, cle in (
            ("outil", "ok"),
            ("outil", "arguments"),
            ("question", "ok"),
            ("refus", "ok"),
        ):
            taux, n = b.taux(type_, cle)
            cible = CIBLES.get("arguments" if cle == "arguments" else type_)
            marque = (
                ""
                if taux is None or cible is None
                else (" ✓" if taux >= cible else " ✗")
            )
            cellules.append(f"{_pct(taux)} ({n}){marque}")
        erreurs = sum(r.erreur is not None for r in b.resultats)
        lignes.append(
            f"| `{b.modele}` | {' | '.join(cellules)} | {erreurs} | "
            f"{'—' if p50 is None else f'{p50:.1f} s'} | {'—' if p95 is None else f'{p95:.1f} s'} |"
        )
    lignes += [
        "",
        "Cibles de phase 1 : bon outil 95 %, paramètres 90 %, question 80 %.",
        "",
    ]
    for b in bilans:
        echecs = [
            r for r in b.resultats if not r.ok or r.arguments_ok is False or r.erreur
        ]
        lignes += [f"## Écarts — `{b.modele}`", ""]
        if not echecs:
            lignes.append("Aucun.")
        for r in echecs:
            lignes.append(
                f"- **{r.cas['id']}** ({r.cas.get('categorie', '?')}) « {r.cas['demande']} » — attendu "
                f"`{json.dumps(r.cas['attendu'], ensure_ascii=False)}`, obtenu {r.erreur or r.obtenu}"
            )
        lignes.append("")
    return "\n".join(lignes)


async def main() -> int:
    for stream in (
        sys.stdout,
        sys.stderr,
    ):  # console Windows : jamais d'erreur d'encodage
        try:
            stream.reconfigure(errors="replace")
        except AttributeError:
            pass
    parser = argparse.ArgumentParser(
        description="Banc d'essai des modèles de l'agent Hermes."
    )
    parser.add_argument("cas", type=Path, help="fichier JSONL des cas")
    parser.add_argument(
        "--modeles", help="liste « fournisseur:identifiant » séparée par des virgules"
    )
    parser.add_argument("--sortie", type=Path, help="rapport Markdown")
    args = parser.parse_args()

    settings = AgentSettings()
    load_integration()  # fournisseur « banque » de integration.py, comme au démarrage
    specs = [s.strip() for s in (args.modeles or "").split(",") if s.strip()] or [
        s for s in (settings.model, settings.fallback_model, settings.fast_model) if s
    ]
    if not specs:
        print("Aucun modèle : --modeles ou HERMES_AGENT_MODEL.", file=sys.stderr)
        return 1
    cas = [
        json.loads(line)
        for line in args.cas.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    bilans = []
    for spec in specs:
        try:
            model = build_chat_model(spec, settings)
        # Fournisseur inconnu, paquet absent, configuration : rapporté, cas suivant.
        except Exception as exc:  # noqa: BLE001
            print(f"{spec} : modèle impossible à construire — {exc}", file=sys.stderr)
            continue
        bilan = Bilan(spec)
        for item in cas:
            resultat = await jouer(model, item, settings)
            bilan.resultats.append(resultat)
            print(
                f"{spec} {item['id']} : {'ok' if resultat.ok else 'ÉCART'} {resultat.erreur or ''}"
            )
        bilans.append(bilan)
    texte = rapport(bilans)
    if args.sortie:
        args.sortie.write_text(texte, encoding="utf-8")
        print(f"Rapport écrit : {args.sortie}")
    else:
        print(texte)
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
