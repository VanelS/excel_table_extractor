"""Vérifie qu'une base migrée porte exactement le schéma de l'agent Hermes.

À lancer depuis `hermes_back`, venv actif, sur une COPIE de la base de développement, après y
avoir appliqué les migrations (étape 5 de la procédure) :

    python scripts/agent/verifier_migration.py <chemin de la copie de hermes.db>

Compare les tables `agent_*` de la base, leurs colonnes (type, NOT NULL, défaut, clé primaire)
et leurs index (colonnes, unicité, condition) à ceux que crée `app/services/agent/schema.sql`,
la référence du code. La base est ouverte en lecture seule.

Code de sortie : 0 si le schéma est conforme, 1 sinon.
"""

from __future__ import annotations

import os
import re
import sqlite3
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, os.getcwd())  # lancé depuis hermes_back : `app` doit être importable

_AGENT_TABLES = "SELECT name FROM sqlite_master WHERE type = 'table' AND name LIKE 'agent\\_%' ESCAPE '\\'"


_LABELS = {"table": "table", "index": "index"}
_AGREEMENT = {"table": "e", "index": ""}  # « table absente », « index absent »


def _index_sql(sql: str | None) -> str | None:
    if sql is None:  # index implicite (clé primaire, UNIQUE)
        return None
    text = " ".join(sql.lower().split())
    return re.sub(r"\bif not exists\s+", "", text)


def describe(conn: sqlite3.Connection) -> dict[tuple[str, str], Any]:
    """Tables agent_* : colonnes par nom ; index : colonnes, unicité, SQL normalisé."""
    shape: dict[tuple[str, str], Any] = {}
    for (table,) in conn.execute(_AGENT_TABLES).fetchall():
        shape[("table", table)] = {
            name: (str(kind).upper(), bool(notnull), default, pk)
            for _, name, kind, notnull, default, pk in conn.execute(
                f"PRAGMA table_info('{table}')"
            )
        }
        for _, index, unique, origin, _partial in conn.execute(
            f"PRAGMA index_list('{table}')"
        ):
            if origin != "c":  # index créés par CREATE INDEX seulement
                continue
            columns = [r[2] for r in conn.execute(f"PRAGMA index_info('{index}')")]
            (sql,) = conn.execute(
                "SELECT sql FROM sqlite_master WHERE type = 'index' AND name = ?",
                (index,),
            ).fetchone()
            shape[("index", index)] = (table, columns, bool(unique), _index_sql(sql))
    return shape


def reference() -> dict[tuple[str, str], Any]:
    from app.services.agent.store import schema_statements

    conn = sqlite3.connect(":memory:")
    for statement in schema_statements():
        conn.execute(statement)
    return describe(conn)


def compare(db_path: Path) -> list[str]:
    if not db_path.is_file():
        return [f"base introuvable : {db_path}"]
    conn = sqlite3.connect(f"{db_path.resolve().as_uri()}?mode=ro", uri=True)
    try:
        actual = describe(conn)
    finally:
        conn.close()
    expected = reference()
    problems = []
    for key, value in expected.items():
        kind, name = key
        if key not in actual:
            problems.append(f"{_LABELS[kind]} absent{_AGREEMENT[kind]} : {name}")
        elif kind == "table":
            for column, spec in value.items():
                found = actual[key].get(column)
                if found is None:
                    problems.append(f"colonne absente : {name}.{column}")
                elif found != spec:
                    problems.append(
                        f"colonne différente : {name}.{column} — attendu {spec}, trouvé {found}"
                    )
            for column in actual[key].keys() - value.keys():
                problems.append(f"colonne en trop : {name}.{column}")
        elif actual[key] != value:
            problems.append(
                f"index différent : {name} — attendu {value}, trouvé {actual[key]}"
            )
    for kind, name in sorted(actual.keys() - expected.keys()):
        problems.append(f"{_LABELS[kind]} en trop : {name}")
    return problems


def main() -> int:
    for stream in (
        sys.stdout,
        sys.stderr,
    ):  # console Windows : jamais d'erreur d'encodage
        try:
            stream.reconfigure(errors="replace")
        except AttributeError:
            pass
    if len(sys.argv) != 2 or sys.argv[1] in {"-h", "--help"}:
        print(__doc__)
        return 2
    problems = compare(Path(sys.argv[1]))
    if problems:
        print("Schéma de l'agent NON conforme à schema.sql :")
        for problem in problems:
            print(f"- {problem}")
        return 1
    expected = reference()
    tables = sum(kind == "table" for kind, _ in expected)
    indexes = sum(kind == "index" for kind, _ in expected)
    print(
        f"Schéma de l'agent conforme à schema.sql : {tables} tables, {indexes} index."
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
