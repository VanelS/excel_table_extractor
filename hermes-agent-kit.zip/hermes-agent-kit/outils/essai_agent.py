"""Essai de bout en bout de l'agent Hermes sur une application lancée (développement ou recette).

Prérequis : l'application tourne avec `HERMES_AGENT_ENABLED=True` et un modèle configuré.
En développement (`IS_DEV_MODE=True`), `--connexion-dev` ouvre la session administrateur fictive
par `GET /api/login`. Ailleurs, passer les cookies d'une session ouverte dans le navigateur.

    python scripts/agent/essai_agent.py --base http://localhost:8000 \
        --origin http://localhost:4200 --connexion-dev
    python scripts/agent/essai_agent.py ... --avec-action --controle section_setting

Étapes : session, /api/me, capacités, conversation, un tour de consultation. Avec
`--avec-action`, demande le lancement d'un contrôle, vérifie que la carte arrive, puis la REFUSE :
rien n'est jamais exécuté par ce script. Une réponse du modèle de secours fait échouer l'essai :
elle signale un modèle principal en échec.

Code de sortie : 0 si toutes les étapes passent, 1 sinon.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
import uuid
from typing import Any

import httpx


class Echec(Exception):
    pass


def etape(titre: str) -> None:
    print(f"\n== {titre}")


def ouvrir_session_dev(client: httpx.Client) -> None:
    """Suit les redirections de /api/login sans quitter l'application, en gardant les cookies."""
    url = "/api/login"
    for _ in range(4):
        response = client.get(url, follow_redirects=False)
        if "hermes_session" in client.cookies:
            return
        location = response.headers.get("location")
        if response.status_code not in (301, 302, 303, 307, 308) or not location:
            break
        if location.startswith("http") and not location.startswith(
            str(client.base_url)
        ):
            break  # redirection vers le fournisseur d'identité : pas de mode développement
        url = location
    raise Echec(
        "pas de cookie hermes_session après /api/login : IS_DEV_MODE=True ? "
        "Sinon, passer --cookie hermes_session=… --cookie hermes_csrf=…"
    )


def lire_flux(response: httpx.Response) -> list[tuple[str, dict[str, Any]]]:
    """Lit le flux SSE au fil de l'eau et affiche chaque événement."""
    if response.status_code != 200:
        response.read()
        raise Echec(f"HTTP {response.status_code} : {response.text[:300]}")
    events, name, data = [], None, []
    texte_en_cours = False
    for line in response.iter_lines():
        if line.startswith("event:"):
            name = line[6:].strip()
        elif line.startswith("data:"):
            data.append(line[5:].lstrip())
        elif not line.strip() and name:
            payload = json.loads("\n".join(data)) if data else {}
            events.append((name, payload))
            if name == "message.delta":
                print(payload.get("text", ""), end="", flush=True)
                texte_en_cours = True
            else:
                if texte_en_cours:
                    print()
                    texte_en_cours = False
                print(f"  [{name}] {resumer(name, payload)}")
            name, data = None, []
    return events


def resumer(name: str, payload: dict[str, Any]) -> str:
    if name == "tool.started":
        return payload.get("label", payload.get("tool", ""))
    if name == "tool.completed":
        card = payload.get("card") or {}
        return f"{payload.get('tool')} ok={payload.get('ok')} carte={card.get('kind')}"
    if name == "action.proposed":
        champs = "; ".join(
            f"{f['label']}={f['value']}" for f in payload.get("fields", [])
        )
        return f"{payload.get('title')} ({payload.get('level')}) — {champs}"
    if name == "action.updated":
        return f"{payload.get('action_id')} → {payload.get('status')}"
    if name == "message.completed":
        return f"modèle={payload.get('model')} jetons={payload.get('usage')}"
    return json.dumps(payload, ensure_ascii=False)[:200]


def controler_reponses(events: list[tuple[str, dict[str, Any]]]) -> None:
    """Une réponse du modèle de secours signale un modèle principal en échec : l'essai échoue,
    même si la conversation a abouti."""
    for name, payload in events:
        if name == "message.completed" and payload.get("fallback"):
            raise Echec(
                f"réponse produite par le modèle de secours ({payload.get('model')}) : le "
                "modèle principal échoue. Voir le journal de l'application et "
                "verifier_modeles.py (étape 9)."
            )


def tour(
    client: httpx.Client, conv: str, texte: str
) -> list[tuple[str, dict[str, Any]]]:
    print(f"> {texte}")
    debut = time.monotonic()
    with client.stream(
        "POST",
        f"/api/agent/conversations/{conv}/messages",
        json={"request_id": uuid.uuid4().hex, "content": texte},
        timeout=httpx.Timeout(10.0, read=180.0),
    ) as response:
        events = lire_flux(response)
    print(f"  ({time.monotonic() - debut:.1f} s)")
    noms = [n for n, _ in events]
    if "error" in noms:
        raise Echec(f"le tour s'est arrêté sur une erreur : {dict(events)['error']}")
    if not noms or noms[-1] != "done":
        raise Echec(f"flux incomplet : {noms}")
    controler_reponses(events)
    return events


def main() -> int:
    for stream in (
        sys.stdout,
        sys.stderr,
    ):  # console Windows : jamais d'erreur d'encodage
        try:
            stream.reconfigure(errors="replace")
        except AttributeError:
            pass
    parser = argparse.ArgumentParser(
        description="Essai de bout en bout de l'agent Hermes."
    )
    parser.add_argument("--base", default="http://localhost:8000", help="URL de l'API")
    parser.add_argument(
        "--origin",
        default="http://localhost:4200",
        help="Origin autorisée (CORS_ORIGINS)",
    )
    parser.add_argument(
        "--connexion-dev",
        action="store_true",
        help="session fictive par /api/login (IS_DEV_MODE)",
    )
    parser.add_argument(
        "--cookie", action="append", default=[], help="nom=valeur, répétable"
    )
    parser.add_argument(
        "--message",
        default="Quels contrôles sont disponibles, et quelle est leur version championne ?",
    )
    parser.add_argument(
        "--avec-action",
        action="store_true",
        help="proposer un lancement, puis le refuser",
    )
    parser.add_argument(
        "--controle",
        default="section_setting",
        help="contrôle utilisé par --avec-action",
    )
    args = parser.parse_args()

    client = httpx.Client(base_url=args.base, timeout=30.0)
    for item in args.cookie:
        name, _, value = item.partition("=")
        client.cookies.set(name.strip(), value.strip())
    try:
        etape("Session")
        if args.connexion_dev:
            ouvrir_session_dev(client)
        csrf = client.cookies.get("hermes_csrf")
        if not csrf:
            raise Echec("cookie hermes_csrf absent : les POST seront refusés")
        client.headers.update({"X-CSRF-Token": csrf, "Origin": args.origin})
        me = client.get("/api/me")
        if me.status_code != 200:
            raise Echec(f"/api/me répond {me.status_code}")
        print(f"  utilisateur : rôles {me.json().get('roles')}")

        etape("Capacités")
        caps = client.get("/api/agent/capabilities")
        if caps.status_code == 404:
            raise Echec(
                "/api/agent répond 404 : HERMES_AGENT_ENABLED=True ? routeur inclus ?"
            )
        caps.raise_for_status()
        outils = [t["name"] for t in caps.json()["tools"]]
        print(
            f"  phase {caps.json()['phase']}, {len(outils)} outils : {', '.join(outils)}"
        )

        etape("Conversation")
        created = client.post("/api/agent/conversations", json={})
        if created.status_code != 201:
            raise Echec(
                f"création refusée : HTTP {created.status_code} {created.text[:200]}"
            )
        conv = created.json()["id"]
        print(f"  {conv}")

        etape("Tour de consultation")
        events = tour(client, conv, args.message)
        if not any(n == "tool.completed" for n, _ in events):
            print(
                "  attention : aucun outil appelé, la réponse ne s'appuie sur aucune donnée"
            )

        if args.avec_action:
            etape("Action proposée puis refusée")
            if "start_execution" not in outils:
                raise Echec("start_execution absent : rôle USER_MANAGER requis")
            events = tour(
                client,
                conv,
                f"Lance le contrôle {args.controle} sur sa version championne.",
            )
            cartes = [p for n, p in events if n == "action.proposed"]
            if not cartes:
                print(
                    "  aucune carte : le modèle a peut-être posé une question (sources, date) ; relancer avec un message plus précis"
                )
                return 1
            carte = cartes[0]
            with client.stream(
                "POST",
                f"/api/agent/conversations/{conv}/actions/{carte['action_id']}/decision",
                json={
                    "decision": "reject",
                    "payload_hash": carte["payload_hash"],
                    "edited_fields": {},
                },
                timeout=httpx.Timeout(10.0, read=180.0),
            ) as response:
                events = lire_flux(response)
            statuts = [p.get("status") for n, p in events if n == "action.updated"]
            if "rejected" not in statuts:
                raise Echec(f"refus non pris en compte : {statuts}")
            controler_reponses(events)

        etape("Relecture de la conversation")
        detail = client.get(f"/api/agent/conversations/{conv}").json()
        print(
            f"  {len(detail['messages'])} messages, {len(detail['recent_tool_calls'])} appels d'outils tracés"
        )
        print("\nEssai réussi.")
        return 0
    except (Echec, httpx.HTTPError) as exc:
        print(f"\nÉCHEC : {exc}", file=sys.stderr)
        return 1
    finally:
        client.close()


if __name__ == "__main__":
    raise SystemExit(main())
