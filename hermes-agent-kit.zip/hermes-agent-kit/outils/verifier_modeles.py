"""Vérifie les modèles configurés pour l'agent Hermes, avant tout essai de bout en bout.

À lancer depuis `hermes_back`, venv actif, avec les variables `HERMES_AGENT_*` (ou `.env`) :

    python scripts/agent/verifier_modeles.py

Pour chaque modèle renseigné (principal, secours, rapide) : construction du client, réponse
simple, appel d'outil attendu (`list_executions` avec `control_id=section_setting`), diffusion en
fragments. Aucune donnée de la banque n'est envoyée : seulement les deux questions ci-dessous.

Code de sortie : 0 si le modèle principal passe les trois essais, 1 sinon.
"""

from __future__ import annotations

import asyncio
import os
import sys
import time
from typing import Any

sys.path.insert(0, os.getcwd())

from langchain_core.messages import HumanMessage, SystemMessage

from app.services.agent.config import AgentSettings
from app.services.agent.llm import (
    build_chat_model,
    load_integration,
    message_text,
)
from app.services.agent.registry import load_tools

QUESTION_OUTIL = "Montre-moi les 3 derniers runs du contrôle section_setting."


async def _timed(coro: Any, timeout: float) -> tuple[Any, float]:
    start = time.monotonic()
    result = await asyncio.wait_for(coro, timeout=timeout)
    return result, time.monotonic() - start


async def verifier(role: str, spec: str, settings: AgentSettings) -> bool:
    print(f"\n== {role} : {spec}")
    try:
        model = build_chat_model(spec, settings)
    # Configuration : fournisseur inconnu, paquet absent… Toute erreur est rapportée.
    except Exception as exc:  # noqa: BLE001
        print(f"  construction : ÉCHEC — {exc}")
        return False
    ok = True
    timeout = settings.model_timeout_s * 2
    responses_api = getattr(model, "use_responses_api", "sans objet")
    if responses_api != "sans objet":  # client OpenAI (fournisseurs openai, banque…)
        print(
            "  API OpenAI : "
            + ("Responses (/responses)" if responses_api else "Chat Completions")
            + (
                f" (HERMES_AGENT_OPENAI_API={settings.openai_api})"
                if settings.openai_api != "auto"
                else " (choix automatique de langchain-openai)"
            )
        )

    try:
        answer, seconds = await _timed(
            model.ainvoke([HumanMessage(content="Réponds uniquement par le mot OK.")]),
            timeout,
        )
        print(
            f"  réponse simple : « {message_text(answer).strip()[:40]} » en {seconds:.1f} s"
        )
    except Exception as exc:  # noqa: BLE001 — tout échec est rapporté
        print(f"  réponse simple : ÉCHEC — {type(exc).__name__} : {exc}")
        if responses_api not in ("sans objet", None, False):
            print(
                "  → la passerelle sert-elle /responses ? Sinon, HERMES_AGENT_OPENAI_API=chat "
                "(étape 9), après avoir vérifié que le modèle y est servi en Chat Completions."
            )
        elif "responses" in str(exc).lower():
            print(
                "  → ce modèle semble exiger /responses : HERMES_AGENT_OPENAI_API=responses "
                "(étape 9)."
            )
        return False

    tools = load_tools()
    schemas = [
        tools[name].model_schema()
        for name in ("list_executions", "get_platform_status")
    ]
    try:
        answer, seconds = await _timed(
            model.bind_tools(schemas).ainvoke(
                [
                    SystemMessage(
                        content="Tu es l'assistant de la plateforme HERMES. Utilise les outils."
                    ),
                    HumanMessage(content=QUESTION_OUTIL),
                ]
            ),
            timeout,
        )
        calls = getattr(answer, "tool_calls", []) or []
        good = any(
            c["name"] == "list_executions"
            and c["args"].get("control_id") == "section_setting"
            for c in calls
        )
        print(
            f"  appel d'outil : {'OK' if good else 'INATTENDU'} — "
            f"{[(c['name'], c['args']) for c in calls] or message_text(answer)[:80]} en {seconds:.1f} s"
        )
        ok = ok and good
    except Exception as exc:  # noqa: BLE001 — tout échec est rapporté
        print(f"  appel d'outil : ÉCHEC — {type(exc).__name__} : {exc}")
        ok = False

    try:
        chunks = 0
        start = time.monotonic()
        first = None
        merged = None
        async for chunk in model.astream(
            [HumanMessage(content="Compte de 1 à 10, en chiffres.")]
        ):
            chunks += 1
            first = first or time.monotonic() - start
            merged = chunk if merged is None else merged + chunk
        print(
            f"  diffusion : {chunks} fragment(s), premier après {first or 0:.1f} s"
            + (
                ""
                if chunks > 1
                else " (pas de diffusion progressive : le panneau affichera la réponse d'un bloc)"
            )
        )
        usage = getattr(merged, "usage_metadata", None) or {}
        print(
            "  jetons en diffusion : "
            + (
                f"comptés ({usage.get('input_tokens')} en entrée, "
                f"{usage.get('output_tokens')} en sortie)"
                if usage.get("output_tokens")
                else "NON COMPTÉS — ils seraient enregistrés à 0 (HERMES_AGENT_STREAM_USAGE, "
                "ou stream_usage dans la fabrique de integration.py)"
            )
        )
    except Exception as exc:  # noqa: BLE001 — tout échec est rapporté
        print(f"  diffusion : ÉCHEC — {type(exc).__name__} : {exc}")
        ok = False
    return ok


async def main() -> int:
    for stream in (
        sys.stdout,
        sys.stderr,
    ):  # console Windows : jamais d'erreur d'encodage
        try:
            stream.reconfigure(errors="replace")
        except AttributeError:
            pass
    settings = AgentSettings()
    if (
        load_integration()
    ):  # fournisseur « banque » de integration.py, comme au démarrage
        print("Fournisseurs de integration.py enregistrés.")
    roles = [
        ("principal", settings.model),
        ("secours", settings.fallback_model),
        ("rapide", settings.fast_model),
    ]
    if not settings.model:
        print("HERMES_AGENT_MODEL n'est pas défini : rien à vérifier.", file=sys.stderr)
        return 1
    results = {}
    for role, spec in roles:
        if spec:
            results[role] = await verifier(role, spec, settings)
    print(
        "\nRésumé : "
        + ", ".join(f"{r} {'OK' if ok else 'ÉCHEC'}" for r, ok in results.items())
    )
    return 0 if results.get("principal") else 1


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
