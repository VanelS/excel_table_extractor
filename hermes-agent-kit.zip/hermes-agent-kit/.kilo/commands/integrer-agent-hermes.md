---
description: Intègre le kit de l'agent Hermes (backend) dans hermes_back, étape par étape
agent: code
---

Tu intègres l'agent conversationnel Hermes dans le backend de HERMES, à partir du kit
décompressé dans `hermes-agent-kit/` à la racine de l'espace de travail.

Avant tout, lis en entier `hermes-agent-kit/PROCEDURE_INTEGRATION.md`, puis
`hermes-agent-kit/LISEZMOI.md` et `hermes-agent-kit/décisions.md`. Suis ensuite la procédure
dans l'ordre, une étape à la fois, de l'étape 1 à l'étape 10, puis l'étape 12. L'étape 11
(endpoint SQL) ne se fait que si je la demande explicitement.

Règles impératives (section 0 de la procédure) :

- Ne devine rien : chaque nom de dépendance, chemin, champ d'API ou identifiant de modèle se
  lit dans le code ou la configuration. Si tu ne le trouves pas, arrête-toi et pose la question.
- N'écrase aucun fichier existant. Ne copie pas `app/__init__.py`, `app/api/__init__.py` ni
  `app/services/__init__.py` du kit ; copie bien ceux de `app/services/agent/`,
  `app/services/agent/tools/` et `tests/agent/`, indispensables.
- Ne modifie aucune route existante (seule exception : la marque « via Hermes » de l'étape 7).
- `hermes_back` et `hermes_front` sont deux dépôts Git distincts : branche, commits et demande
  de fusion se font dans `hermes_back` (`git -C hermes_back …`). Jamais de `stash`, `clean`,
  `reset` ni `checkout -- …`.
- L'agent reste désactivé (`HERMES_AGENT_ENABLED=False`) dans tout ce que tu commites ; aucun
  secret, aucune URL de production, aucun identifiant de modèle inventé, jamais `agent.env`.
- Commandes backend depuis `hermes_back`, avec l'interpréteur du venv. Demande confirmation
  avant `pip install`, la suite de tests complète, tout démarrage de l'application, `git push`
  et l'ouverture de la demande de fusion.
- Ne modifie jamais un test pour le faire passer.
- Tiens à jour `hermes_back/docs/agent-hermes/rapport-integration.md` à chaque étape, et
  consigne dans sa section 4 chaque décision que tu prends, avec sa raison.
- Un commit par étape, message préfixé `agent-hermes :`.

À la fin de chaque étape, donne en trois lignes au plus : ce qui est fait, la vérification et
son résultat, la prochaine étape. Arrête-toi aux conditions d'arrêt de la procédure, et à
l'étape 10 si l'application ne peut pas être démarrée dans cet environnement.
