# kilo-harness — Kilo Code × GPT-6.1 Sol

Harnais pour garder le rapport qualité/prix de GPT-6.1 Sol sans subir sa
latence. Trois leviers :

1. **Effort de raisonnement adapté à la tâche.** Trois agents, low / medium / high.
   Pas de `max` : beaucoup plus lent, et pas meilleur en code.
2. **Exploration déléguée à un modèle rapide.** Le sous-agent `scout` fouille
   le dépôt pour que Sol ne raisonne pas sur de la simple lecture de fichiers.
3. **Moins d'allers-retours et plus de parallélisme.** Ce sont les skills
   `brief-de-tache`, `decoupage-parallele` et `contexte-projet`, avec un `AGENTS.md`.

## Contenu

```
agent/
  sol-rapide.md      primary  · gpt-6.1-sol · low     · steps 30
  sol-standard.md    primary  · gpt-6.1-sol · medium  · steps 60   ← par défaut
  sol-deep.md        primary  · gpt-6.1-sol · high    · arrière-plan
  scout.md           subagent · gpt-6-sol   · low     · lecture seule
skills/
  brief-de-tache/        demande floue → brief complet en un seul passage
  decoupage-parallele/   tâche large → 2 à 4 sous-tâches pour l'Agent Manager
  contexte-projet/       génère / met à jour AGENTS.md (+ modèle inclus)
templates/
  AGENTS.md              à copier à la racine de chaque projet
install.sh / install.ps1
```

## Installation sur l'autre PC

```bash
git clone <url-du-repo> ~/kilo-harness
cd ~/kilo-harness
./install.sh            # macOS / Linux : liens symboliques, mise à jour par git pull
./install.sh --copy     # ou copie simple
```

Sous Windows (PowerShell) :

```powershell
git clone <url-du-repo> $HOME\kilo-harness
cd $HOME\kilo-harness
powershell -ExecutionPolicy Bypass -File .\install.ps1
```

Les fichiers existants qui portent le même nom sont sauvegardés dans
`~/.kilo-harness-backup/<date>/`, rien n'est écrasé sans sauvegarde.
Emplacements utilisés : `~/.config/kilo/agent/` pour les agents et
`~/.kilo/skills/` pour les skills. Vous pouvez les changer avec
`KILO_AGENT_DIR` et `KILO_SKILL_DIR`.

## ⚠️ À vérifier après installation (2 minutes)

1. **Identifiants de modèles.** Lancez `kilo models` et ajustez le champ `model:`
   des 4 agents si besoin :
   - avec votre propre clé OpenAI, c'est en principe `openai/gpt-6.1-sol` ;
   - via la Kilo Gateway, ce sera plutôt `kilo/openai/gpt-6.1-sol`.

   Pour `scout`, vous pouvez prendre encore plus rapide et moins cher, par
   exemple GPT-6 Luna, si `kilo models` le liste.
2. **Variant = effort de raisonnement.** Lancez `kilo debug agent sol-rapide`
   et vérifiez que le variant `low` est bien appliqué. Si le champ `variant`
   n'est pas pris en compte par votre version, enlevez-le et mettez le suffixe
   directement dans le modèle : `model: openai/gpt-6.1-sol#low`.
3. **Skills détectés.** `kilo debug skill` doit lister les 3 skills.

## Utilisation au quotidien

| Situation | Quoi faire |
|---|---|
| Petite modif, question | `sol-rapide` |
| Dev courant | `sol-standard` |
| Bug coriace, archi, migration | `sol-deep` **dans l'Agent Manager**, puis faire autre chose pendant qu'il tourne |
| Grosse feature | « applique decoupage-parallele », puis lancer chaque sous-tâche dans son worktree |
| Demande floue | « applique brief-de-tache » avant de coder |
| Nouveau projet | « applique contexte-projet » pour générer `AGENTS.md`, puis le relire |

## Notes vitesse

- La lenteur de GPT-6.1 Sol vient surtout du temps de réflexion **avant**
  le premier token, et ce temps augmente avec l'effort. Baisser l'effort est
  le premier levier.
- En clé API, le gain de vitesse annoncé par OpenAI le 5 octobre 2026 ne
  s'applique pas : il ne concerne que les abonnés connectés avec ChatGPT dans
  Codex. Pour aller plus vite en API, il faut le tier `fast`, au double du
  prix Standard.
