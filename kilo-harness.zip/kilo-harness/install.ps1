# Installe le harnais Kilo (agents + skills) au niveau utilisateur sous Windows.
# Copie les fichiers (les liens symboliques demandent des droits admin sous Windows).
# Relancer ce script après chaque `git pull` pour mettre à jour.
$ErrorActionPreference = "Stop"

$RepoDir  = Split-Path -Parent $MyInvocation.MyCommand.Path
$AgentDir = if ($env:KILO_AGENT_DIR) { $env:KILO_AGENT_DIR } else { Join-Path $HOME ".config\kilo\agent" }
$SkillDir = if ($env:KILO_SKILL_DIR) { $env:KILO_SKILL_DIR } else { Join-Path $HOME ".kilo\skills" }
$Backup   = Join-Path $HOME (".kilo-harness-backup\" + (Get-Date -Format "yyyyMMdd-HHmmss"))

New-Item -ItemType Directory -Force -Path $AgentDir, $SkillDir | Out-Null

function Install-Item($Src, $Dest) {
    if (Test-Path $Dest) {
        New-Item -ItemType Directory -Force -Path $Backup | Out-Null
        Move-Item $Dest $Backup
        Write-Host "  ! $(Split-Path $Dest -Leaf) existant sauvegardé dans $Backup"
    }
    Copy-Item $Src $Dest -Recurse
    Write-Host "  + $(Split-Path $Dest -Leaf)"
}

Write-Host "Agents  -> $AgentDir"
Get-ChildItem (Join-Path $RepoDir "agent\*.md") | ForEach-Object {
    Install-Item $_.FullName (Join-Path $AgentDir $_.Name)
}

Write-Host "Skills  -> $SkillDir"
Get-ChildItem (Join-Path $RepoDir "skills") -Directory | ForEach-Object {
    Install-Item $_.FullName (Join-Path $SkillDir $_.Name)
}

Write-Host ""
Write-Host "Installé. Vérifications conseillées :"
Write-Host "  kilo models"
Write-Host "  kilo debug agent sol-standard"
Write-Host "  kilo debug skill"
Write-Host "Puis /reload ou nouvelle session dans VS Code."
