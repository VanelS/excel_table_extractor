---
name: decoupage-parallele
description: Découpe une tâche large en sous-tâches indépendantes à lancer en parallèle dans l'Agent Manager de Kilo (un git worktree par agent). À utiliser pour une feature multi-modules, une migration ou une série de corrections indépendantes.
---

# Découpage pour agents parallèles

Le modèle est lent mais pas cher : on compense la latence en faisant tourner
plusieurs agents en même temps, chacun dans son worktree.

## Règles de découpage

- Chaque sous-tâche doit toucher des fichiers DIFFÉRENTS des autres
  (sinon conflits de merge).
- Chaque sous-tâche doit être testable seule.
- 2 à 4 sous-tâches maximum. Au-delà, la relecture devient le goulot.
- Les interfaces partagées (types, signatures d'API, schémas) sont définies
  D'ABORD, dans une sous-tâche 0 faite en séquentiel, puis les autres partent
  en parallèle.

## Sortie attendue

Pour chaque sous-tâche, produire un bloc prêt à coller dans un nouvel agent
de l'Agent Manager :

```
### Sous-tâche N — <titre>
Agent : sol-rapide | sol-standard | sol-deep
Branche/worktree : feat/<slug>
Fichiers autorisés : <liste>
Ne pas toucher : <liste>
Objectif : ...
Critères d'acceptation : ...
Tests : <commande>
```

Terminer par l'ordre de merge conseillé et les points de vigilance à la
relecture.
