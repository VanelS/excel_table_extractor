---
name: brief-de-tache
description: Transforme une demande de code floue en brief complet (contexte, fichiers, critères d'acceptation, commande de test) avant de lancer le travail. À utiliser quand une demande manque d'informations, pour éviter les allers-retours coûteux avec un modèle lent.
---

# Brief de tâche

Objectif : obtenir en UNE fois tout ce qu'il faut pour coder sans revenir
vers l'utilisateur. Chaque aller-retour coûte une longue phase de réflexion
au modèle, donc on les évite.

## Étapes

1. Lis la demande et AGENTS.md. Note ce qui est déjà connu.
2. Si besoin, délègue au sous-agent `scout` la localisation du code concerné.
3. Remplis ce brief :

```
OBJECTIF : <une phrase>
CONTEXTE : <pourquoi, contraintes connues>
FICHIERS : <chemins à modifier / à lire>
HORS PÉRIMÈTRE : <ce qu'on ne touche pas>
CRITÈRES D'ACCEPTATION :
  - [ ] ...
  - [ ] ...
TESTS : <commande exacte à lancer>
EFFORT CONSEILLÉ : sol-rapide | sol-standard | sol-deep
PARALLÉLISABLE : oui/non (si oui, voir skill decoupage-parallele)
```

4. S'il manque une information que tu ne peux pas déduire du code, pose
   TOUTES les questions en une seule fois (3 max). Sinon, fais une hypothèse
   raisonnable, écris-la dans le brief, et commence.
5. Utilise le brief comme checklist pendant le travail et coche les
   critères dans le rapport final.
