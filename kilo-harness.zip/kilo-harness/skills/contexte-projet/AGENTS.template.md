# AGENTS.md

> Lu par Kilo à chaque session. Garder court (< 120 lignes) et à jour.
> Astuce : demander à l'agent « applique le skill contexte-projet » pour le remplir.

## Stack
- Langage : <ex. Python 3.12>
- Framework : <ex. FastAPI / Django / React>
- Gestionnaire de paquets : <ex. uv / poetry / pnpm>

## Structure du dépôt
```
src/        <rôle>
tests/      <rôle>
...
```

## Commandes
| Action | Commande |
|---|---|
| Installer | `<ex. uv sync>` |
| Test ciblé | `<ex. uv run pytest tests/chemin/test_x.py -q>` |
| Tests complets | `<ex. uv run pytest -q>` |
| Lint | `<ex. uv run ruff check .>` |
| Format | `<ex. uv run ruff format .>` |
| Lancer | `<ex. uv run uvicorn app.main:app --reload>` |

Toujours lancer le **test ciblé** pendant le travail, les tests complets à la fin.

## Conventions
- <nommage, style, structure des modules>
- <où placer les nouveaux tests>
- <gestion des erreurs, logs>

## Pièges connus / à ne pas faire
- <ex. ne jamais modifier les migrations déjà appliquées>
- <ex. les fixtures de tests/data sont générées, ne pas les éditer à la main>

## Choix d'agent
- `sol-rapide` : fix simple, renommage, test unitaire, question.
- `sol-standard` : feature moyenne, debug classique (par défaut).
- `sol-deep` : architecture, bug coriace, migration — en arrière-plan dans l'Agent Manager.
- Recherche dans le code : déléguer au sous-agent `scout`.
