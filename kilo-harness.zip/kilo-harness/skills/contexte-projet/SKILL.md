---
name: contexte-projet
description: Génère ou met à jour le fichier AGENTS.md d'un projet (stack, structure, commandes de build/test/lint, conventions, pièges connus) pour que les agents n'aient plus à redécouvrir le dépôt à chaque session. À utiliser à l'arrivée sur un nouveau projet ou quand AGENTS.md est absent ou obsolète.
---

# Contexte projet → AGENTS.md

Un bon AGENTS.md est le levier le plus rentable avec un modèle lent :
moins d'exploration = moins de réflexion = réponses plus rapides.

## Étapes

1. Délègue au sous-agent `scout` l'inventaire du dépôt :
   - langage(s), framework(s), gestionnaire de paquets,
   - arborescence principale (2 niveaux),
   - fichiers de config (pyproject, package.json, Makefile, docker-compose, CI),
   - commandes de test / lint / format / build trouvées dans ces fichiers,
   - conventions visibles (nommage, structure des tests, style d'imports).
2. Pars du modèle `AGENTS.template.md` situé dans le dossier de ce skill
   et remplis chaque section avec ce que `scout` a trouvé.
3. Vérifie les commandes en les lançant une fois (tests et lint). Corrige
   celles qui échouent ou signale-les.
4. Écris le fichier à la racine du projet. S'il existe déjà, ne réécris que
   les sections obsolètes et garde les ajouts manuels de l'utilisateur.
5. Garde-le court : < 120 lignes. Ce fichier est relu à chaque session.

## Structure attendue

- Stack
- Structure du dépôt
- Commandes (install, test ciblé, test complet, lint, format, run)
- Conventions
- Pièges connus / à ne pas faire
- Choix d'agent (rapide / standard / deep)
