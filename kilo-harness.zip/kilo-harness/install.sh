#!/usr/bin/env bash
# Installe le harnais Kilo (agents + skills) au niveau utilisateur.
# Par défaut : liens symboliques vers ce dépôt, donc un `git pull` suffit
# pour mettre à jour. Option --copy pour copier les fichiers à la place.
set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
AGENT_DIR="${KILO_AGENT_DIR:-$HOME/.config/kilo/agent}"
SKILL_DIR="${KILO_SKILL_DIR:-$HOME/.kilo/skills}"
MODE="link"
[[ "${1:-}" == "--copy" ]] && MODE="copy"

mkdir -p "$AGENT_DIR" "$SKILL_DIR"
BACKUP_DIR="$HOME/.kilo-harness-backup/$(date +%Y%m%d-%H%M%S)"

install_item () {
  local src="$1" dest="$2"
  if [[ -e "$dest" || -L "$dest" ]]; then
    # Déjà un lien vers ce dépôt : rien à faire
    if [[ -L "$dest" && "$(readlink "$dest")" == "$src" ]]; then
      echo "  = $(basename "$dest") (déjà installé)"; return
    fi
    mkdir -p "$BACKUP_DIR"
    mv "$dest" "$BACKUP_DIR/"
    echo "  ! $(basename "$dest") existant sauvegardé dans $BACKUP_DIR"
  fi
  if [[ "$MODE" == "link" ]]; then ln -s "$src" "$dest"; else cp -R "$src" "$dest"; fi
  echo "  + $(basename "$dest")"
}

echo "Agents  -> $AGENT_DIR"
for f in "$REPO_DIR"/agent/*.md; do
  install_item "$f" "$AGENT_DIR/$(basename "$f")"
done

echo "Skills  -> $SKILL_DIR"
for d in "$REPO_DIR"/skills/*/; do
  d="${d%/}"
  install_item "$d" "$SKILL_DIR/$(basename "$d")"
done

cat <<EOF

Installé (mode: $MODE).
Vérifications conseillées :
  kilo models                      # vérifier les identifiants de modèles
  kilo debug agent sol-standard    # vérifier modèle + variant résolus
  kilo debug skill                 # vérifier que les 3 skills sont détectés
Puis /reload ou nouvelle session dans VS Code.
EOF
